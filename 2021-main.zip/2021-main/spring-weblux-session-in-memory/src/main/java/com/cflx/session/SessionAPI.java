package com.cflx.session;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.WebSession;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/session")
public class SessionAPI {


    @GetMapping
    public Mono<String> getSession(WebSession session){
        session.getAttributes().putIfAbsent("Hi","Hello");

        Map<String,Object> s = session.getAttributes();

        for (Map.Entry<String,Object> m : s.entrySet()){
            System.out.println(m.getKey()+" : "+m.getValue());
        }


        return  Mono.just((String) session.getAttributes().get("Hi"));
    }


}
