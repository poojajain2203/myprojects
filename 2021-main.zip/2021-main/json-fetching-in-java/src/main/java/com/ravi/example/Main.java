package com.ravi.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

public class Main {

	private static Connection con = null;
	ObjectMapper objectMapper = new ObjectMapper();

	public Main() throws ClassNotFoundException, SQLException {
		Class.forName("org.postgresql.Driver");

		con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/test", "postgres", "14july");

	}

	private List<Map<String, Object>> setRelationships(Object relationships, String relationshipType) {
		JsonNode relationshipObject = objectMapper.convertValue(relationships, JsonNode.class);
		List<Map<String, Object>> relationshipList = new ArrayList<>();

		try {
			JsonNode relationshipNode = objectMapper.readTree(relationshipObject.asText());
			if (relationshipNode.get("values") != null && !relationshipNode.get("values").isNull()
					&& relationshipNode.get("values").isArray()) {
				ArrayNode values = (ArrayNode) relationshipNode.get("values");
				for (final JsonNode relationship : values) {
					Map<String, Object> relationshipMap = new HashMap<>();
					relationshipMap.put("category",
							relationship.get("relationshipCategory") != null
									? relationship.get("relationshipCategory").asText()
									: null);
					relationshipMap.put("type",
							relationship.get("relationshipTypeName") != null
									? relationship.get("relationshipTypeName").asText()
									: null);

					relationshipMap.put("data", relationship.get("data") != null ? relationship.get("data") : null);
					relationshipMap.put("valuePath",
							relationship.get("domainValuePath").asText() != null
									? relationship.get("domainValuePath").asText()
									: null);
					if (relationship.get("relatedSince") != null) {
						long relatedSince = Long.parseLong(relationship.get("relatedSince").asText());
						Instant createTime = Instant.ofEpochMilli(relatedSince);
						relationshipMap.put("createTime", createTime);
					}
					relationshipMap.put("valueSignature",
							relationship.get("valueSignature").asText() != null
									? relationship.get("valueSignature").asText()
									: null);

					if (relationshipType == null) {
						relationshipList.add(relationshipMap);
					} else if (relationshipType.equals(relationship.get("relationshipTypeName").asText())) {
						relationshipList.add(relationshipMap);

					}
				}
			}
		} catch (IOException e) {
			// logger.error("Invalid Json : please validate alerts value.");
		}
		return relationshipList;
	}

	private List<Map<String, Object>> setActors(final JsonNode relationships, String actorType) {
		JsonNode relationshipObject = objectMapper.convertValue(relationships, JsonNode.class);
		List<Map<String, Object>> actorMap = new ArrayList<>();

		try {
			JsonNode relationshipNode = objectMapper.readTree(relationshipObject.asText());
			if (relationshipNode.get("values") != null && !relationshipNode.get("values").isNull()
					&& relationshipNode.get("values").isArray()) {
				ArrayNode values = (ArrayNode) relationshipNode.get("values");
				for (final JsonNode relationship : values) {
					Map<String, Object> person = new HashMap<>();
					Map<String, Object> actors = new HashMap<>();
					person.put("userId", relationship.get("rangeEntityKey").asText());
					actors.put("person", person);
					actors.put("type",
							relationship.get("relationshipTypeName") != null
									? relationship.get("relationshipTypeName").asText()
									: null);
					actors.put("data", relationship.get("data"));
					actors.put("valuePath", relationship.get("domainValuePath").asText());
					if (relationship.get("relatedSince") != null) {
						long relatedSince = Long.parseLong(relationship.get("relatedSince").asText());
						Instant createTime = Instant.ofEpochMilli(relatedSince);
						actors.put("createTime", createTime);
					}
					actors.put("valueSignature", relationship.get("valueSignature").asText());

					if (actorType != null && (!actorType.isEmpty() && actorType.equals("relationshipTypeName"))) {
						actorMap.add(actors);
					} else {
						actorMap.add(actors);
					}
				}
			}
		} catch (IOException e) {
			// logger.error("Invalid Json : please validate alerts value.");
		}
		return actorMap;
	}
	private List<Map<String, Object>> setEvent(Object events, Object processId, Object gid) {
		JsonNode eventsNode = objectMapper.convertValue(events, JsonNode.class);

		List<Map<String, Object>> eventList = new ArrayList<>();
		Map<String, Object> eventMap = new HashMap<>();
		try {
			JsonNode eventNode = objectMapper.readTree(eventsNode.asText());
			if (eventNode.isArray()) {
				for (final JsonNode event : eventNode) {
					eventMap = objectMapper.convertValue(event, Map.class);
					eventMap.put("processId", processId);
					eventMap.put("gid", gid);
					if (eventMap.get("category") != null) {
						String category = eventMap.get("category").toString();
						// String eventCategory = EventCategory.valueOf(category).getUiEventCategory();
						eventMap.put("eventCategory", category);
					}
					if (eventMap.get("type") != null) {
						String type = eventMap.get("type").toString();
						// String eventType = EventType.valueOf(type).getUiEventType();
						eventMap.put("type", type);
					}
					eventList.add(eventMap);
				}
			}
		} catch (IOException e) {
		//	logger.error("Invalid Json : please validate alerts value.");
		}

		return eventList;
	}

	private List<Map<String, Object>> setAlertLevel(Object alerts, Object processId) {
		JsonNode alertsNode = objectMapper.convertValue(alerts, JsonNode.class);
		System.out.println(alertsNode);
		List<Map<String, Object>> alertList = new ArrayList<>();
		try {
			JsonNode arrNode = objectMapper.readTree(alertsNode.asText());
			if (arrNode.get("values").isArray()) {
				ArrayNode values = (ArrayNode) arrNode.get("values");
				for (final JsonNode objNode : values) {
					Map<String, Object> alertsMap = new HashMap<>();
					alertsMap = objectMapper.convertValue(objNode, Map.class);
					alertsMap.put("processId", processId);
					alertsMap.put("messages", alertsMap.get("message"));
					alertsMap.put("gid", objNode.get("$gid") != null ? objNode.get("$gid").asText() : null);
					alertsMap.remove("$gid");
					if (alertsMap.get("raisedTime") != null) {
						alertsMap.put("raisedTime",
								Instant.ofEpochMilli(Long.parseLong(alertsMap.get("raisedTime").toString())));
					} else {
						alertsMap.put("raisedTime", null);
					}
					if (alertsMap.get("level") != null) {
						int level = Integer.parseInt((String) alertsMap.get("level"));
						
						if (level == 1) {
							alertsMap.put("level", "INFO_LEVEL");
						} else if (level == 2) {
							alertsMap.put("level", "LOW_LEVEL");
						} else if (level == 3) {
							alertsMap.put("level", "MEDIUM_LEVEL");
						} else if (level == 4) {
							alertsMap.put("level", "HIGH_LEVEL");
						} else {
							alertsMap.put("level", "CRITICAL_LEVEL");
						}
					}
					alertList.add(alertsMap);
				}
			}
		} catch (IOException e) {
			//logger.error("Invalid Json : please validate alerts value.");
		}
		return alertList;
	}

	public static void main(String[] args)
			throws JsonMappingException, JsonProcessingException, ClassNotFoundException, SQLException {
		ObjectMapper mapper = new ObjectMapper();
		Main m = new Main();
		Statement stmt = null;
		String Query = "SELECT alerts from iap_probable_entity";

		stmt = con.createStatement();
		ResultSet res = stmt.executeQuery(Query);
		JsonNode jsonNode = null;
		String f = null;
		while (res.next()) {
			if (res.getString(1) != null) {
				//jsonNode = res.getString(1) != null ? mapper.convertValue(res.getString(1), JsonNode.class) : null;
				f = res.getString(1);
			}
		}
		System.out.println(f);
	//	List<Map<String, Object>> map = m.setEvent(jsonNode, "88", "00");
	//	System.out.println("map=>" + map);
	//	System.out.println(jsonNode);

	}
}
