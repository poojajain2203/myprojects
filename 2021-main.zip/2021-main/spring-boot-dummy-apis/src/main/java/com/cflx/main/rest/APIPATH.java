package com.cflx.main.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cflx.main.model.Product;

@RestController
@RequestMapping("/process")
public class APIPATH {
	@Autowired
	private Product product;
	
	@GetMapping("/products")
	public ResponseEntity<Object> getProducts(){
		return new ResponseEntity<Object>(product.getRecords(),HttpStatus.OK);
	}

}
