package com.cflx.main.model;

import java.util.HashMap;
import java.util.Map;
public class Product {

	int id;
	String name;

	static Map<Integer, String> map;

	static {
		map = new HashMap<Integer, String>();

		map.put(1, "Red");
		map.put(2, "Blue");
		map.put(3, "Black");
	}

	public Map<Integer, String> getRecords() {
		return map;
	}

}
