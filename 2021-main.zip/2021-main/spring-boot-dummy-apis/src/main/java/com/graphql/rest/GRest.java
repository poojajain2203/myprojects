package com.graphql.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cflx.main.model.Product;

import ch.qos.logback.classic.Logger;

@RestController
@RequestMapping("/graphql")
public class GRest {
	
	@Autowired
	private Product product;
	
	
	@GetMapping("/products")
	public ResponseEntity<Object> getPros(){
		return new ResponseEntity<Object>(product.getRecords(),HttpStatus.OK);
	}
	
	@GetMapping("/products/{id}")
	public ResponseEntity<Object> getPros2(@RequestHeader("tenantOrgId") String tenantOrgId,@PathVariable("id") int id){
		System.out.println("tenantOrgId :: ====>"+tenantOrgId);
		return new ResponseEntity<Object>(product.getRecords().get(id),HttpStatus.OK);
	}
	
	
	@PostMapping(produces = "application/json", consumes = "application/json")
	public  ResponseEntity<Object> getPros3(@RequestHeader("tenantOrgId") String tenantOrgId,@RequestBody GraphqlRequestBuilder graphqlRequestBuilder){
		
		System.out.println("graphqlRequestBuilder ::=========> "+graphqlRequestBuilder);
		System.out.println("graphqlRequestBuilder.getQuery()  ::===========> "+graphqlRequestBuilder.getQuery());
		System.out.println("graphqlRequestBuilder.getVariables() ::===========> "+graphqlRequestBuilder.getVariables());
		System.out.println("graphqlRequestBuilder.getOperationsName() :: ========> "+graphqlRequestBuilder.getOperationName());
		
		
		return new ResponseEntity<Object>("Success...",HttpStatus.OK);
	}
 
}
