package com.spring.webflux.service;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping(path="/service")
public class Cart {
    @GetMapping(path="/hello")
    public Mono<String> printHello(){
        System.out.println("Hi....");
        return Mono.just("Hello Service");
    }
}
