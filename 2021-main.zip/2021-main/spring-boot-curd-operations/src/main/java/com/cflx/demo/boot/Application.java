package com.cflx.demo.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
//@ComponentScan(basePackageClasses = API.class)
public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(Application.class, args);
	}
}


/**
 * --Notes:
 * 		- Put Application.Java in root package of controller.
 * 
 * if Application.java package is : com.cflx.demo.boot.application.Application.java
 *   - add component scan in Application.java file.
 *	if Application.java package is : com.cflx.demo.boot.Application.java
 *  -- not required to add component scan.
 * 
 * */