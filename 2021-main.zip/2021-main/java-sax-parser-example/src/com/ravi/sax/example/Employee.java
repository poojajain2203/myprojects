package com.ravi.sax.example;

/**
 * SAX Parser in java provides API to parse XML documents. SAX parser is different from DOM parser because it doesn�t 
 * load complete XML into memory and read xml document sequentially.
 * 
 * */


/*
 javax.xml.parsers.SAXParser provides method to parse XML document using event handlers. 
 This class implements XMLReader interface and provides overloaded versions of parse() methods to read XML document from File, 
 InputStream, SAX InputSource and String URI.

The actual parsing is done by the Handler class. We need to create our own handler class to parse the XML document. 
We need to implement org.xml.sax.ContentHandler interface to create our own handler classes. This interface contains 
callback methods that receive notification when an event occurs. 
For example StartDocument, EndDocument, StartElement, EndElement, CharacterData etc.

org.xml.sax.helpers.DefaultHandler provides default implementation of ContentHandler interface and we can 
extend this class to create our own handler. 
It�s advisable to extend this class because we might need only a few of the methods to implement. 
Extending this class will keep our code cleaner and maintainable.
 */

public class Employee {

	private int id;
	private String name;
	private String gender;
	private int age;
	private String role;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Employee:: ID=" + this.id + " Name=" + this.name + " Age=" + this.age + " Gender=" + this.gender
				+ " Role=" + this.role;
	}

}
