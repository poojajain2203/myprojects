package com.ravi.practice.test.operations.csv;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ravi.practice.operations.csv.ReadCSV;

public class TestCSVOperations {
	private ReadCSV readCSV;
	
	@BeforeTest
	public void init() {
		readCSV = new ReadCSV();
	}
	
  @Test
  public void testreadCSVEmloyee() {
	  String path = "src/test/resources/employee.csv";
	  readCSV.readCSV(path);
  }
  
  
  @Test
  public void testreadCSVPE() {
	  String path = "src/test/resources/pe.csv";
	  readCSV.readCSV(path);
  }
  
  
  @Test
  public void testreadCSVPEP() {
	  String path = "src/test/resources/pep.csv";
	  readCSV.readCSV(path);
  }
  
  @Test
  public void testreadCSVREQ() {
	  String path = "src/test/resources/req.csv";
	  readCSV.readCSV(path);
  }
}
