package com.ravi.practice.operations.csv;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import scala.Tuple2;

public class ReadCSV {
	public void readCSV(String path) {
		System.setProperty("hadoop.home.dir", "C:\\winutils");
		SparkSession sparkSession = SparkSession.builder().appName("Basic Example").config("spark.master", "local")
				.getOrCreate();

		Map<String, String> map = new HashedMap();
		map.put("header", "true"); // by default false -> read as a String.
		map.put("inferSchema", "true"); // by default false-> read as a
		map.put("delimiter", "|");
		map.put("timestampFormat", "yyyy-MM-dd HH:mm:ss.SSSSSSSSS");
		Dataset<Row> ds = sparkSession.read().options(map).csv(path);

		// Displays the content of the DataFrame to stdout.	
		ds.show();

		// Print the schema in a tree format
		ds.printSchema();
		
	

		/************************************************************************************************************/

		// For CSV Data:
		List<Row> list = ds.collectAsList();
		System.out.println(list);

		// For CSV Header:
		Tuple2<String, String>[] st = ds.dtypes();

		System.out.println("Length Of Tuple::=>" + st.length);

		for (int i = 0; i < st.length; i++) {
			System.out.println("Name:=>" + st[i]._1 + " " + "Type:=>" + st[i]._2);
		}
		/*************************************************************************************************************/
	}

}
