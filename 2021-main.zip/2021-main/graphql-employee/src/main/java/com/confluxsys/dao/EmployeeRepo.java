package com.confluxsys.dao;

import java.util.ArrayList;
import java.util.List;

import com.confluxsys.model.Address;
import com.confluxsys.model.Employee;

public class EmployeeRepo {
	
		private final List<Employee> emp;
		public EmployeeRepo() {
			emp = new ArrayList<Employee>();
			emp.add(new Employee("101", "Ravi", "test@123.com",new Address("201", "HMH", "Rajasthan")));
			emp.add(new Employee("102", "Test", "test@123.com", new Address("202", "HMH", "Rajasthan")));
			emp.add(new Employee("103", "OP", "test@123,com",new Address("203", "HMH", "Rajasthan")));
			emp.add(new Employee("104", "GMAIL", "test@123.com", new Address("204", "HMH", "Rajasthan")));
			emp.add(new Employee("105", "PCM", "test@123.com",new Address("205", "HMH", "Rajasthan")));
			emp.add(new Employee("106", "Ram", "test@123.com", new Address("206", "HMH", "Rajasthan")));
			emp.add(new Employee("107", "Kuamr", "test@123.com",new Address("207", "HMH", "Rajasthan")));
			emp.add(new Employee("108", "TT.K", "test@123.com", new Address("208", "HMH", "Rajasthan")));
			emp.add(new Employee("109", "Template", "test@123.com",new Address("209", "HMH", "Rajasthan")));
			emp.add(new Employee("110", "CSV", "test@123.com", new Address("210", "HMH", "Rajasthan")));
		
		}
		
		
		public List<Employee> getAllEmployee(){
			return emp;
		}
}
