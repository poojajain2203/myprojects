package com.confluxsys.graphql;

import java.util.List;

import com.confluxsys.dao.EmployeeRepo;
import com.confluxsys.model.Employee;
import com.coxautodev.graphql.tools.GraphQLRootResolver;

public class Query implements GraphQLRootResolver {

	private final EmployeeRepo employeeRepo;

	public Query(EmployeeRepo employeeRepo) {
		this.employeeRepo = employeeRepo;
	}

	public List<Employee> allEmployee() {
		return employeeRepo.getAllEmployee();
	}
	
	

}
