package com.confluxsys.model;

public class Address {

	String id;
	String city;
	String state;

	public Address(String id, String city, String state) {
		super();
		this.id = id;
		this.city = city;
		this.state = state;
	}

	public Address() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}
