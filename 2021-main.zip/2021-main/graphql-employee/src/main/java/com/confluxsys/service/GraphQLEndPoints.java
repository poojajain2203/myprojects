package com.confluxsys.service;

import javax.servlet.annotation.WebServlet;

import com.confluxsys.dao.EmployeeRepo;
import com.confluxsys.graphql.Query;
import com.coxautodev.graphql.tools.SchemaParser;

import graphql.schema.GraphQLSchema;
import graphql.servlet.SimpleGraphQLServlet;

@WebServlet(urlPatterns = "/employees")
public class GraphQLEndPoints extends SimpleGraphQLServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GraphQLEndPoints() {
		super(buildSchema());
	}

	private static GraphQLSchema buildSchema() {
		
		EmployeeRepo employeeRepo = new EmployeeRepo();
		

		return SchemaParser.newParser().file("emp.graphqls").resolvers(new Query(employeeRepo)).build().makeExecutableSchema();
				
	}

}
