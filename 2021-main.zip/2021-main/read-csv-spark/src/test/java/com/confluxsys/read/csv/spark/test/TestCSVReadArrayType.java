package com.confluxsys.read.csv.spark.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.confluxsys.read.csv.spark.ReadCSVFieldUsingSparkArrayType;

public class TestCSVReadArrayType {
	private ApplicationContext context;
	private ReadCSVFieldUsingSparkArrayType readCSVFieldUsingSparkArrayType;
	
	@BeforeTest
	public void init() {
		context = new ClassPathXmlApplicationContext("bean.xml");
		readCSVFieldUsingSparkArrayType = context.getBean(ReadCSVFieldUsingSparkArrayType.class);
	}  
  @Test(description = "Test Method 001")
  public void testReadCSVArrayType() {
	  String path = "src/test/resources/sample2.csv";
	  readCSVFieldUsingSparkArrayType.readCSV(path);
  }
}
