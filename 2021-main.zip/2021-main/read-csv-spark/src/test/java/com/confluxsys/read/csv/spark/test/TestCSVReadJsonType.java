package com.confluxsys.read.csv.spark.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.confluxsys.read.csv.spark.ReadCSVFieldUsingSparkArrayType;
import com.confluxsys.read.csv.spark.ReadCSVFieldUsingSparkJsonType;

public class TestCSVReadJsonType {
	private ApplicationContext context;
	private ReadCSVFieldUsingSparkJsonType readCSVFieldUsingSparkCsvFieldUsingSparkJsonType;
	
	@BeforeTest
	public void init() {
		context = new ClassPathXmlApplicationContext("bean.xml");
		readCSVFieldUsingSparkCsvFieldUsingSparkJsonType = context.getBean(ReadCSVFieldUsingSparkJsonType.class);
	}  
  @Test(description = "Test Method 001")
  public void testReadCSVJsonType() {
	  String path = "src/test/resources/sample3.csv";
	  readCSVFieldUsingSparkCsvFieldUsingSparkJsonType.readCSV(path);
  }
}
