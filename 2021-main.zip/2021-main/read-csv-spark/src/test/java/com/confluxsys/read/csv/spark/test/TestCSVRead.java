package com.confluxsys.read.csv.spark.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.confluxsys.read.csv.spark.ReadCSVFieldUsingSpark;

public class TestCSVRead {
	private ApplicationContext context;
	private ReadCSVFieldUsingSpark readCSVFieldUsingSpark;
	
	@BeforeTest
	public void init() {
		context = new ClassPathXmlApplicationContext("bean.xml");
		readCSVFieldUsingSpark = context.getBean(ReadCSVFieldUsingSpark.class);
	}
	
  @Test(description = "Test Method 001")
  public void testReadCSV() {
	  String path = "src/test/resources/sample.csv";
	  readCSVFieldUsingSpark.readCSV(path);
  }
}
