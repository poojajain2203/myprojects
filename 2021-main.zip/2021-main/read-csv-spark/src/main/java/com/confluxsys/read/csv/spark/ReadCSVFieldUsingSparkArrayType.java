package com.confluxsys.read.csv.spark;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;

public class ReadCSVFieldUsingSparkArrayType {

	public void readCSV(String path) {

		SparkSession sparkSession = SparkSession.builder().master("local").appName("Read CSV").getOrCreate();
		SQLContext sqlContext = new SQLContext(sparkSession);
		Dataset<Row> csvRows = sqlContext.read().format("com.databricks.spark.csv").option("header", "true")
				.option("inferSchema", "true").option("delimiter", "|")
				.option("timestampFormat", "yyyy-MM-dd HH:mm:ss.SSSSSSSSS").load(path).toDF("id","values");
		csvRows.printSchema();	
		
		
		 Dataset<Row> newCsvRows = csvRows.withColumn("values",functions.split(functions.col("values"), "\\,"));
		 
		 newCsvRows.printSchema();
		 newCsvRows.show();
		
		
	}



}
