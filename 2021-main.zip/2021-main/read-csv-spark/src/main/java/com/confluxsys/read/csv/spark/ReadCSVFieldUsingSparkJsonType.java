package com.confluxsys.read.csv.spark;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class ReadCSVFieldUsingSparkJsonType {

	public void readCSV(String path) {

		SparkSession sparkSession = SparkSession.builder().master("local").appName("Read CSV").getOrCreate();
		SQLContext sqlContext = new SQLContext(sparkSession);
		Dataset<Row> csvRows = sqlContext.read().format("com.databricks.spark.csv").option("header", "true")
				.option("inferSchema", "true").option("delimiter", "|")
				.option("timestampFormat", "yyyy-MM-dd HH:mm:ss.SSSSSSSSS").load(path);
		csvRows.printSchema();	
		csvRows.show();
		StructType schema = null;
	//	csvRows.select(functions.col("id"),functions.from_json("JsonValue",schema))
		
		
	}



}
