package com.confluxsys.read.csv.spark;

/**
 * @author Ravi Ranjan
 * */

public class JsonSchemaConstants {
	
	/**
	 * JSONSchema Constants.
	 * */
	
	public static final String SCHEMA = "$schema";
	public static final String SCHEMA_VALUE = "http://json-schema.org/draft-07/schema#";
	public static final String TITLE = "title";
	public static final String TYPE = "type";
	public static final String PROPERTIES = "properties";
	public static final String NAME = "name";
	public static final String FIELDS = "fields";
	public static final String ITEMS = "items";
	public static final String REQUIRED = "required";
	
	public static final String EXTENSION = "$extension";
	//$extension values.
	public static final String IS_IDENTIFIER = "isIdentifier";
	public static final String IS_NAME_ATTRIBUTE = "isNameAttribute";
	public static final String IS_NATIVE_ID = "isNativeId";
	public static final String IS_STATUS = "isStatus";
	
	
	
	//JSON_SCHEMA TYPE
	public static final String TYPE_OBJECT = "object";
	public static final String TYPE_ARRAY = "array";
	
	
	/**
	  "externalSystemArtifactTypes": {
        "Sailpoint": [
          {
            "artifactCategory": "Entitlement",
            "artifactTypeName": "Groups",
            "targetAdditionalInfo": null,
            "purpose": "Synchronize",
            "schemaMapping": null
          }
        ]
      }
      */
	
	//externalSystemArtifactTypes
	public static final String EXTERNAL_SYSTEM_ARTIFACT_TYPES = "externalSystemArtifactTypes";
	public static final String SAILPOINT ="Sailpoint";
	public static final String IAP="IAP";
	public static final String OIM = "OIM";
	public static final String ARTIFACT_CATEGORY = "artifactCategory";
	public static final String ARTIFACT_TYPE_NAME = "artifactTypeName";
	public static final String TARGET_ADDITIONAL_INFO = "targetAdditionalInfo";
	public static final String PURPOSE= "purpose";
	public static final String SCHEMA_MAPPING  = "schemaMapping";
	

}
