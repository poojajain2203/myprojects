package com.confluxsys.tools.read.csv.spark.v2;

import java.util.Iterator;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.StructType;

/**
 * @author Ravi Ranjan
 */

public class ReadCSVAllData {

	public static void main(String[] args) {
		// SparkSession
		SparkSession sparkSession = SparkSession.builder().master("local[1]").appName("csv read").getOrCreate();
		// Create sqlContext Object.
		SQLContext sqlContext = new SQLContext(sparkSession);

		String path = getPath();
		Dataset<Row> dataSet = readCsv(sqlContext, path);
		/*
		 * System.out.println("========================Print Schema=================");
		 * showSchema(dataSet);
		 * System.out.println("=========================Print CSV Data================"
		 * ); printDataInCSV(dataSet);
		 * 
		 */

		/**
		 * Read CSV Header.
		 */

//		csvHeaderOperations(dataSet);

		/**
		 * Read CSV Values Row & Column.
		 * 
		 */
	//	List<Row> allCSVRows = dataSet.collectAsList();
	//	readCsvData(allCSVRows);

		
		StructType schema = dataSet.head().schema();
		System.out.println("SChema:"+schema);
		
		/*
		 * String[] filedName = schema.fieldNames();
		 * System.out.println("fieldName::"+filedName);
		 */
		
		System.out.println("Json::"+schema.json());
		
		System.out.println("prettyJson::"+schema.prettyJson());
		
	
	}

	private static void csvHeaderOperations(Dataset<Row> dataSet) {
		Row headerRow = dataSet.head();
		// header Schema.
		
		StructType headerStructure = headerRow.schema();
		System.out.println(headerStructure);

	

	}

	private static void readCsvData(List<Row> allCSVRows) {
		for (Row row : allCSVRows) {
			// Check The Row Length:
			// System.out.println("Row Length :: "+row.length());
			for (int i = 0; i < row.length(); i++) {
				System.out.print(row.get(i) + "   ");
			}
			System.out.println();
		}

	}

	private static void printDataInCSV(Dataset<Row> dataSet) {
		dataSet.show();

	}

	private static void showSchema(Dataset<Row> dataSet) {
		dataSet.printSchema();

	}

	private static String getPath() {
		String path = "src/test/resources/sample.csv";
		return path;
	}

	private static Dataset<Row> readCsv(SQLContext sqlContext, String path) {
		return sqlContext.read().format("com.databricks.spark.csv").option("header", "true")
				.option("inferSchema", "true").option("delimiter", "|")
				.option("timestampFormat", "yyyy-MM-dd HH:mm:ss.SSSSSSSSS").load(path);
	}

}
