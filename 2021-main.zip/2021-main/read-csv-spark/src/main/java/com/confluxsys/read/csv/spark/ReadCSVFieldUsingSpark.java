package com.confluxsys.read.csv.spark;

import java.util.List;

import org.apache.commons.collections.map.HashedMap;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.ArrayType;
import org.apache.spark.sql.types.BinaryType;
import org.apache.spark.sql.types.BooleanType;
import org.apache.spark.sql.types.ByteType;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DateType;
import org.apache.spark.sql.types.DecimalType;
import org.apache.spark.sql.types.DoubleType;
import org.apache.spark.sql.types.FloatType;
import org.apache.spark.sql.types.IntegerType;
import org.apache.spark.sql.types.LongType;
import org.apache.spark.sql.types.MapType;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.ShortType;
import org.apache.spark.sql.types.StringType;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.sql.types.TimestampType;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import scala.Tuple2;

public class ReadCSVFieldUsingSpark {

	private static ObjectMapper mapper = new ObjectMapper();

	public void readCSV(String path) {

		SparkSession sparkSession = SparkSession.builder().master("local[1]").appName("Read CSV").getOrCreate();
		SQLContext sqlContext = new SQLContext(sparkSession);
		Dataset<Row> csvRows = sqlContext.read().format("com.databricks.spark.csv").option("header", "true")
				.option("inferSchema", "true").option("delimiter", "|")
				.option("timestampFormat", "yyyy-MM-dd HH:mm:ss.SSSSSSSSS").load(path);

		csvRows.printSchema();
		//csvRows.show();
		/*------------------------------------<Call method For Creating Spark Schema>--------------------------------------*/
		StructType sparkSchema = createSparkSchema(csvRows);
		System.out.println("sparkSchema::=>"+sparkSchema.toString());
		
		String jsonSchema =sparkSchema.json();
		System.out.println("JsonSchema::=>"+jsonSchema);
		//System.out.println("JsonSchema::=>"+sparkSchema.json());
	}

	/*------------------------------------------<Method For creating Spark Schema>--------------------------------------------*/
	public static StructType createSparkSchema(Dataset<Row> r) {
		Row headerRow = r.head();
		return headerRow.schema();
	
		/*
		 * Tuple2<String, String>[] headerDataType = r.dtypes();
		 * StructField fields[] = new StructField[headerDataType.length];
		 * 
		 * for (int i = 0; i < fields.length; i++) { fields[i] = new
		 * StructField(headerDataType[i]._1, dataType(headerDataType[i]._2), true,
		 * Metadata.empty()); } return new StructType(fields);
		 */
	}

	/*----------------------------------------<Spark DataType For Schema>-----------------------------------------------------*/

	
	private static DataType dataType(String dataType) {
		if (dataType.equals("IntegerType"))
			return new IntegerType();
		else if (dataType.equals("StringType"))
			return new StringType();
		else if (dataType.equals("FloatType"))
			return new FloatType();
		else if (dataType.equals("LongType"))
			return new LongType();
		else if (dataType.equals("TimestampType"))
			return new TimestampType();
		else if (dataType.equals("BooleanType"))
			return new BooleanType();
		else if (dataType.equals("DoubleType"))
			return new DoubleType();
		else if (dataType.equals("DateType"))
			return new DateType();
		else if (dataType.equals("ByteType"))
			return new ByteType();
		else if (dataType.equals("BinaryType"))
			return new BinaryType();
		else if (dataType.equals("StructType"))
			return new StructType();
		else if (dataType.equals("ArrayType"))
			return new ArrayType();
		else if (dataType.equals("MapType"))
			return new MapType();
		else if (dataType.equals("DecimalType"))
			return new DecimalType();
		else if (dataType.equals("ShortType"))
			return new ShortType();
		else
			throw new IllegalArgumentException("Invalid Data Type : " + dataType);

	}

	
	/*-------------------------------------<CSV JSON Coloumn>------------------------------*/
	/*
	 * public static void csvJsonColumnOperations(Dataset<Row> csvRows) {
	 * csvRows.createOrReplaceGlobalTempView("sample"); SQLContext context =
	 * csvRows.sqlContext(); Dataset<Row> jsonCol =
	 * context.sql("select json_sample from global_temp.sample");
	 * 
	 * List<Row> row = jsonCol.collectAsList(); String result =
	 * row.get(0).getString(0);
	 * 
	 * JsonNode jsonNodeConversionOfResult = null; jsonNodeConversionOfResult =
	 * mapper.convertValue(result, JsonNode.class);
	 * System.out.println(jsonNodeConversionOfResult);
	 * 
	 * }
	 */

}
