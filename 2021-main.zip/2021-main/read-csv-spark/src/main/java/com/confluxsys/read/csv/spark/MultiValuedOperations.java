package com.confluxsys.read.csv.spark;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

public class MultiValuedOperations {
	private static ObjectMapper objectMapper = new ObjectMapper();

	public static void readCSV(String path) throws JsonMappingException, JsonProcessingException {

		SparkSession sparkSession = SparkSession.builder().master("local[1]").appName("Read CSV").getOrCreate();
		SQLContext sqlContext = new SQLContext(sparkSession);
		Dataset<Row> csvRows = sqlContext.read().format("com.databricks.spark.csv").option("header", "true")
				.option("inferSchema", "true").option("delimiter", "|")
				.option("timestampFormat", "yyyy-MM-dd HH:mm:ss.SSSSSSSSS").load(path);
		String sparkSchema = csvRows.head().schema().prettyJson();
		JsonNode jsonNode =  objectMapper.readTree(sparkSchema);
		Map<String, String> cd = getColumnNameAndDataType(jsonNode);
		
		/**
		 "Profiles": {
      "type": "array",
      "items": [
        {
          "type": "object",
          "properties": {
            "Profile": {
              "type": "string"
            }
          }
        }
      ]
    }
		 
		 
		 */
		
		
		
		

	}
	
	private static Map<String, String> getColumnNameAndDataType(JsonNode sparkSchemaAsAJsonNode) {
		Map<String, String> columnNameAndDataType = new LinkedHashMap<String, String>();
		if (sparkSchemaAsAJsonNode.get(JsonSchemaConstants.FIELDS).isArray()) {
			ArrayNode fieldsNode = (ArrayNode) sparkSchemaAsAJsonNode.get(JsonSchemaConstants.FIELDS);
			for (JsonNode fieldNode : fieldsNode) {
				String columnName = null;
				String dataType = null;
				if (fieldNode.path(JsonSchemaConstants.NAME) != null
						&& !fieldNode.path(JsonSchemaConstants.NAME).asText().isEmpty()) {
					columnName = fieldNode.path(JsonSchemaConstants.NAME).asText();
				}
				if (fieldNode.path(JsonSchemaConstants.TYPE) != null
						&& !fieldNode.path(JsonSchemaConstants.TYPE).asText().isEmpty()) {
					dataType = fieldNode.path(JsonSchemaConstants.TYPE).asText();
				}
				columnNameAndDataType.put(columnName, dataType);
			}
		}
		return columnNameAndDataType;
	}
	public static void main(String[] args) throws JsonMappingException, JsonProcessingException {
		String path = "";
		readCSV(path);
	}

}
