package com.confluxsys.iap.tools.app.onboarding.introspect;

/**
 * @author Ravi Ranjan
 * */

public interface SampleDataSource {
}
