package com.confluxsys.iap.tools.app.onboarding.introspect.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.confluxsys.iap.tools.app.onboarding.introspect.FileDataSource;
import com.confluxsys.iap.tools.app.onboarding.introspect.SampleDataReader;
import com.confluxsys.iap.tools.app.onboarding.introspect.SampleDataSource;
import com.confluxsys.iap.tools.app.onboarding.introspect.SparkSessionDataSource;

/**
 * @author Ravi Ranjan
 */

public class SampleDataReaderImpl implements SampleDataReader<SampleDataSource> {

	private static final Logger logger = LoggerFactory.getLogger(SampleDataReaderImpl.class);
	private static final String FILE_FORMAT_CSV = "com.databricks.spark.csv";
	private static final String HEADER = "header";
	private static final String INFER_SCHEMA = "inferSchema";
	private static final String DELIMITER = "delimiter";
	private static final String TIMESTAMP_FORMAT = "timestampFormat";
	private static final String TIMESTAMP_FORMAT_VALUE = "yyyy-MM-dd HH:mm:ss.SSSSSSSSS";
	private static final String TRUE = "true";
	private static final String DELIMITER_VALUE_COMMA = ",";

	@Override
	public Dataset<Row> readSampleData(SampleDataSource source) {
		logger.debug("Executing::SampleDataReaderImpl.readSampleData() method.");
		if (source == null) {
			logger.info("Please, Provide source::{}", source);
			throw new IllegalArgumentException("Please, Provide source" + source);
		}

		SparkSessionDataSource sparkSessionDataSource = new SparkSessionDataSource();
		SparkSession sparkSession = sparkSessionDataSource.getSparkSession();
		SQLContext sqlContext = new SQLContext(sparkSession);
		Dataset<Row> datasetAllRows = sqlContext.read().format(FILE_FORMAT_CSV).options(getOptionsMap())
				.load(((FileDataSource) source).getFilePath());

		logger.debug("Exit::SampleDataReaderImpl.readSampleData() method.");
		return datasetAllRows;
	}

	private static Map<String, String> getOptionsMap() {
		logger.debug("Executing::SampleDataReaderImpl.getOptionsMap() method.");
		Map<String, String> optionsMap = new HashMap<String, String>();
		optionsMap.put(HEADER, TRUE);
		optionsMap.put(INFER_SCHEMA, TRUE);
		optionsMap.put(DELIMITER, DELIMITER_VALUE_COMMA);
		optionsMap.put(TIMESTAMP_FORMAT, TIMESTAMP_FORMAT_VALUE);
		logger.debug("Exit::SampleDataReaderImpl.getOptionsMap() method.");
		return optionsMap;
	}
}
