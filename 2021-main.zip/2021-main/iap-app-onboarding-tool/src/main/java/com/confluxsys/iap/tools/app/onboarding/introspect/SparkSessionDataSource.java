package com.confluxsys.iap.tools.app.onboarding.introspect;

import org.apache.spark.sql.SparkSession;

/**
 * @author Ravi Ranjan
 * 
 * */
public class SparkSessionDataSource{

	private final SparkSession sparkSession;
	private final static String  MASTER = "local[1]";
	private final static String APP_NAME = "DefaultCSVRead";

	public SparkSessionDataSource() {
		// TODO Auto-generated constructor stub
		this.sparkSession = SparkSession.builder().master(MASTER).appName(APP_NAME).getOrCreate();
	}

	public SparkSession getSparkSession() {
		return sparkSession;
	}

}
