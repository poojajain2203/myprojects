package com.confluxsys.iap.app.onboarding.tool.cli;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.confluxsys.iap.app.onboarding.tool.parameter.AppOnboardingConfigParameter;

/**
 * @author Ravi Ranjan
 */
public class AppOnboardingParameterReader {
	private static Options options = new Options();
	private static final Logger logger = LoggerFactory.getLogger(AppOnboardingParameterReader.class);

	public static AppOnboardingConfigParameter buildAppOnboardingConfigParameter(String args[]) {
		logger.debug("Executing::AppOnboardingParameterReader.buildAppOnboardingConfigParameter() method.");
		AppOnboardingParameterReader.buildCommandlineOptions();
		if (args == null || args.length == 0) {
			printHelpMenu();
			logger.error("INVALID PARAMETERS , YOU  DIDN'T PROVIDED ANY  ARGUMENTS FOR TOOL");
			throw new IllegalArgumentException(
					"INVALID PARAMETERS. Command line argument array size : " + (args != null ? args.length : null));
		}
		AppOnboardingConfigParameter parameters = null;
		try {
			CommandLineParser parser = new DefaultParser();
			CommandLine commandLine = parser.parse(options, args);
			parameters = new AppOnboardingConfigParameter();

			if (commandLine.hasOption(AppOnboardingConfigArgumants.f.name())) {
				parameters.setCsvFilePath(commandLine.getOptionValue(AppOnboardingConfigArgumants.f.name()));
			}
			if (commandLine.hasOption(AppOnboardingConfigArgumants.a.name())) {
				parameters.setApplicationTypeName(commandLine.getOptionValue(AppOnboardingConfigArgumants.a.name()));
			}

			if (commandLine.hasOption(AppOnboardingConfigArgumants.i.name())) {
				parameters.setIsIdentifier(commandLine.getOptionValue(AppOnboardingConfigArgumants.i.name()));
			}
			if (commandLine.hasOption(AppOnboardingConfigArgumants.s.name())) {
				parameters.setIsStatus(commandLine.getOptionValue(AppOnboardingConfigArgumants.s.name()));
			}

			if (commandLine.hasOption(AppOnboardingConfigArgumants.ni.name())) {
				parameters.setIsNativeId(commandLine.getOptionValue(AppOnboardingConfigArgumants.ni.name()));
			}

			if (commandLine.hasOption(AppOnboardingConfigArgumants.na.name())) {
				parameters.setIsNameAttribute(commandLine.getOptionValue(AppOnboardingConfigArgumants.na.name()));
			}

		} catch (ParseException e) {
			printHelpMenu();
			logger.error("Error occured while parsing command line arguments.", e);
			throw new IllegalStateException("Error occured while parsing command line arguments.", e);
		}
		logger.debug("Exit::AppOnboardingParameterReader.buildAppOnboardingConfigParameter() method.");
		return parameters;
	}

	private static void buildCommandlineOptions() {
		logger.debug("Executing::AppOnboardingParameterReader.buildCommandlineOptions() method.");
		for (AppOnboardingConfigArgumants arg : AppOnboardingConfigArgumants.values()) {
			Option definitionOpt = new Option(arg.name(), arg.name(), true, arg.getDescription());
			definitionOpt.setArgName(arg.getName());
			options.addOption(definitionOpt);
		}
		logger.debug("Exit::AppOnboardingParameterReader.buildCommandlineOptions() method.");
	}

	public static void printHelpMenu() {
		logger.debug("Executing::AppOnboardingParameterReader.printHelpMenu() method.");
		HelpFormatter helpFormatter = new HelpFormatter();
		helpFormatter.setWidth(150);
		helpFormatter.printHelp("Help", "...............Please refer below menu for help option.................\n"
				+ "See required options with possible values.", options, "\nEnd of option menu...");
		logger.debug("Exit::AppOnboardingParameterReader.printHelpMenu() method.");
	}

}
