package com.confluxsys.iap.tools.app.onboarding.introspect;

/**
 * @author Ravi Ranjan
 * */

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public interface SampleDataReader <S extends SampleDataSource> {
    public Dataset<Row> readSampleData(S source);
}
