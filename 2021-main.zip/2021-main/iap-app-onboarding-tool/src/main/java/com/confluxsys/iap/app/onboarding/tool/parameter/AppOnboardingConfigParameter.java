package com.confluxsys.iap.app.onboarding.tool.parameter;

/**
 * @author Ravi Ranjan
 */

public class AppOnboardingConfigParameter {
	private String csvFilePath;
	private String applicationTypeName;
	
	//Single Valued & Multivalued Attributes For Account Entity Type Schema.
	private String isIdentifier;
	private String isStatus;
	private String isNativeId;
	private String isNameAttribute;
	
	public String getIsIdentifier() {
		return isIdentifier;
	}

	public void setIsIdentifier(String isIdentifier) {
		this.isIdentifier = isIdentifier;
	}

	public String getIsStatus() {
		return isStatus;
	}

	public void setIsStatus(String isStatus) {
		this.isStatus = isStatus;
	}

	public String getIsNativeId() {
		return isNativeId;
	}

	public void setIsNativeId(String isNativeId) {
		this.isNativeId = isNativeId;
	}

	public String getIsNameAttribute() {
		return isNameAttribute;
	}

	public void setIsNameAttribute(String isNameAttribute) {
		this.isNameAttribute = isNameAttribute;
	}

	public String getCsvFilePath() {
		return csvFilePath;
	}

	public void setCsvFilePath(String csvFilePath) {
		this.csvFilePath = csvFilePath;
	}

	public String getApplicationTypeName() {
		return applicationTypeName;
	}

	public void setApplicationTypeName(String applicationTypeName) {
		this.applicationTypeName = applicationTypeName;
	}

}
