package com.confluxsys.iap.app.onboarding.tool;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.fusesource.hawtbuf.ByteArrayInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.confluxsys.iam.adc.common.model.stage.DataClassification;
import com.confluxsys.iam.adc.common.model.stage.UploadMode;
import com.confluxsys.iam.adc.common.model.subscription.ServiceProviderRole;
import com.confluxsys.iam.adc.service.model.FileExtractionInfo;
import com.confluxsys.iap.app.onboarding.tool.cli.AppOnboardingParameterReader;
import com.confluxsys.iap.app.onboarding.tool.parameter.AppOnboardingConfigParameter;
import com.confluxsys.iap.tools.app.onboarding.introspect.FileDataSource;
import com.confluxsys.iap.tools.app.onboarding.introspect.SampleDataSource;
import com.confluxsys.iap.tools.app.onboarding.introspect.impl.DatasetRowToJsonNode;
import com.confluxsys.iap.tools.app.onboarding.introspect.util.JsonSchemaConstants;
import com.confluxsys.iap.tools.app.onboarding.introspect.util.SparkUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * @author Ravi Ranjan
 */

public class AppOnboardingTool {

	// For Client
	private static FileExtractionInfo extractInfo;
	private static EntityEnrollClientAppOnboarding enrollClientAppOnboarding;
	private static final String BASE_URI = "http://10.1.27.41:8081/iamws/adc";
	private static final String USER_NAME = "PDHARM";
	private static final String PASSWORD = "password1";
	private static final String ORG_IDENTIFIER = "Default";
	private static final String APPLICATION_IDENTIFIER = "CAMR-Application Configuration";
	private static final String ENTITY_TYPE = "Disconnected Application Type";
	private static final String SUBMITTER = "PDHARM";
	private static final String SOURCE_SYSTEM = ServiceProviderRole.Originating.name();
	private static final String DATA_CLASS = DataClassification.REPRESENTATIONAL.getValue();
	private static final String MODE = UploadMode.OFFLINE.getValue();
	private static final String SORUCE_SYSTEM_ID = "originatingService-talend";
	private static boolean SELECTED_ENTITIES = true;
	private static boolean SELECTED_ATTRIBUTES = false;
	private static String PRE_APPROVAL_INFO = null;
	private static boolean PERFORM_APPROVAL_IN_BULK = true;

	// For Tool
	private static final String PROPERTIES_FILE_PATH_KEY = "iap.app.onboarding.properties.file.path";
	private static final String CONTEXT_FILE_NAME = "app-onboarding-tool-context.xml";
	private static Logger logger = LoggerFactory.getLogger(AppOnboardingTool.class);
	private static ClassPathXmlApplicationContext applicationContext = null;
	private ObjectMapper objectMapper = new ObjectMapper();

	public static void main(String[] args) {
		logger.debug("Executing :: AppOnboardingTool.main() method");
		try {
			try {
				new AppOnboardingTool().run(args);
			} catch (IOException | AppOnboardingToolException e) {
				logger.error("App Onboarding tool execution failed.Cause : {}", e.getMessage());
				logger.error("Error occurred while executing  App Onboarding tool : {}", e);
				System.err.println(e);
			}
		} catch (URISyntaxException e) {
			logger.error("App Onboarding tool execution failed.Cause : {}", e.getMessage());
			logger.error("Error occurred while executing  App Onboarding tool : {}", e);
			System.err.println(e);
		} finally {
			if (applicationContext != null) {
				applicationContext.close();
			}
		}
		logger.debug("Exit :: AppOnboardingTool.main() method");
	}

	private void run(String[] args) throws URISyntaxException, IOException, AppOnboardingToolException {
		logger.debug("Executing :: AppOnboardingTool.run() method");
		AppOnboardingConfigParameter parameters = AppOnboardingParameterReader.buildAppOnboardingConfigParameter(args);
		logger.debug("Loading context file : {}", CONTEXT_FILE_NAME);
		applicationContext = new ClassPathXmlApplicationContext("classpath*:**/" + CONTEXT_FILE_NAME);
		FileInputStream inputStream = null;
		String propertiesFilePath = System.getProperty(PROPERTIES_FILE_PATH_KEY);
		if (propertiesFilePath == null || propertiesFilePath.isEmpty()) {
			logger.error("Properties file path is not provided.Please set propertis file path properly.");
			throw new AppOnboardingToolException(
					"Properties file path is not provided.Please set propertis file path properly.");
		}
		File file = new File(propertiesFilePath);
		if (!file.isFile() || !file.exists()) {
			logger.error("properties file doesn't exists at path : {}.", propertiesFilePath);
			throw new AppOnboardingToolException("Properties file doen't exists at path : " + propertiesFilePath);
		}
		// set properties file.
		SparkUtil sparkUtil = applicationContext.getBean(SparkUtil.class);
		Properties properties = new Properties();
		inputStream = new FileInputStream(file);
		properties.load(inputStream);
		sparkUtil.setProperties(properties);
		// Enroll Application Type.
		if (parameters.getCsvFilePath() == null || parameters.getCsvFilePath().isEmpty()) {
			logger.error("Could not find CSV file at provided location :: {}" + parameters.getCsvFilePath());
			throw new AppOnboardingToolException(
					"Could not find CSV file at provided location ::" + parameters.getCsvFilePath());
		}
		if (parameters.getApplicationTypeName() == null || parameters.getApplicationTypeName().isEmpty()) {
			logger.error("Application Type Name not null or empty :: {}" + parameters.getApplicationTypeName());
			throw new AppOnboardingToolException(
					"Application Type Name not null or empty :: " + parameters.getApplicationTypeName());
		}

		if (parameters.getIsIdentifier() == null || parameters.getIsIdentifier().isEmpty()) {
			logger.error("isIdentifier is not null or empty :: {}" + parameters.getIsIdentifier());
			throw new AppOnboardingToolException(
					"isIdentifier is not null or empty :: " + parameters.getIsIdentifier());
		}

		/**
		 * For Single Valued Attributes & MutlivaluedAttributes.
		 */

		String isIdentifier[] = parameters.getIsIdentifier().split(",");
		String isStatus[] = null;
		String isNativeId[] = null;
		String isNameAttribute[] = null;
		if (parameters.getIsStatus() != null && !parameters.getIsStatus().isEmpty()) {
			isStatus = parameters.getIsStatus().split(",");
		}
		if (parameters.getIsNativeId() != null && !parameters.getIsNativeId().isEmpty()) {
			isNativeId = parameters.getIsNativeId().split(",");
		}
		if (parameters.getIsNameAttribute() != null && !parameters.getIsNameAttribute().isEmpty()) {
			isNameAttribute = parameters.getIsNameAttribute().split(",");
		}

		/**
		 * SET the values:SparkUtil.setRequiredFieldAndExtensionfield() methods.
		 */
		sparkUtil.setRequiredFieldAndExtensionfield(isIdentifier, isStatus, isNativeId, isNameAttribute);

		SampleDataSource source = (SampleDataSource) new FileDataSource(parameters.getCsvFilePath());
		DatasetRowToJsonNode datasetRowToJsonNode = applicationContext.getBean(DatasetRowToJsonNode.class);
		JsonNode output = datasetRowToJsonNode.datasetRowToJsonNode(source);
		ObjectNode obj = ((ObjectNode) output).put(JsonSchemaConstants.APPLICATION_TYPE_NAME,
				parameters.getApplicationTypeName());
		ArrayNode applicationTypeJson = objectMapper.createArrayNode();
		applicationTypeJson.add(obj);
		System.out.println("Application Type Json Schema ::"+applicationTypeJson);
		logger.debug("Application Type Json Schema::{}", applicationTypeJson);

		List<JsonNode> nodes = objectMapper.readValue(applicationTypeJson.toString(),
				new TypeReference<List<JsonNode>>() {
				});
		String response = getEnrollApplicationTypeClient().stageBulkDataUploadV2Json(ORG_IDENTIFIER,
				APPLICATION_IDENTIFIER, SOURCE_SYSTEM, PRE_APPROVAL_INFO, DATA_CLASS, MODE, null, ENTITY_TYPE,
				SORUCE_SYSTEM_ID, SELECTED_ENTITIES, SELECTED_ATTRIBUTES, extractInfo, PERFORM_APPROVAL_IN_BULK,
				new ByteArrayInputStream(nodes.toString().getBytes()), null);
		logger.debug("Response Return By Client :: {}", response);
		logger.debug("Exit :: AppOnboardingTool.run() method");
	}

	private static EntityEnrollClientAppOnboarding getEnrollApplicationTypeClient() throws URISyntaxException {
		logger.debug("Executing :: AppOnboardingTool.getEnrollApplicationTypeClient() method");
		extractInfo = new FileExtractionInfo();
		extractInfo.setExtractedBy(SUBMITTER);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -2);
		extractInfo.setExtractTimestamp(new Date(cal.getTime().getTime()));
		extractInfo.setExtractTimestamp(new Date());

		URI baseURI = new URI(BASE_URI);
		enrollClientAppOnboarding = new EntityEnrollClientAppOnboarding(baseURI, USER_NAME, PASSWORD.toCharArray());
		logger.debug("Exit :: AppOnboardingTool.getEnrollApplicationTypeClient() method");
		return enrollClientAppOnboarding;
	}

}
