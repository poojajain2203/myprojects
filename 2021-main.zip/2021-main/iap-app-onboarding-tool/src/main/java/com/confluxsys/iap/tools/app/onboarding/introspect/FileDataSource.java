package com.confluxsys.iap.tools.app.onboarding.introspect;

/**
 * @author Ravi Ranjan
 * */

public class FileDataSource implements SampleDataSource{
    private final String filePath;

    public FileDataSource(String filePath) {
        this.filePath = filePath;
    }

	public String getFilePath() {
		return filePath;
	}
}
