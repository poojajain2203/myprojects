package com.confluxsys.iap.app.onboarding.tool;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URI;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.confluxsys.iam.adc.service.client.ADCWebserviceClient;
import com.confluxsys.iam.adc.service.model.FileExtractionInfo;
import com.confluxsys.iam.adc.service.util.ServiceConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 * @author Ravi Ranjan
 * */
public class EntityEnrollClientAppOnboarding extends ADCWebserviceClient {
	static final String STAGE_PATH = "/stage/";
	ObjectMapper mapper = new ObjectMapper();
	Logger logger;
	public EntityEnrollClientAppOnboarding(URI baseURI, String userName, char[] password) {
		super(baseURI, userName, password);
		logger = LoggerFactory.getLogger(EntityEnrollClientAppOnboarding.class);
	}

	public String stageBulkDataUploadV2Json(String orgIdentifier, String appIdentifier, String sourceSystem,
			String preApprovalInfo, String dataClass, String mode, String dataformat, String entityType,
			String sourceSystemId, boolean selectedEntities, boolean selectedAttributes, FileExtractionInfo extractInfo,
			boolean performApprovalInBulk, InputStream inputStreamData, String stageIdStr)
			throws FileNotFoundException, JsonProcessingException {

		WebTarget targetResource = webTarget.path("/v2/applications/" + appIdentifier + "/entities/bulk");

		WebTarget targetRes11 = targetResource.queryParam(ServiceConstants.OUT_OF_BAND_APPROVAL_INFO, preApprovalInfo);
		WebTarget targetRes3 = targetRes11.queryParam(ServiceConstants.SELECTED_ATTRIBUTES_FLAG, selectedAttributes);
		WebTarget targetRes9 = targetRes3.queryParam(ServiceConstants.SELECTED_ENTITIES_FLAG, selectedEntities);
		WebTarget targetRes5 = targetRes9.queryParam(ServiceConstants.DATA_FORMAT_PARAM, dataformat);
		WebTarget targetRes6 = targetRes5.queryParam(ServiceConstants.EXTRACTED_BY_PARAM, extractInfo.getExtractedBy());
		WebTarget targetRes7 = targetRes6.queryParam(ServiceConstants.ENTITY_TYPE_PARAM, entityType);
		WebTarget targetRes8 = targetRes7.queryParam(ServiceConstants.SOURCE_SYSTEM_ID, sourceSystemId);
		WebTarget targetRes12 = targetRes8.queryParam(ServiceConstants.STAGE_ID_PARAM, stageIdStr);
		WebTarget targetRes13 = targetRes12.queryParam(ServiceConstants.PERFORM_APPROVAL_IN_BULK,
				performApprovalInBulk);
		Builder builder = this.getRequestBuilder(targetRes13);

		MultivaluedMap<String, Object> headers = this.getAuthorizationHeader();
		headers.add(ServiceConstants.EXTRACTED_TIME_PARAM, extractInfo.getExtractTimestamp());
		headers.add(ServiceConstants.TENANT_ORG_ID, orgIdentifier);
		builder.headers(headers);

		Response response = builder.post(Entity.entity(inputStreamData, MediaType.APPLICATION_JSON));
		logger.debug("Reject Stage Process Response status :" + response.getStatus());
		logger.info("upload review workbook response : " + response.getStatus());
		String responseEntity = response.readEntity(String.class);
		return responseEntity;
	}
}
