package com.confluxsys.iap.tools.app.onboarding.introspect.impl;

/**
 * @author Ravi Ranjan
 * */

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.confluxsys.iap.tools.app.onboarding.introspect.SampleDataReader;
import com.confluxsys.iap.tools.app.onboarding.introspect.SampleDataSource;
import com.confluxsys.iap.tools.app.onboarding.introspect.util.SparkUtil;
import com.fasterxml.jackson.databind.JsonNode;

public class DatasetRowToJsonNode {
	private static final Logger logger = LoggerFactory.getLogger(DatasetRowToJsonNode.class);
	private SampleDataReader<SampleDataSource> sampleDataReader;

	public void setSampleDataReader(SampleDataReader<SampleDataSource> sampleDataReader) {
		this.sampleDataReader = sampleDataReader;
	}

	public JsonNode datasetRowToJsonNode(SampleDataSource sampleDataSource) {
		logger.debug("Executing::DatasetRowToJsonNode.datasetRowToJsonNode() method.");
		Dataset<Row> datasetRows = sampleDataReader.readSampleData(sampleDataSource);
		JsonNode entityTypejsonSchema = SparkUtil.getJsonSchema(datasetRows.head().schema());
		//logger.debug("EntityType JsonSchema::{}", entityTypejsonSchema);
		logger.debug("Exit::DatasetRowToJsonNode.datasetRowToJsonNode() method.");
		return entityTypejsonSchema;
	}
}
