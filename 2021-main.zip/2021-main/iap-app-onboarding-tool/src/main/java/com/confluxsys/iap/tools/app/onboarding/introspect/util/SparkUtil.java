package com.confluxsys.iap.tools.app.onboarding.introspect.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.spark.sql.types.StructType;

import com.confluxsys.util.logger.Logger;
import com.confluxsys.util.logger.LoggerFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * @author Ravi Ranjan
 */

public class SparkUtil {
	private static final Logger logger = LoggerFactory.getLogger(SparkUtil.class);
	private static final String DOT_OPERATOR = ".";
	private static final String EQUAL = "=";
	private static ObjectMapper objectMapper = new ObjectMapper();
	private static Properties properties;

	public void setProperties(Properties properties) {
		logger.debug("Executing::SparkUtil.setProperties() method");
		SparkUtil.properties = properties;
		logger.debug("Exit::SparkUtil.setProperties() method");
	}

	/**
	 * Map For setting the required Field In entity_type schema.
	 */
	private static Map<String, Boolean> requiredField = null;
	/**
	 * Map For setting the $extension Field In entity_type schema.
	 * 
	 * (FiledName,<extensionFieldKey,true>)
	 */
	private static Map<String, Map<String, Boolean>> extensionfield = null;

	public void setRequiredFieldAndExtensionfield(String[] isIdentifier, String[] isStatus, String[] isNativeId,
			String[] isNameAttribute) {
		logger.debug("Executing::SparkUtil.setRequiredFieldAndExtensionfield() method");
		if (SparkUtil.requiredField == null || SparkUtil.extensionfield == null) {
			SparkUtil.requiredField = new HashMap<String, Boolean>();
			SparkUtil.extensionfield = new HashMap<String, Map<String, Boolean>>();
		}
		for (int i = 0; i < isIdentifier.length; i++) {
			Map<String, Boolean> isIdentifierInnerMap = new HashMap<String, Boolean>();
			isIdentifierInnerMap.put(JsonSchemaConstants.IS_IDENTIFIER, true);
			SparkUtil.requiredField.put(isIdentifier[i], true);
			SparkUtil.extensionfield.put(isIdentifier[i], isIdentifierInnerMap);
		}
		if (isStatus != null && isStatus.length > 0) {
			for (int i = 0; i < isStatus.length; i++) {
				Map<String, Boolean> isStatusInnerMap = new HashMap<String, Boolean>();
				isStatusInnerMap.put(JsonSchemaConstants.IS_STATUS, true);
				if (SparkUtil.extensionfield.get(isStatus[i]) != null) {
					Map<String, Boolean> b = SparkUtil.extensionfield.get(isStatus[i]);
					b.put(JsonSchemaConstants.IS_STATUS, true);
					SparkUtil.extensionfield.put(isStatus[i], b);
				} else {
					SparkUtil.extensionfield.put(isStatus[i], isStatusInnerMap);
				}
			}

		}
		if (isNativeId != null && isNativeId.length > 0) {
			for (int i = 0; i < isNativeId.length; i++) {
				Map<String, Boolean> isNativeIdInnerMap = new HashMap<String, Boolean>();
				isNativeIdInnerMap.put(JsonSchemaConstants.IS_NATIVE_ID, true);
				if (SparkUtil.extensionfield.get(isNativeId[i]) != null) {
					Map<String, Boolean> b = SparkUtil.extensionfield.get(isNativeId[i]);
					b.put(JsonSchemaConstants.IS_NATIVE_ID, true);
					SparkUtil.extensionfield.put(isNativeId[i], b);
				} else {
					SparkUtil.extensionfield.put(isNativeId[i], isNativeIdInnerMap);
				}
			}
		}
		if (isNameAttribute != null && isNameAttribute.length > 0) {
			for (int i = 0; i < isNameAttribute.length; i++) {
				Map<String, Boolean> isNameAttributeInnerMap = new HashMap<String, Boolean>();
				isNameAttributeInnerMap.put(JsonSchemaConstants.IS_NAME_ATTRIBUTE, true);
				if (SparkUtil.extensionfield.get(isNameAttribute[i]) != null) {
					Map<String, Boolean> b = SparkUtil.extensionfield.get(isNameAttribute[i]);
					b.put(JsonSchemaConstants.IS_NAME_ATTRIBUTE, true);
					SparkUtil.extensionfield.put(isNameAttribute[i], b);
				} else {
					SparkUtil.extensionfield.put(isNameAttribute[i], isNameAttributeInnerMap);
				}

			}

		}
		logger.debug("Exit::SparkUtil.setRequiredFieldAndExtensionfield() method");
	}

	/**
	 * EntityTypeConfigurations ArrayNode.
	 */
	static ArrayNode entityTypeConfigurations = objectMapper.createArrayNode();
	/**
	 * Method To get ApplicationType JSON Schema.
	 * 
	 * @param sparkSchema
	 */

	public static JsonNode getJsonSchema(StructType sparkSchema) {
		logger.debug("Executing::SparkUtil.getJsonSchema() method");
		ObjectNode applicationTypeJson = objectMapper.createObjectNode();
		// Target System Category
		applicationTypeJson.put(JsonSchemaConstants.TARGET_SYSTEM_CATEGORY,
				JsonSchemaConstants.TARGET_SYSTEM_CATEGORY_VALUE);

		// External Systems Template Info: if any
		Map<String, JsonNode> externalSystems = getExternalSystemsSchema();
		if (externalSystems != null && !externalSystems.isEmpty()) {
			for (Map.Entry<String, JsonNode> es : externalSystems.entrySet()) {
				applicationTypeJson.set(es.getKey(), es.getValue());
			}
		}
		// Entity Types Schema:
		getEntityTypeConfigurationsArrayNode(sparkSchema);
		applicationTypeJson.set(JsonSchemaConstants.ENTITY_TYPE_CONFIGURATIONS, entityTypeConfigurations);

		logger.debug("Exit::SparkUtil.getJsonSchema() method");
		return applicationTypeJson;
	}

	/**
	 * Method: To get EntityTypeConfigurations ArrayNode.
	 * 
	 * @param sparkSchema
	 */
	private static void getEntityTypeConfigurationsArrayNode(StructType sparkScheam) {
		logger.debug("Executing::SparkUtil.getEntityTypeConfigurationsArrayNode() method");
		ObjectNode entityTypeConfigurationsJson = objectMapper.createObjectNode();
		entityTypeConfigurationsJson.put(JsonSchemaConstants.CATEGORY, JsonSchemaConstants.ACCOUNT);
		entityTypeConfigurationsJson.put(JsonSchemaConstants.NAME, JsonSchemaConstants.ACCOUNT);

		ImmutablePair<List<String>, JsonNode> pair = getJsonSchemaForEntityTypeSchema(sparkScheam);

		entityTypeConfigurationsJson.set(JsonSchemaConstants.JSON_SCHEMA, pair.getRight());
		
		//--check for relationship is exits or not.
		if (pair.getLeft() != null && !pair.getLeft().isEmpty()) {
			entityTypeConfigurationsJson.set(JsonSchemaConstants.RELATIONSHIPS,
					getJsonSchemaForRelationships(pair.getLeft()));
		}
		entityTypeConfigurations.add(entityTypeConfigurationsJson);
		logger.debug("Exit::SparkUtil.getEntityTypeConfigurationsArrayNode() method");
	}

	/**
	 * Method: To get EntityTypeSchema.
	 * 
	 * @param sparkSchema
	 */
	private static ImmutablePair<List<String>, JsonNode> getJsonSchemaForEntityTypeSchema(StructType sparkSchema) {
		logger.debug("Executing::Sparkutil.getJsonSchemaForEntityTypeSchema() method");
		// SparkSchema To JsonSchema Impl.
		String jsonString = sparkSchema.prettyJson();
		JsonNode jsonNode = null;
		try {
			jsonNode = objectMapper.readTree(jsonString);
		} catch (IOException e) {
			logger.debug("Please,Provide Correct SparkSchema::{}", e);
			throw new IllegalArgumentException("Please,Provide Correct SparkSchema::" + e);
		}
		ImmutablePair<List<String>, Map<String, String>> sparkSchemaHeaders = getColumnNameAndDataType(jsonNode);
		List<String> mutlivaluedColumn = sparkSchemaHeaders.getLeft();
		Map<String, String> columnNameAndDataType = sparkSchemaHeaders.getRight();
		// Create EntityTypeSchema RootNode For Account.
		ObjectNode rootNode = objectMapper.createObjectNode();
		rootNode.put(JsonSchemaConstants.SCHEMA, JsonSchemaConstants.SCHEMA_VALUE);
		rootNode.put(JsonSchemaConstants.TYPE, JsonSchemaConstants.TYPE_OBJECT);
		rootNode.put(JsonSchemaConstants.TITLE, JsonSchemaConstants.ACCOUNT);

		// Create Properties JsonNode & Required ArayNode:
		ObjectNode childNodePropertiesChild = objectMapper.createObjectNode();
		ArrayNode requiredNode = objectMapper.createArrayNode();
		for (Map.Entry<String, String> cd : columnNameAndDataType.entrySet()) {
			String columnName = cd.getKey();
			ObjectNode childPropeties = objectMapper.createObjectNode();
			childPropeties.put(JsonSchemaConstants.TYPE, cd.getValue());
			ObjectNode extensionNode = objectMapper.createObjectNode();
			// if any extended attributes --add here.
			if (extensionfield != null && !extensionfield.isEmpty()) {
				if (extensionfield.get(columnName) != null) {
					Map<String, Boolean> extensionMap = extensionfield.get(columnName);
					for (Map.Entry<String, Boolean> extension : extensionMap.entrySet()) {
						extensionNode.put(extension.getKey(), extension.getValue());
					}
					childPropeties.set(JsonSchemaConstants.EXTENSION, extensionNode);
				}

			}
			childNodePropertiesChild.set(columnName, childPropeties);
			// SET Required Field Values.
			if (requiredField != null && !requiredField.isEmpty()) {
				if (requiredField.get(columnName) != null && requiredField.get(columnName).booleanValue()) {
					requiredNode.add(columnName);
				}
			}
		}
		// if any multivalued attributes -- add here.
		if (mutlivaluedColumn != null && !mutlivaluedColumn.isEmpty()) {
			for (String multival : mutlivaluedColumn) {
				String key = null;
				String value = null;
				if (multival.contains(DOT_OPERATOR)) {
					String ps[] = multival.split(Pattern.quote(DOT_OPERATOR));
					key = ps[0];
					value = ps[1];
				}
				ObjectNode multivaluedJsonProperty = objectMapper.createObjectNode();
				// cretae item arrayNode:
				ArrayNode item = objectMapper.createArrayNode();
				ObjectNode itemProperitiesForJson = objectMapper.createObjectNode();
				// --add item keys values here
				itemProperitiesForJson.put(JsonSchemaConstants.TYPE, JsonSchemaConstants.TYPE_OBJECT);
				// add properties in item.
				ObjectNode itemProperties = objectMapper.createObjectNode();
				ObjectNode multivalueColumnProperty = objectMapper.createObjectNode();
				multivalueColumnProperty.put(JsonSchemaConstants.TYPE, JsonSchemaConstants.TYPE_STRING);
				// $extension field --create new node:
				ObjectNode extensionNodeForMutliValued = objectMapper.createObjectNode();

				// here add extension to multivalueColumnProperty
				if (extensionfield != null && !extensionfield.isEmpty()) {
					if (extensionfield.get(value) != null) {
						Map<String, Boolean> extensionMap = extensionfield.get(value);
						for (Map.Entry<String, Boolean> extension : extensionMap.entrySet()) {
							extensionNodeForMutliValued.put(extension.getKey(), extension.getValue());
						}
						multivalueColumnProperty.set(JsonSchemaConstants.EXTENSION, extensionNodeForMutliValued);
					}
				}

				itemProperties.set(value, multivalueColumnProperty);
				itemProperitiesForJson.set(JsonSchemaConstants.PROPERTIES, itemProperties);

				// add type = array.
				multivaluedJsonProperty.put(JsonSchemaConstants.TYPE, JsonSchemaConstants.TYPE_ARRAY);
				// add item.
				item.add(itemProperitiesForJson);
				multivaluedJsonProperty.set(JsonSchemaConstants.ITEMS, item);

				// add multivalued Required Field.
				ArrayNode multiValuedRequiredNode = objectMapper.createArrayNode();
				if (requiredField != null && !requiredField.isEmpty()) {
					if (requiredField.get(value) != null && requiredField.get(value).booleanValue()) {
						multiValuedRequiredNode.add(value);
					}
				}
				if (requiredField != null && !requiredField.isEmpty() && requiredField.get(value) != null) {
					itemProperitiesForJson.set(JsonSchemaConstants.REQUIRED, multiValuedRequiredNode);
				}

				childNodePropertiesChild.set(key, multivaluedJsonProperty);
				// Method CALL: For Build Entity Type Schema(Entitlement).Roles/Profile etc.
				buildEntityTypeSchema(key, value);
			}
		}

		// Add properties JsonNode To Root EntityTypeSchema.
		if (childNodePropertiesChild != null) {
			rootNode.set(JsonSchemaConstants.PROPERTIES, childNodePropertiesChild);
		}
		// Add required ArrayNode To Root EntityTypeSchema.
		if (requiredField != null && !requiredField.isEmpty() && requiredNode.size() != 0) {
			rootNode.set(JsonSchemaConstants.REQUIRED, requiredNode);
		}
		logger.debug("Exit::Sparkutil.getJsonSchemaForEntityTypeSchema() method");
		return new ImmutablePair<List<String>, JsonNode>(mutlivaluedColumn, (JsonNode) rootNode);
	}

	/**
	 * Method For Build EntityType Schema For Entitlements.
	 * 
	 * @param key   Ex: Profiles/Roles
	 * @param value Ex: PROFILE/ROLE
	 */

	private static void buildEntityTypeSchema(String key, String value) {
		logger.debug("Executing::SpakUtil.buildEntityTypeSchema() method");
		ObjectNode schema = objectMapper.createObjectNode();
		schema.put(JsonSchemaConstants.CATEGORY, JsonSchemaConstants.ENTITLEMENT);
		schema.put(JsonSchemaConstants.NAME, key);
		ObjectNode rootNode = objectMapper.createObjectNode();
		rootNode.put(JsonSchemaConstants.SCHEMA, JsonSchemaConstants.SCHEMA_VALUE);
		rootNode.put(JsonSchemaConstants.TYPE, JsonSchemaConstants.TYPE_OBJECT);
		rootNode.put(JsonSchemaConstants.TITLE, key);

		ObjectNode childNodePropertiesChild = objectMapper.createObjectNode();
		ArrayNode requiredNode = objectMapper.createArrayNode();
		ObjectNode childPropeties = objectMapper.createObjectNode();
		childPropeties.put(JsonSchemaConstants.TYPE, JsonSchemaConstants.TYPE_STRING);
		// $extension attribute.
		ObjectNode extension = objectMapper.createObjectNode();
		extension.put(JsonSchemaConstants.IS_IDENTIFIER, true);
		extension.put(JsonSchemaConstants.IS_NATIVE_ID, true);
		childPropeties.set(JsonSchemaConstants.EXTENSION, extension);

		childNodePropertiesChild.set(value, childPropeties);
		requiredNode.add(value);

		if (childNodePropertiesChild != null) {
			rootNode.set(JsonSchemaConstants.PROPERTIES, childNodePropertiesChild);
		}
		// Add required ArrayNode To Root EntityTypeSchema.
		if (requiredField != null && !requiredField.isEmpty() && requiredNode.size() != 0) {
			rootNode.set(JsonSchemaConstants.REQUIRED, requiredNode);
		}
		schema.set(JsonSchemaConstants.JSON_SCHEMA, rootNode);
		entityTypeConfigurations.add(schema);
		logger.debug("Exit::SpakUtil.buildEntityTypeSchema() method");
	}

	/**
	 * Method To GET MultiValued ColumnName & Map Of <SingleValueColumnName,
	 * DataType>
	 * 
	 * @param sparkSchemaAsAJsonNode
	 * @return
	 */
	private static ImmutablePair<List<String>, Map<String, String>> getColumnNameAndDataType(
			JsonNode sparkSchemaAsAJsonNode) {
		logger.debug("Executing::Sparkutil.getColumnNameAndDataType() method");
		Map<String, String> singleValuedAttriburecolumnNameAndDataType = new LinkedHashMap<String, String>();
		List<String> multiValuedAttributes = new ArrayList<>();
		if (sparkSchemaAsAJsonNode.get(JsonSchemaConstants.FIELDS).isArray()) {
			ArrayNode fieldsNode = (ArrayNode) sparkSchemaAsAJsonNode.get(JsonSchemaConstants.FIELDS);
			for (JsonNode fieldNode : fieldsNode) {
				String columnName = null;
				String dataType = null;
				if (fieldNode.path(JsonSchemaConstants.CSV_NAME) != null
						&& !fieldNode.path(JsonSchemaConstants.CSV_NAME).asText().isEmpty()) {
					columnName = fieldNode.path(JsonSchemaConstants.CSV_NAME).asText();
				}
				if (fieldNode.path(JsonSchemaConstants.CSV_TYPE) != null
						&& !fieldNode.path(JsonSchemaConstants.CSV_TYPE).asText().isEmpty()) {
					dataType = fieldNode.path(JsonSchemaConstants.CSV_TYPE).asText();
				}
				if (!columnName.contains(DOT_OPERATOR)) {
					singleValuedAttriburecolumnNameAndDataType.put(columnName, dataType);
				} else {
					multiValuedAttributes.add(columnName);
				}
			}
		}
		logger.debug("Exit::Sparkutil.getColumnNameAndDataType() method");
		return new ImmutablePair<List<String>, Map<String, String>>(multiValuedAttributes,
				singleValuedAttriburecolumnNameAndDataType);
	}

	/**
	 * Method To GET Relationships Configurations For Entity Type Schema.
	 * 
	 * @param multivaluedAttributes
	 * @return
	 */

	private static JsonNode getJsonSchemaForRelationships(List<String> multivaluedAttributes) {
		logger.debug("Executing::Sparkutil.getJsonSchemaForRelationships() method");
		// Roles.ROLE
		ObjectNode relationConfigObject = objectMapper.createObjectNode();
		Map<String, String> map = new HashMap<String, String>();
		for (String multiValueAttribute : multivaluedAttributes) {
			String[] splitedValue = multiValueAttribute.split(Pattern.quote(DOT_OPERATOR));
			map.put(splitedValue[0], splitedValue[1]);
		}
		for (Map.Entry<String, String> entry : map.entrySet()) {
			ArrayNode mappingArray = objectMapper.createArrayNode();
			ObjectNode domainObject = objectMapper.createObjectNode();
			ObjectNode mappingObject = objectMapper.createObjectNode();
			String domain = JsonSchemaConstants.DOMAIN_ATTR_PREFIX + entry.getKey() + "/" + entry.getValue();
			domainObject.put(JsonSchemaConstants.JSON_LOGIC_VAR_OP, domain);

			ObjectNode rangeObject = objectMapper.createObjectNode();
			String range = JsonSchemaConstants.RANGE_ATTR_PREFIX + JsonSchemaConstants.$IDENTIFIER;
			rangeObject.put(JsonSchemaConstants.JSON_LOGIC_VAR_OP, range);
			mappingArray.add(domainObject);
			mappingArray.add(rangeObject);
			mappingObject.set(JsonSchemaConstants.JSON_LOGIC_TRIPPEL_EQUALS_TO_OP, mappingArray);
			ObjectNode entityTypeObject = objectMapper.createObjectNode();
			entityTypeObject.put(JsonSchemaConstants.RELATED_ENTITY_TYPE_NAME, entry.getKey());
			entityTypeObject.set(JsonSchemaConstants.MATCHING_RULE, mappingObject);
			entityTypeObject.put(JsonSchemaConstants.RELATIONSHIP_CATEGORY, "Account_Entitlement");
			relationConfigObject.set(entry.getKey(), entityTypeObject);
		}
		logger.debug("Exit::Sparkutil.getJsonSchemaForRelationships() method");
		return (JsonNode) getActorRelationship(relationConfigObject);

	}

	/**
	 * Method To GET Actor Relationship
	 * 
	 * @param relationConfigObject
	 * @return
	 */

	private static JsonNode getActorRelationship(ObjectNode relationConfigObject) {
		logger.debug("Executing::Sparkutil.getActorRelationship() method");
		if ((properties.getProperty(JsonSchemaConstants.DOMAIN_ACTOR) != null
				&& !properties.getProperty(JsonSchemaConstants.DOMAIN_ACTOR).toString().isEmpty())
				&& (properties.getProperty(JsonSchemaConstants.RANGE_ACTOR) != null
						&& !properties.getProperty(JsonSchemaConstants.RANGE_ACTOR).toString().isEmpty())) {
			ArrayNode mappingArray = objectMapper.createArrayNode();
			ObjectNode domainObject = objectMapper.createObjectNode();
			ObjectNode mappingObject = objectMapper.createObjectNode();
			String domain = JsonSchemaConstants.DOMAIN_ATTR_PREFIX
					+ properties.getProperty(JsonSchemaConstants.DOMAIN_ACTOR);
			domainObject.put(JsonSchemaConstants.JSON_LOGIC_VAR_OP, domain);
			ObjectNode rangeObject = objectMapper.createObjectNode();
			String range = JsonSchemaConstants.RANGE_ATTR_PREFIX
					+ properties.getProperty(JsonSchemaConstants.RANGE_ACTOR);
			rangeObject.put(JsonSchemaConstants.JSON_LOGIC_VAR_OP, range);
			mappingArray.add(domainObject);
			mappingArray.add(rangeObject);
			ObjectNode entityTypeObject = objectMapper.createObjectNode();
			mappingObject.set(JsonSchemaConstants.JSON_LOGIC_TRIPPEL_EQUALS_TO_OP, mappingArray);
			entityTypeObject.put(JsonSchemaConstants.RELATED_ENTITY_TYPE_NAME, "Identity");
			entityTypeObject.put(JsonSchemaConstants.RELATED_ENTITY_APPLICATION_ID, "CAMR-Identity");
			entityTypeObject.put(JsonSchemaConstants.RELATED_ENTITY_APPLICATION_TYPE, "Identity");
			entityTypeObject.set(JsonSchemaConstants.MATCHING_RULE, mappingObject);
			entityTypeObject.put(JsonSchemaConstants.RELATIONSHIP_CATEGORY, "Entity_Actor");
			relationConfigObject.set(JsonSchemaConstants.OWNER, entityTypeObject);
			return relationConfigObject;
		}
		logger.debug("Exit::Sparkutil.getActorRelationship() method");
		return (JsonNode) relationConfigObject;
	}

	/**
	 * Method To get External Systems Template Info. 
	 * Map<String,JsonNode> : (SailPoint,SailPointSchema)
	 * 
	 * @return
	 */
	private static Map<String, JsonNode> getExternalSystemsSchema() {
		logger.debug("Executing::Sparkutil.getExternalSystemsSchema() method");
		String externalSystemTemplateInfo = properties
				.getProperty(JsonSchemaConstants.EXTERNAL_SYSTEM_TEMPLATE_INFO) != null
						? properties.getProperty(JsonSchemaConstants.EXTERNAL_SYSTEM_TEMPLATE_INFO)
						: null;
		ObjectNode sailpointSchema = null;
		Map<String, JsonNode> externalSystem = new HashMap<String, JsonNode>();
		if (externalSystemTemplateInfo != null && !externalSystemTemplateInfo.isEmpty()) {
			String[] externalSystemTemplateInfoValues = externalSystemTemplateInfo.split(EQUAL);
			sailpointSchema = objectMapper.createObjectNode();
			sailpointSchema.put(JsonSchemaConstants.TEMPLATE, externalSystemTemplateInfoValues[1]);
			externalSystem.put(externalSystemTemplateInfoValues[0], sailpointSchema);
		}
		logger.debug("Exit::Sparkutil.getExternalSystemsSchema() method");
		return externalSystem;
	}
}
