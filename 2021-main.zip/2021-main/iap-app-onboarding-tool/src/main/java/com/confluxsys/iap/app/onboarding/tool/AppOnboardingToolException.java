package com.confluxsys.iap.app.onboarding.tool;

/**
 * @author Ravi Ranjan
 */
public class AppOnboardingToolException extends Exception {

	/**
	 * AppOnboardingToolException
	 */
	private static final long serialVersionUID = 1L;

	public AppOnboardingToolException(String message) {
		super(message);
	}

	public AppOnboardingToolException(String message, Exception e) {
		super(message, e);
	}

}
