package com.confluxsys.iap.tools.app.onboarding.introspect.util;

/**
 * @author Ravi Ranjan
 * */

public class JsonSchemaConstants {
	
	/**
	 * JSONSchema Constants.
	 * */
	
	public static final String SCHEMA = "$schema";
	public static final String SCHEMA_VALUE = "http://json-schema.org/draft-07/schema#";
	public static final String TITLE = "title";
	public static final String TYPE = "type";
	public static final String PROPERTIES = "properties";
	//public static final String NAME = "name";
	public static final String CSV_NAME = "name";
	public static final String CSV_TYPE = "type";
	public static final String NAME = "Entity Type Name";
	public static final String FIELDS = "fields";
	public static final String ITEMS = "items";
	public static final String REQUIRED = "required";
	
	public static final String EXTENSION = "$extension";
	//$extension values.
	public static final String IS_IDENTIFIER = "isIdentifier";
	public static final String IS_NAME_ATTRIBUTE = "isNameAttribute";
	public static final String IS_NATIVE_ID = "isNativeId";
	public static final String IS_STATUS = "isStatus";
	
	
	
	//JSON_SCHEMA TYPE
	public static final String TYPE_OBJECT = "object";
	public static final String TYPE_ARRAY = "array";
	public static final String TYPE_STRING = "string";
	public static final String TYPE_BOOLEAN= "boolean";
	
	//externalSystemArtifactTypes
	public static final String EXTERNAL_SYSTEM_ARTIFACT_TYPES = "externalSystemArtifactTypes";
	public static final String SAILPOINT ="Sailpoint";
	public static final String IAP="IAP";
	public static final String OIM = "OIM";
	public static final String ARTIFACT_CATEGORY = "artifactCategory";
	public static final String ARTIFACT_TYPE_NAME = "artifactTypeName";
	public static final String TARGET_ADDITIONAL_INFO = "targetAdditionalInfo";
	public static final String PURPOSE= "purpose";
	public static final String SCHEMA_MAPPING  = "schemaMapping";
	
	//entityTypeConfigurations
	//public static final String CATEGORY = "category";
	public static final String CATEGORY = "Category";
	//public static final String JSON_SCHEMA = "jsonSchema";
	public static final String JSON_SCHEMA = "Schema";
	public static final String ACCOUNT = "Account";
	public static final String ENTITLEMENT = "Entitlement";
	public static final String RELATIONSHIP_CONFIGURATIONS = "relationshipConfigurations";
	
	//ApplicationType
	//public static final String TARGET_SYSTEM_CATEGORY  = "targetSystemCategory";
	public static final String TARGET_SYSTEM_CATEGORY  = "Target System Category";
	public static final String TARGET_SYSTEM_CATEGORY_VALUE  = "Business Application";
	//public static final String ENTITY_TYPE_CONFIGURATIONS = "entityTypeConfigurations";
	public static final String ENTITY_TYPE_CONFIGURATIONS = "Entity Types";
	public static final String RESOURCE = "Resource";
	public static final String APPLICATION_TYPE_NAME = "Application Type Name";
	public static final String DESCRIPTION = "Description";
	
	
	//RELATIONSHIPS.
	public static final String RELATIONSHIPS = "Relationships";
	public static final String RELATIONSHIP_CATEGORY = "Relationship Category";
	public static final String RELATED_ENTITY_TYPE_NAME = "Related Entity Type Name";
	public static final String RELATED_ENTITY_APPLICATION_ID = "Related Entity Application Id";
	public static final String RELATED_ENTITY_APPLICATION_TYPE = "Related Entity Application Type";
	public static final String MATCHING_RULE = "Matching Rule";
	public static final String JSON_LOGIC_TRIPPEL_EQUALS_TO_OP = "===";
	public static final String JSON_LOGIC_DUAL_EQUALS_TO_OP = "==";
	public static final String JSON_LOGIC_VAR_OP = "var";
	public static final String DOMAIN_ATTR_PREFIX = "domain@";
	public static final String RANGE_ATTR_PREFIX = "range@";
	public static final String $IDENTIFIER = "$identifier";
	public static final String OWNER = "Owner";
	public static final String DOMAIN_ACTOR  = "DomainActor";
	public static final String RANGE_ACTOR = "RangeActor";
	
	//Sailpoint	
	public static final String TEMPLATE = "Template";
	public static final String TEMPLATE_VALUE  = "Disconnected Salesforce Template";
	public static final String OPERATIONS = "Operations";
	public static final String ENTITY_TYPE_NAME = "Entity Type Name";
	public static final String OPERATION_NAME = "Operation Name";
	public static final String UPDATE = "Update";
	public static final String CREATE = "Create";
	public static final String EXTERNAL_SYSTEM_TEMPLATE_INFO = "External_Systems_Template_Info";
	
	

}
