package com.confluxsys.iap.app.onboarding.tool.cli;

/**
 * @author Ravi Ranjan
 */
public enum AppOnboardingConfigArgumants {
	f("f", "CSV File Path Input", true), a("a", "Application Type Name Input", true),
	i("i", "isIdentifier Column Names", true), s("s", "isStatus Column Names", false),
	ni("ni", "isNativeId Column Names", false), na("na", "isNameAttribute Column Names", false);

	private String name;
	private String description;
	private boolean requried;

	AppOnboardingConfigArgumants(String name, String description, boolean requried) {
		this.name = name;
		this.description = description;
		this.requried = requried;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public boolean isRequried() {
		return requried;
	}

}
