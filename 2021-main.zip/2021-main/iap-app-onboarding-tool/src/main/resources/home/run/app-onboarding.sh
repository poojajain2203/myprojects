#invoke  JAVA_HOME

IAP_APP_ONBOARDING_TOOL_CLASSPATH=./lib/iap-app-onboarding-tool-jar-with-dependencies.jar
java -cp $IAP_APP_ONBOARDING_TOOL_CLASSPATH -Dlogback.configurationFile=./conf/logback.xml -Diap.app.onboarding.properties.file.path=./conf/app-onboarding.properties com.confluxsys.iap.app.onboarding.tool.AppOnboardingTool "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "${10}" "${11}" "${12}"  