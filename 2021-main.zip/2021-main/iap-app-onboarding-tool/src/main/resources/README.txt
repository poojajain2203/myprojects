#Tool Command

./app-onboarding.sh -f "C:\Users\Ravi Ranjan\Practice\iap-app-onboarding-tool\src\test\resources\account_with_role.csv_DEFAULT" -a "my app type" -i "Account ID,ROLE" -ni "Account ID" -s "Status" -na "Account ID"
