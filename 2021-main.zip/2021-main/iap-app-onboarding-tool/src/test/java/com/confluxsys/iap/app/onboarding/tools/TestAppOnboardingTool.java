package com.confluxsys.iap.app.onboarding.tools;

import java.net.URISyntaxException;

import org.apache.commons.cli.UnrecognizedOptionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.confluxsys.iap.app.onboarding.tool.AppOnboardingTool;
import com.confluxsys.iap.app.onboarding.tool.AppOnboardingToolException;
/**
 * @author Ravi Ranjan
 * */

public class TestAppOnboardingTool {
	/**
	 * END TO END AppOnboarding Tool Testing.
	 * 
	 * */
	private Logger logger;
	@BeforeMethod
	public void init() throws URISyntaxException {
		logger = LoggerFactory.getLogger(TestAppOnboardingTool.class);
	
	}
	
	/**
	 * Application Onboarding Command Line Tool Options:
	 *  -f : "CSV FILE PATH" (Required Field)
	 *  -a : "APPLICATION TYPE NAME" (Required Field)
	 *  -i : "isIdentifier column values separated by comma for single valued Attributes & Multi valued Attributes" (Required Field)
	 *  -s : "isStatus column values separated by comma for single valued Attributes & Multi valued Attributes" (Not Required Field)
	 *  -ni : "isNativeId column values separated by comma for single valued Attributes & Multi valued Attributes" (Not Required Field)
	 *  -na : "isNativeStatus column values separated by comma for single valued Attributes & Multi valued Attributes" (Not Required Field) 
	 *  
	 * Application Onboarding Properties File For Actor->Owner:
	 *  DomainActor :  For Actor->Owner Relationship Domain Matching Rule. 
	 *  RangeActor  :  For Actor->Owner Relationship Range Matching Rule.
	 * Application Onboarding Properties File External Systems Template Info
	     External_Systems_Template_Info : Sailpoint=Finance Generic Application Type 
	 * */
	
	
	@Test(description = "test for application type schema when all options are given in command line tool & properties file attributes also given.")
	public void testWhenAllOptionsAreGivenWithPropertiesFile() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenAllOptionsAreGivenWithPropertiesFile() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID,ROLE",
				"-s","Status",
				"-ni","Account ID",
				"-na","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenAllOptionsAreGivenWithPropertiesFile() method");
		
		/**
		 * O/P:
		 * [{"Target System Category":"Business Application","Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true,"isNameAttribute":true,"isNativeId":true}},"Status":{"type":"string","$extension":{"isStatus":true}},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true}}},"required":["ROLE"]}]}},"required":["Account ID"]},"Relationships":{"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"},"Owner":{"Related Entity Type Name":"Identity","Related Entity Application Id":"CAMR-Identity","Related Entity Application Type":"Identity","Matching Rule":{"===":[{"var":"domain@Account Login"},{"var":"range@User Login"}]},"Relationship Category":"Entity_Actor"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	@Test(description = "test for application type schema when required options are given in command line tool & properties file attributes also given.")
	public void testWhenOnlyRequriedOptionsAreGivenWithPropertiesFile() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenOnlyRequriedOptionsAreGivenWithPropertiesFile() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID,ROLE"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenOnlyRequriedOptionsAreGivenWithPropertiesFile() method");
		
		/**
		 * O/P:
		 * [{"Target System Category":"Business Application","Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true}},"Status":{"type":"string"},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true}}},"required":["ROLE"]}]}},"required":["Account ID"]},"Relationships":{"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"},"Owner":{"Related Entity Type Name":"Identity","Related Entity Application Id":"CAMR-Identity","Related Entity Application Type":"Identity","Matching Rule":{"===":[{"var":"domain@Account Login"},{"var":"range@User Login"}]},"Relationship Category":"Entity_Actor"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	@Test(description = "test for application type schema when all required options are given & isStatus options is also given in command line tool & properties file attributes also given.")
	public void testWhenAllRequiredOptionsAreGivenWithIsStatusAndWithPropertiesFile() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithIsStatusAndWithPropertiesFile() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID,ROLE",
				"-s","Status"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithIsStatusAndWithPropertiesFile() method");
		
		/**
		 * O/P:
		 *[{"Target System Category":"Business Application","Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true}},"Status":{"type":"string","$extension":{"isStatus":true}},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true}}},"required":["ROLE"]}]}},"required":["Account ID"]},"Relationships":{"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"},"Owner":{"Related Entity Type Name":"Identity","Related Entity Application Id":"CAMR-Identity","Related Entity Application Type":"Identity","Matching Rule":{"===":[{"var":"domain@Account Login"},{"var":"range@User Login"}]},"Relationship Category":"Entity_Actor"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	
	@Test(description = "test for application type schema when all required options are given & isNativeId options is also given in command line tool & properties file attributes also given.")
	public void testWhenAllRequiredOptionsAreGivenWithIsNativeIdAndWithPropertiesFile() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithIsNativeIdAndWithPropertiesFile() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID,ROLE",
				"-ni","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithIsNativeIdAndWithPropertiesFile() method");
		
		/**
		 * O/P:
		 *[{"Target System Category":"Business Application","Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}},"Status":{"type":"string"},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true}}},"required":["ROLE"]}]}},"required":["Account ID"]},"Relationships":{"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"},"Owner":{"Related Entity Type Name":"Identity","Related Entity Application Id":"CAMR-Identity","Related Entity Application Type":"Identity","Matching Rule":{"===":[{"var":"domain@Account Login"},{"var":"range@User Login"}]},"Relationship Category":"Entity_Actor"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	@Test(description = "test for application type schema when all required options are given & isNameAttributes options is also given in command line tool & properties file attributes also given.")
	public void testWhenAllRequiredOptionsAreGivenWithIsNameAttributesAndWithPropertiesFile() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithIsNameAttributesAndWithPropertiesFile() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID,ROLE",
				"-na","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithIsNameAttributesAndWithPropertiesFile() method");
		
		/**
		 * O/P:
		 *[{"Target System Category":"Business Application","Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true,"isNameAttribute":true}},"Status":{"type":"string"},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true}}},"required":["ROLE"]}]}},"required":["Account ID"]},"Relationships":{"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"},"Owner":{"Related Entity Type Name":"Identity","Related Entity Application Id":"CAMR-Identity","Related Entity Application Type":"Identity","Matching Rule":{"===":[{"var":"domain@Account Login"},{"var":"range@User Login"}]},"Relationship Category":"Entity_Actor"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	@Test(description = "test for application type schema when all required options are given and extended attributes only for single valued attributes is also given in command line tool & properties file attributes also given.")
	public void testWhenAllRequiredOptionsAreGivenWithPropertiesFile() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithPropertiesFile() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithPropertiesFile() method");
		
		/**
		 * O/P:
		 *[{"Target System Category":"Business Application","Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true}},"Status":{"type":"string"},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string"}}}]}},"required":["Account ID"]},"Relationships":{"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"},"Owner":{"Related Entity Type Name":"Identity","Related Entity Application Id":"CAMR-Identity","Related Entity Application Type":"Identity","Matching Rule":{"===":[{"var":"domain@Account Login"},{"var":"range@User Login"}]},"Relationship Category":"Entity_Actor"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	
	@Test(description = "test for application type schema when all required options are given and extended attributes only for single valued attributes is also given in command line tool & properties file attributes is not given.")
	public void testWhenAllRequiredOptionsAreGivenWithOutPropertiesFileKeys() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithOutPropertiesFile() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding2.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenAllRequiredOptionsAreGivenWithOutPropertiesFile() method");
		
		/**
		 * O/P:
		 *[{"Target System Category":"Business Application","Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true}},"Status":{"type":"string"},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string"}}}]}},"required":["Account ID"]},"Relationships":{"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	
	@Test(expectedExceptions = AppOnboardingToolException.class, description = "test for application type schema when  required options csv file path is missing command line tool & properties file attributes is not given.")
	public void testWhenRequiredOptionsAreMissingWithPropertiesFile() throws AppOnboardingToolException {
		logger.debug("Executing::TestAppOnboardingTool.testWhenRequiredOptionsAreMissingWithPropertiesFile() method");
		System.setProperty("iap.app.onboarding.properties.file.path",
				"../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = { "-a", "new app type", "-i", "Account ID" };
		AppOnboardingTool.main(args);
		try {
			throw new AppOnboardingToolException("Expected Exception");
		} finally {
			logger.debug("Exit::TestAppOnboardingTool.testWhenRequiredOptionsAreMissingWithPropertiesFile() method");
		}
	}
	
	
	@Test(expectedExceptions = AppOnboardingToolException.class, description = "test for application type schema when  required options application type name  is missing command line tool & properties file attributes is not given.")
	public void testWhenRequiredOptionsAreMissingWithPropertiesFile2() throws AppOnboardingToolException {
		logger.debug("Executing::TestAppOnboardingTool.testWhenRequiredOptionsAreMissingWithPropertiesFile2() method");
		System.setProperty("iap.app.onboarding.properties.file.path",
				"../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = { 
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-i", "Account ID" 
				};
		AppOnboardingTool.main(args);
		try {
			throw new AppOnboardingToolException("Expected Exception");
		} finally {
			logger.debug("Exit::TestAppOnboardingTool.testWhenRequiredOptionsAreMissingWithPropertiesFile2() method");
		}
	}
	
	@Test(expectedExceptions = AppOnboardingToolException.class, description = "test for application type schema when  required options isIdentifier option  is missing command line tool & properties file attributes is not given.")
	public void testWhenRequiredOptionsAreMissingWithPropertiesFile3() throws AppOnboardingToolException {
		logger.debug("Executing::TestAppOnboardingTool.testWhenRequiredOptionsAreMissingWithPropertiesFile3() method");
		System.setProperty("iap.app.onboarding.properties.file.path",
				"../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = { 
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type"
				};
		AppOnboardingTool.main(args);
		try {
			throw new AppOnboardingToolException("Expected Exception");
		} finally {
			logger.debug("Exit::TestAppOnboardingTool.testWhenRequiredOptionsAreMissingWithPropertiesFile3() method");
		}
	}
	
	
	@Test(description = "test for application type schema when invalid option is provided.",expectedExceptions = {UnrecognizedOptionException.class,IllegalStateException.class})
	public void testWhenInvalidOptionsProvided() throws IllegalStateException,UnrecognizedOptionException {
		logger.debug("Executing::TestAppOnboardingTool.testWhenRequiredOptionsAreMissingWithPropertiesFile3() method");
		System.setProperty("iap.app.onboarding.properties.file.path",
				"../iap-app-onboarding-tool/src/test/resources/app-onboarding.properties");
		String args[] = { 
				"-j","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i" ,"my applicaion type"
				};
		AppOnboardingTool.main(args);
	}
	
	
	
	@Test(description = "test for application type schema when actor->Owner relationship is not given in properties file.")
	public void testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFile() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFile() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding2.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID,ROLE",
				"-s","Status",
				"-ni","Account ID",
				"-na","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFile() method");
		
		/**
		 * O/P:
		 * [{"Target System Category":"Business Application","Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true,"isNameAttribute":true,"isNativeId":true}},"Status":{"type":"string","$extension":{"isStatus":true}},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true}}},"required":["ROLE"]}]}},"required":["Account ID"]},"Relationships":{"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	@Test(description = "test for application type schema when actor->Owner relationship is not given in properties file.")
	public void testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFileAndCSVHasNoEntitlements() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFileAndCSVHasNoEntitlements() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding2.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID",
				"-s","Status",
				"-ni","Account ID",
				"-na","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFileAndCSVHasNoEntitlements() method");
		
		/**
		 * O/P:
		 * [{"Target System Category":"Business Application","Entity Types":[{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true,"isNameAttribute":true,"isNativeId":true}},"Status":{"type":"string","$extension":{"isStatus":true}},"Account Login":{"type":"string"}},"required":["Account ID"]}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	@Test(description = "test for application type schema when actor->Owner relationship is not given in properties file and sailpoint property is given.")
	public void testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFileAndCSVHasNoEntitlementsAndSailpointPropertyConfigure() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFileAndCSVHasNoEntitlementsAndSailpointPropertyConfigure() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding4.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID",
				"-s","Status",
				"-ni","Account ID",
				"-na","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFileAndCSVHasNoEntitlementsAndSailpointPropertyConfigure() method");
		
		/**
		 * O/P:
		 *[{"Target System Category":"Business Application","Sailpoint":{"Template":"Finance Generic Application Type"},"Entity Types":[{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true,"isNameAttribute":true,"isNativeId":true}},"Status":{"type":"string","$extension":{"isStatus":true}},"Account Login":{"type":"string"}},"required":["Account ID"]}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	@Test(description = "test for application type schema when actor->Owner relationship is not given in properties file and sailpoint property is given.")
	public void testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFileAndSailpointPropertyConfigure() {
		logger.debug("Executing::TestAppOnboardingTool.testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFileAndSailpointPropertyConfigure() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding4.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/account_with_role.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID,ROLE",
				"-s","Status",
				"-ni","Account ID",
				"-na","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testWhenOwnerToActorRelationShipIsNotConfigureInPropertiesFileAndSailpointPropertyConfigure() method");
		
		/**
		 * O/P:
		 *[{"Target System Category":"Business Application","Sailpoint":{"Template":"Finance Generic Application Type"},"Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true,"isNameAttribute":true,"isNativeId":true}},"Status":{"type":"string","$extension":{"isStatus":true}},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true}}},"required":["ROLE"]}]}},"required":["Account ID"]},"Relationships":{"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	@Test(description = "test for multiple entitlements when all the configurtion supported to command line & properties file.")
	public void testMultipleEntitlementsCSV() {
		logger.debug("Executing::TestAppOnboardingTool.testMultipleEntitlementsCSV() method");
		System.setProperty("iap.app.onboarding.properties.file.path", "../iap-app-onboarding-tool/src/test/resources/app-onboarding3.properties");
		String args[] = {
				"-f","../iap-app-onboarding-tool/src/test/resources/csv_with_three_entitlement.csv_DEFAULT",
				"-a","new app type",
				"-i","Account ID,ROLE,GROUP,PROFILE",
				"-s","Status",
				"-ni","Account ID",
				"-na","Account ID"
		};
		AppOnboardingTool.main(args);
		logger.debug("Exit::TestAppOnboardingTool.testMultipleEntitlementsCSV() method");
		
		/**
		 * O/P:
		 *[{"Target System Category":"Business Application","Sailpoint":{"Template":"Finance Generic Application Type"},"Entity Types":[{"Category":"Entitlement","Entity Type Name":"Roles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Roles","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["ROLE"]}},{"Category":"Entitlement","Entity Type Name":"Profiles","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Profiles","properties":{"PROFILE":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["PROFILE"]}},{"Category":"Entitlement","Entity Type Name":"Groups","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Groups","properties":{"GROUP":{"type":"string","$extension":{"isIdentifier":true,"isNativeId":true}}},"required":["GROUP"]}},{"Category":"Account","Entity Type Name":"Account","Schema":{"$schema":"http://json-schema.org/draft-07/schema#","type":"object","title":"Account","properties":{"Account ID":{"type":"string","$extension":{"isIdentifier":true,"isNameAttribute":true,"isNativeId":true}},"Status":{"type":"string","$extension":{"isStatus":true}},"Account Login":{"type":"string"},"Roles":{"type":"array","items":[{"type":"object","properties":{"ROLE":{"type":"string","$extension":{"isIdentifier":true}}},"required":["ROLE"]}]},"Profiles":{"type":"array","items":[{"type":"object","properties":{"PROFILE":{"type":"string","$extension":{"isIdentifier":true}}},"required":["PROFILE"]}]},"Groups":{"type":"array","items":[{"type":"object","properties":{"GROUP":{"type":"string","$extension":{"isIdentifier":true}}},"required":["GROUP"]}]}},"required":["Account ID"]},"Relationships":{"Groups":{"Related Entity Type Name":"Groups","Matching Rule":{"===":[{"var":"domain@Groups/GROUP"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"},"Profiles":{"Related Entity Type Name":"Profiles","Matching Rule":{"===":[{"var":"domain@Profiles/PROFILE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"},"Roles":{"Related Entity Type Name":"Roles","Matching Rule":{"===":[{"var":"domain@Roles/ROLE"},{"var":"range@$identifier"}]},"Relationship Category":"Account_Entitlement"},"Owner":{"Related Entity Type Name":"Identity","Related Entity Application Id":"CAMR-Identity","Related Entity Application Type":"Identity","Matching Rule":{"===":[{"var":"domain@Account Login"},{"var":"range@User Login"}]},"Relationship Category":"Entity_Actor"}}}],"Application Type Name":"new app type"}]
		 * */
	}
	
	
	
	
	
	

}
