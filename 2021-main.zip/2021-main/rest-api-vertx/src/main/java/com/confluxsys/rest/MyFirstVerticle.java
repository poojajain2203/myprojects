package com.confluxsys.rest;

import java.util.LinkedHashMap;
import java.util.Map;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.json.Json;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.StaticHandler;

public class MyFirstVerticle extends AbstractVerticle {

	private Map<Integer, Whisky> products = new LinkedHashMap<>();

	// Create some product
	private void createSomeData() {
		Whisky bowmore = new Whisky("Bowmore 15 Years Laimrig", "Scotland, Islay");
		products.put(bowmore.getId(), bowmore);
		Whisky talisker = new Whisky("Talisker 57° North", "Scotland, Island");
		products.put(talisker.getId(), talisker);
	}
	
	
	private void getAll(RoutingContext routingContext) {
		  routingContext.response()
		      .putHeader("content-type", "application/json; charset=utf-8")
		      .end(Json.encodePrettily(products.values()));
		}

	@Override
	public void start(Future<Void> fut) {
		
		createSomeData();

		Router router = Router.router(vertx);

		router.route("/").handler(routingContext -> {
			HttpServerResponse httpServerResponse = routingContext.response();

			httpServerResponse.putHeader("content-type", "text/html").end("<h1>Hello My First Application</h1>");
		});

		router.route("/src/main/resources/assets/*").handler(StaticHandler.create("assets"));
		
		router.get("/api/whiskies").handler(this::getAll);

		vertx.createHttpServer().requestHandler(router::accept).listen(
				// Retrieve the port from the configuration,
				// default to 8080.
				config().getInteger("http.port", 8081), result -> {
					if (result.succeeded()) {
						fut.complete();
					} else {
						fut.fail(result.cause());
					}
				});
	}
}
