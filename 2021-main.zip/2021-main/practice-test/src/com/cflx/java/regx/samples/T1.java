package com.cflx.java.regx.samples;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class T1 {

	public static void function1() {
		Pattern p = Pattern.compile("abc");
		Matcher m = p.matcher("abcabcabc");
		boolean b = m.matches();
		System.out.println(b);
	}
	
	public static void main(String[] args) {
	//	function1();
		function2();

	}

	// Regx for alphanumeric.
	private static void function2() {
		// TODO Auto-generated method stub
		List<String> names = new ArrayList<String>();
		names.add("Lokesh");
		names.add("LOkesh123");
		names.add("LOkesh123-");

		String exp = "^[a-zA-Z0-9]+$";
		Pattern pattern = Pattern.compile(exp);

		for (String name : names) {
			Matcher m = pattern.matcher(name);
			System.out.println(m.matches());
		}
	}

}
