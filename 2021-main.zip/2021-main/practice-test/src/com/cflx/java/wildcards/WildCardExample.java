package com.cflx.java.wildcards;

import java.util.Arrays;
import java.util.List;

public class WildCardExample {

	// Upper Bound WildCard.
	public static Double calSum(List<? extends Number> list) {
		double sum = 0.0D;
		for (Number i : list) {
			sum += i.doubleValue();
		}

		return sum;
	}

	// Lower Bound WildCards.
	public static void print(List<? super Integer> list) {
		System.out.println(list);
	}

	public static void printL(List<? super Long> list) {
		System.out.println(list);
	}

	// Unbounded Wildcard
	public static void printList(List<?> li) {
		System.out.println(li);
	}

	public static void main(String[] args) {
		System.out.println(calSum(Arrays.asList(1, 2, 3, 4, 5)));
		System.out.println(calSum(Arrays.asList(3.0D, 8.9D, 7.8D)));
		List<Integer> b = Arrays.asList(1, 2, 3, 4, 5);
		print(b);

		List<Long> l = Arrays.asList(1L, 2L, 3L);
		// print(l); // error compile.
		printL(l);
		printList(Arrays.asList(1,2,3,4,5,6));
		printList(Arrays.asList(1L,2L,3L,5L));
		printList(Arrays.asList(3.0D,5.8D,4.6F));

	}

}
