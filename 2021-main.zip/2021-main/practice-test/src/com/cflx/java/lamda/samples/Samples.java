package com.cflx.java.lamda.samples;


interface Print{
	public void print();
}

public class Samples {

	public void test() {
		System.out.println("Rahul");
	}
	
	static Print p = ()->System.out.println("Rahul");
	
	
	 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//p.print();
		
		
		String s = "select ce.id as cagEventId, cui.id as cagusecaseInstaceId, cui.pattern as ,cu.id as usecaseId, \r\n"
				+ "cu.name as usecaseName, cu.display_name as displayName,cu.priority as priority,cu.definition as definition, cu.config as config, cu.create_time as usecaseCreateTime, cu.update_time as usecaseUpdateTime, \r\n"
				+ "cut.id as usecaseTypeId, cut.name as useaseTypeName,cut.display_name as usecaseTypeDisplayName, cut.config as usecaseTypeConfig, cut.origin_service_id as originServiceId, cut.originating_artifact  as originatingArtifact ,\r\n"
				+ "cut.create_time as usecaseTypeCreateTime, cut.update_time as usecaseUpdateTime,\r\n"
				+ "--cag Task\r\n"
				+ "ct.id as cagTaskId , ct.name as taskName, ct.sp_task_id as spTaskId, ct.superseded_by_id as supersededById, ct.task_time as taskTime,\r\n"
				+ "ct.create_time as taskCreateTime,ct.task_outcome as taskOutcome,ct.task_outcome_summary as taskOutcomeSummary,ct.task_status as taskStatus,\r\n"
				+ "ct.task_status_details as taskStatusDetails,ct.target_object_reference_id as targetObjectRefId,ct.obligation_state as obligationStatus,\r\n"
				+ "ct.task_type as taskType, ct.data as taskData,ct.task_subject_type as taskSubjectType, ct.task_subject as taskSubject,ct.task_object_type as taskObjectType,ct.task_object as taskObject,\r\n"
				+ "ct.task_related_to as taskRelatedTo, ct.task_description as taskDescription\r\n"
				+ "from cag_event ce \r\n"
				+ "left join cag_usecase_instance cui on ce.usecase_instance_id = cui.id \r\n"
				+ "left join cag_usecase  cu on cu.id = cui.usecase_id left jon cag_usecase_type cut on cut.id = cu.usecase_type_id \r\n"
				+ "left join cag_object_store cos on cos.id = ce.target_resource_reference_id left join cag_object_store cos2 on cos2.id = ce.additional_info_reference_id \r\n"
				+ "left join cag_event_task cet on cet.event_id = ce.id\r\n"
				+ "left join cag_task ct on ct.id = cet.task_id\r\n"
				+ "where 1 = 1\r\n"
				+ "ce.id in(?,?,?,?,?,?,?";
		
		
		System.out.println(s);
		
		

	}

}
