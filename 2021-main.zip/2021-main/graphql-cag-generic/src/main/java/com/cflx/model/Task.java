package com.cflx.model;

import java.util.List;

public class Task {

	int id;
	String type;
	String name;
	List<Action> child;

	public List<Action> getChild() {
		return child;
	}

	public void setChild(List<Action> child) {
		this.child = child;
	}

	public Task() {

	}

	public Task(int id, String type, String name, List<Action> child) {
		super();
		this.id = id;
		this.type = type;
		this.name = name;
		this.child = child;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
