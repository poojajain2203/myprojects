package com.cflx.model;

import java.util.List;

public class Event {
	int id;
	String type;
	String name;
	List<Task> child;

	public Event() {
		super();
	}

	public Event(int id, String type, String name, List<Task> child) {
		super();
		this.id = id;
		this.type = type;
		this.name = name;
		this.child = child;
	}

	public List<Task> getChild() {
		return child;
	}

	public void setChild(List<Task> child) {
		this.child = child;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
