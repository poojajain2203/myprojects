package com.cflx.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cflx.model.Action;
import com.cflx.model.Event;
import com.cflx.model.Task;

public class Repo {



	public Object search(Map<String, Object> parm) {
		Map<String, Object> qt = (Map<String, Object>) parm.get("quark");
		
		List<Map<String, Object>> listmap = new ArrayList<Map<String, Object>>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", 30);
		map.put("type","Event");
		map.put("name", "Event_A");
		map.put("child", null);
		map.put("quark",qt);
		
		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("id", 31);
		map2.put("type","Event");
		map2.put("name", "Event_B");
		map2.put("child", null);
		map2.put("quark",qt);
		listmap.add(map);
		listmap.add(map2);
		return listmap;

	}

	public static Task getTasks(int id) {
		System.out.println("Dao Task Id : "+id);
		return null;
	}

	public static Event getEvents(int id) {
		return null;
	}

	public static Action getActions(int id) {
		System.out.println("Dao Action Id : "+id);
		return null;
	}

}