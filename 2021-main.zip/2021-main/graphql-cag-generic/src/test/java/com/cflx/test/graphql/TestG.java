package com.cflx.test.graphql;

import static org.testng.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cflx.graphql.GraphQLManager;
import com.cflx.graphql.QuarkType;

import graphql.ExecutionResult;

public class TestG {
	
	private GraphQLManager graphQLManager;
	
	@BeforeTest
	public void init() {
		graphQLManager = new GraphQLManager();
	}
	
	
  @Test
  public void f() {
	  Map<String, Object> map = new HashMap<String, Object>();
	  Map<String, Object> mapType = new HashMap<String, Object>();
	  mapType.put("quarkType", QuarkType.Event);
	  map.put("quark", mapType);
	  String query = "query lookupQuark($quark:QuarkInput!){ lookupQuark(quark:$quark){... on Event{name id type child{edges{node{ ... on Task{id name type}}}}}}}";
	  ExecutionResult res = graphQLManager.getData(query, map);
	  
	  assertNotNull(res);
  }
}
