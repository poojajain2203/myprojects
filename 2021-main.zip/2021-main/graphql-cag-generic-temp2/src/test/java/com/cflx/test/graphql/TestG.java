package com.cflx.test.graphql;

import static org.testng.Assert.assertNotNull;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cflx.graphql.GraphQLManager;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import graphql.ExecutionResult;

public class TestG {
	
	private GraphQLManager graphQLManager;
	private ObjectMapper objectMapper;
	
	@BeforeTest
	public void init() {
		graphQLManager = new GraphQLManager();
		objectMapper = new ObjectMapper();
	}
	
	
  @Test
  public void f() {
	 //   String query = "query lookupE_{lookupE_{id  name children{... on  Task{name children{... on Action{name}}}}}}";
	    
	//    String query = "query lookupT_{lookupT_{id name children{... on Action{id name}}}}";
	// String query = "query lookupA_{lookupA_{id name children{... on Task{id}}}}";
	  //using aliases request same query
	   String query = "query lookupE_{ ETA : lookupE_{id  name children{... on  Task{name children{... on Action{name}}}}} ET : lookupE_{id  name children{... on  Task{name}}}}";
	  
	  //using aliases  request different query:
	//  String query  = "query result{ ETA : lookupE_{name children{... on  Task{name children{... on Action{name}}}}} TA: lookupT_{id name children{... on Action{name}}}}";
	 
	  ExecutionResult res = graphQLManager.getData(query, null);
	  JsonNode json = objectMapper.convertValue(res, JsonNode.class);
	  assertNotNull(json);
	  System.out.println(json);
  }
}
