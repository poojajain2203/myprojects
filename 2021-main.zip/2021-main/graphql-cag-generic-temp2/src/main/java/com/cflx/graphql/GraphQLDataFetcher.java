package com.cflx.graphql;

import com.cflx.dao.Repo;

import graphql.schema.DataFetcher;

public class GraphQLDataFetcher {
	public GraphQLDataFetcher() {

	}

	@SuppressWarnings("rawtypes")
	DataFetcher lookupE = env -> {
		System.out.println("============:DF Event:===========");
		return Repo.lookupEvents();
	};
	@SuppressWarnings("rawtypes")
	DataFetcher lookupT = env -> {
		System.out.println("============:DF Task:===========");
		return Repo.lookupTasks();
	};

	@SuppressWarnings("rawtypes")
	DataFetcher lookupA = env -> {
		System.out.println("============:DF Action:===========");
		return Repo.lookupActions();
	};

	@SuppressWarnings("rawtypes")
	public DataFetcher getLookupT() {
		return lookupT;
	}

	@SuppressWarnings("rawtypes")
	public DataFetcher getLookupA() {
		return lookupA;
	}

	@SuppressWarnings("rawtypes")
	public DataFetcher getLookupE() {
		return lookupE;
	}

}
