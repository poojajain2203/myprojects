package com.cflx.dao;

import java.util.ArrayList;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Ravi Ranjan
 * */

public class Repo {

	public Repo() {

	}
	static List<Map<String, Object>> listMapOfTasks;
	static List<Map<String, Object>> listMapOfEvents;
	static List<Map<String, Object>> listMapOfActions;
 
	/**
	 * 
	 * 				Event
	 * 				   child -> Task
	 *                      	child-> Action
	 *  								child -> []
	 * */
	
	static {

		listMapOfTasks = new ArrayList<Map<String, Object>>();
		listMapOfEvents = new ArrayList<Map<String, Object>>();
		listMapOfActions = new ArrayList<Map<String, Object>>();
		for (int i = 1; i <= 3; i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", i);
			map.put("quarkType", "Task");
			map.put("name", "Task-name" + i);
			map.put("children", listMapOfActions);
			listMapOfTasks.add(map);
		}

		for (int i = 1; i <= 3; i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", i);
			map.put("quarkType", "Event");
			map.put("name", "event-name-" + i);
			map.put("children", listMapOfTasks);
			listMapOfEvents.add(map);
		}

		for (int i = 1; i <= 3; i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", i);
			map.put("quarkType", "Action");
			map.put("name", "action-name-" + i);
			map.put("children", Collections.emptyList());
			listMapOfActions.add(map);
		}

	}

	public static Object lookupEvents() {
		return listMapOfEvents;
	}

	public static Object lookupTasks() {
		return listMapOfTasks;
	}

	public static Object lookupActions() {
		return listMapOfActions;
	}

}
