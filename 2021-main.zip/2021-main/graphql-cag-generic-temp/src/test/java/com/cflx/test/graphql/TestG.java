package com.cflx.test.graphql;

import static org.testng.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cflx.graphql.GraphQLManager;
import com.cflx.graphql.QuarkType;

import graphql.ExecutionResult;

public class TestG {
	
	private GraphQLManager graphQLManager;
	
	@BeforeTest
	public void init() {
		graphQLManager = new GraphQLManager();
	}
	
	
  @Test
  public void f() {
	  Map<String, Object> map = new HashMap<String, Object>();
	  map.put("type", "Event");
	//  String query = "query lookupQuark($type:String!){ lookupQuark(type:$type){id type ... on Event{name child{... on Task{id name}}}}}";
	  String query = "query lookupQuark($type:String!){ lookupQuark(type:$type){ ... on Event{ id type child{... on Task{name type child{... on Action{name type }}}}}}}";
	  ExecutionResult res = graphQLManager.getData(query, map);
	  
	  assertNotNull(res);
  }
}
