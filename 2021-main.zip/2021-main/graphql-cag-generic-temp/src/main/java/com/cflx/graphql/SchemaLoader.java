package com.cflx.graphql;

import static graphql.schema.idl.TypeRuntimeWiring.newTypeWiring;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

import graphql.schema.DataFetcher;
import graphql.schema.GraphQLSchema;
import graphql.schema.TypeResolver;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;

public class SchemaLoader {

	private static final String GRAPHQL_FILE_NAME = "graphql-schema.graphql";
	private static SchemaLoader schemaProvider;
	private GraphQLSchema graphQLSchema;

	public static SchemaLoader getInstance() {
		if (schemaProvider == null) {
			schemaProvider = new SchemaLoader();
		}
		return schemaProvider;
	}

	public graphql.GraphQL getGraphqlProvider() {
		return graphql.GraphQL.newGraphQL(graphQLSchema).build();
	}

	public void buildSchema() {
		InputStream stream = null;
		Reader reader = null;
		try {
			ClassLoader classLoader = SchemaLoader.class.getClassLoader();
			stream = classLoader.getResourceAsStream(GRAPHQL_FILE_NAME);

			if (stream == null) {
				throw new RuntimeException("Cannot read Graphl schema!. File: " + GRAPHQL_FILE_NAME);
			}

			reader = new InputStreamReader(stream);
			SchemaGenerator schemaGenerator = new SchemaGenerator();
			SchemaParser schemaParser = new SchemaParser();
			TypeDefinitionRegistry registry = schemaParser.parse(reader);
			RuntimeWiring wiring = buildRuntimeWiring();
			graphQLSchema = schemaGenerator.makeExecutableSchema(registry, wiring);

		} catch (Exception e) {
			throw new RuntimeException("Cannot build Graphql schema. Error: ", e);

		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
				if (stream != null) {
					stream.close();
				}
			} catch (IOException e) {
			}
		}
	}

	private static RuntimeWiring buildRuntimeWiring() {
		GraphQLDataFetcher dataFetcher = new GraphQLDataFetcher();
		System.out.println("RunTimeWiringWiring");

		return RuntimeWiring.newRuntimeWiring()
				.type(newTypeWiring("Query").dataFetcher("lookupQuark", dataFetcher.lookupQuark))
				//.type(newTypeWiring("Event").typeResolver(entityResolver).dataFetcher("child", dataFetcher.lookupQuark))
				.type(newTypeWiring("Quark").typeResolver(entityResolver)).build();
	}

	private static final TypeResolver entityResolver = env -> {
		System.out.println(env);
		if (env.getObject() != null && env.getObject() instanceof Map) {
			Map<String, Object> object = env.getObject();
			if (object != null && !object.isEmpty()) {
				String qt = object.get("type").toString();
				switch (qt) {
				case "Task":
					System.out.println("=====: Task :=====");
					return env.getSchema().getObjectType("Task");
				case "Event":
					System.out.println("=====: Event :=====");
					return env.getSchema().getObjectType("Event");
				case "Action":
					System.out.println("=====: Action :=====");
					return env.getSchema().getObjectType("Action");
				default:
					System.out.println("Default === Not Resolve Type =======");
					return null;
				}

			}
		}
		System.out.println("(: === Cannot Resolve Type ====:)");
		return null;
	};
}
