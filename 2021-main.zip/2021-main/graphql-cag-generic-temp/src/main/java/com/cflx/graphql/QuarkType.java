package com.cflx.graphql;

public enum QuarkType {
	Task,
	Action,
	Event

}
