package com.cflx.graphql;

import java.util.Map;

import graphql.ExecutionInput;
import graphql.ExecutionResult;

public class GraphQLManager {
	private graphql.GraphQL graphQL;
	private SchemaLoader schemaLoader;

	public GraphQLManager() {
		schemaLoader = new SchemaLoader();
		checkAndBuildSchema();
	}

	public ExecutionResult getData(String query, Map<String, Object> parameters) {
		// build Input object
		ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).variables(parameters).build();
		ExecutionResult result;

		result = graphQL.execute(executionInput);

		return result;
	}

	private void checkAndBuildSchema() {
		if (graphQL == null) {
			schemaLoader.buildSchema();
			graphQL = schemaLoader.getGraphqlProvider();
		}
	}

}
