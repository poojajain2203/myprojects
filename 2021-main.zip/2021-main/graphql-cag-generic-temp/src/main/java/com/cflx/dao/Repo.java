package com.cflx.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.cflx.graphql.QuarkType;

public class Repo {

	public Repo() {

	}
	
	static List<Map<String, Object>> listMapOfTasks;
	static List<Map<String, Object>> listMapOfEvents;
	static List<Map<String, Object>> listMapOfActions;
 
	static {
		
		listMapOfTasks = new ArrayList<Map<String,Object>>();
		listMapOfEvents = new ArrayList<Map<String,Object>>();
		listMapOfActions = new ArrayList<Map<String,Object>>();
		for(int i=1;i<=10;i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", i);
			map.put("type", "Task");
			map.put("name", "Approval-name"+i);
			map.put("child", Collections.emptyList());
			listMapOfTasks.add(map);
		}
		
		for(int i=1;i<=10;i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", i);
			map.put("type", "Event");
			map.put("name", "event-name-"+i);
			map.put("child", Collections.emptyList());
			listMapOfEvents.add(map);
		}
		
		for(int i=1;i<=10;i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", i);
			map.put("type", "Action");
			map.put("name", "action-name-"+i);
			map.put("child", Collections.emptyList());
			listMapOfActions.add(map);
		}
		
		

	}

	public static Object lookupEvents() {
		return listMapOfEvents;
	}

	public static Object lookupTasks() {
		return listMapOfTasks;
	}

	public static Object lookupActions() {
		return listMapOfActions;
	}

}
