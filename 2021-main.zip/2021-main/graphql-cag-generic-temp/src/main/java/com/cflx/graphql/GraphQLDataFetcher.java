package com.cflx.graphql;

import java.util.Map;

import org.dataloader.DataLoaderRegistry;

import com.cflx.dao.Repo;

import graphql.schema.DataFetcher;

public class GraphQLDataFetcher {
	public static DataLoaderRegistry dataLoaderRegistry;

	public GraphQLDataFetcher() {

	}

	DataFetcher lookupQuark = env -> {
		System.out.print("============:DF:===========");
		Map<String, Object> parm = env.getArguments();
		String qt = parm.get("type").toString();
		switch (qt) {
		case "Task":
			return Repo.lookupTasks(); // lookupTask with Associated E/A if any.
		case "Event":
			return Repo.lookupEvents(); // lookupEvents with Associated T/A if any.
		case "Action":
			return Repo.lookupActions(); // lookupActions with Associated E/T if any.
		default:
			return null;
		}
	};

	public DataFetcher getLookupQuark() {
		return lookupQuark;
	}

}
