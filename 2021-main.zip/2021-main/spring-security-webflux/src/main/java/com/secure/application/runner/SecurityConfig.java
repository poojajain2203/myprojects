package com.secure.application.runner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.util.matcher.PathPatternParserServerWebExchangeMatcher;
import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatcher;

@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {
  /*   @Bean
      public MapReactiveUserDetailsService userDetailsService() {
          System.out.println("===========UserDetailService================");
          UserDetails user = User.withDefaultPasswordEncoder()
                  .username("user")
                  .password("user")
                  .roles("USER")
                  .build();
          return new MapReactiveUserDetailsService(user);
      }*/

    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) throws  Exception {
        System.out.println("================I am SecurityWebFilterChain==============");
       /* http
                .authorizeExchange()
                .anyExchange().authenticated()
                .and()
                .httpBasic().and()
                .formLogin();
        return http.build();*/

      //  return http.csrf().disable().authorizeExchange().anyExchange().authenticated().and().httpBasic().and().formLogin().and().build();


        //  return http.authorizeExchange().pathMatchers("/service/user/**").permitAll().anyExchange().authenticated().and().oauth2Login().and().build();
        http
              //  .cors()
               // .and()
                .csrf().disable()
                .httpBasic().disable()
                .authorizeExchange()
              //  .pathMatchers("/msg").permitAll()
                .anyExchange().authenticated()
                .and()
                .oauth2Login();
          return http.build();
   }
}
