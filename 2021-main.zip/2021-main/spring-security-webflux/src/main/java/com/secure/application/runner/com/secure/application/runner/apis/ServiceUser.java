package com.secure.application.runner.com.secure.application.runner.apis;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.netty.http.server.HttpServer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/service/user")
public class ServiceUser {
    private List<String> listOfusers;

    public ServiceUser(){
        listOfusers = new ArrayList<>();
        listOfusers.add("Ravi");
        listOfusers.add("BJAIN");
    }


    @GetMapping("/getAllUsers")
    public ResponseEntity<Flux<List<String>>> getUsers(){
        return ResponseEntity.status(HttpStatus.OK).body(Flux.just(listOfusers));
    }

    @GetMapping(path = "add/{user}")
    public Mono<String> addUser(@PathVariable("user") String user){
            listOfusers.add(user);
            return  Mono.just(user);
    }

}
