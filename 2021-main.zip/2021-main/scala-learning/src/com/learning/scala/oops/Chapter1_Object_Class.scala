package com.learning.scala.oops

/**
 * Scala Object & Class:
 *
 * - Unlike java, scala is a pure object oriented programming language. It allows us to create object and class so that you can develop object oriented applications.
 *
 * What is Object?
 * Object is a real world entity. It contains state and behavior. Laptop, car, cell phone are the real world objects.
 * Object typically has two characteristics:
 *   1. state  : data values of an object are known as its state.
 *   2. behavior : functionality that an object performs is known as its behavior.
 *
 *   ** Object in scala is an instance of class. It is also known as runtime entity.
 */

/**
 * What is class?
 * Class is a template or a blueprint. It is also known as collection of objects of similar type.
 *
 * In scala, a class can contain:
 * Data member
 * Member method
 * Constructor
 * Block
 * Nested class
 * Super class information etc.
 *
 * You must initialize all instance variables in the class. There is no default scope.
 * If you don't specify access scope, it is public.
 * There must be an object in which main method is defined. It provides starting point for your program.
 *
 */

class Student {
  //Must be initilize
  var id: Int = 0;
  var name: String = null;
}

class Student2(id:Int,name:String){
  
  def show(){
    println("Id : "+id + " Name : "+name);
  }
}

object Chapter1_Object_Class {

  def main(args: Array[String]) : Unit = {
    var v = new Student();
    println(v.id + "::" + v.name);
    
    v.id = 30;
    v.name = "Rahul Kumar";
    println(v.id + "::" + v.name);
    
    var s = new Student2(101, "Ravi Ranjan");
    s.show();
    
    
    
    
    
  }
}