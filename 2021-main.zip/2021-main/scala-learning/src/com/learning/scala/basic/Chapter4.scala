package com.learning.scala.basic

/**
 * Scala Conditional Expressions
 */

object Chapter4 {
  def ifFun(v: Int) {
    if (v < 20) {
      println("I am " + v + " year old.");
    }
  }
  
  def ifElseFun(v:Int){
    //odd even
    if((v&1)==0){
      println("Even Number");
    }else{
      println("Odd Number");
    }
  }

  
  /**
   * Scala If Statement as better alternative of Ternary Operators
   *   - In scala, you can assign if statement result to a function. 
   *   - Scala does not have ternary operator concept like C/C++ but provides more powerful if which can return value. Let's see an example:
   * 
   * */
  
  def checkIT(a:Int) = if(a>0) 1 else -1;
  
  
  //Main Method

  def main(args: Array[String]) {
    ifFun(18);
    ifElseFun(20);
    ifElseFun(13);

    // Ternary Operators
    val i = checkIT(-10);
    println(i);

    val j = checkIT(2);
    println(j)

  }
}