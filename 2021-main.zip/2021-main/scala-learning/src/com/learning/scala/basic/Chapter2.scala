package com.learning.scala.basic

/**
 * Hello World.
 * */

object Chapter2 {
  
  //Using Functions
  def myWords{
    println("I am Scala...");
  }
  
  def main(args : Array[String]){
    println("Hello World");
    myWords
  }
  
}