package com.learning.scala.basic
import scala.util.control.Breaks._

/**
 * Break Statment:
 * 
 * */

object Chapter8 {
  def outerBreak {
    breakable {
      for (a <- 1 to 10) {
        if (a == 7)
          break;
        else
          println(a);
      }
    }
  }

  def innerBreak {
    for (a <- 1 to 10) {
      breakable {
        if (a == 5) //skip
          break; 
        else
          println(a);
      }
    }
  }
  def main(args: Array[String]) {
  //  outerBreak;
    innerBreak;
  }
}