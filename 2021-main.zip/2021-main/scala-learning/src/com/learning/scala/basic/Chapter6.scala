package com.learning.scala.basic
/**
 * Loop In Scala
 * 1. While Loop
 * 2. Do While Loop
 * */
object Chapter6 {
  
  //While Loop
  def loopwhileFinite{
    var a = 10;
        while(a>0){
          println(a+" ");
          a -=2;
        }
  }
  //Infinite While Loops
  def loopWhileInfinite{
    var i:Int = 0;
    while(true){
      println(i);
      i+=1;
    }
  }
  
  //Do While Loop.
  def do_while{
    var a :Int =10;
    do{
      println(a);
      a = a+2;
    }while(a!=20)
  }
  
   //Do While Loop Infinte.
  def do_while_Infinite{
    var a :Int =10;
    do{
      println(a);
      a = a+2;
    }while(true)
  }
  
  
  def main(args : Array[String]){
    //  loopwhileFinite;
   // loopWhileInfinite;
    
    do_while;
 //   do_while_Infinite;
  }
  
}