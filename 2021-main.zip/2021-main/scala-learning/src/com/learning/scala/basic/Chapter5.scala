package com.learning.scala.basic
/**
 * Scala Pattern Matching
 * */
object Chapter5 {
  def patternMatch(a : Int){
    a match{
      case 1 => println("one")
      case 2 => println("Two");
      case _ => println("Undefine");
    }
  }

  /**
   * Match expression can return case value also. In next example, we are defining method having a match with cases for any type of data.
   * Any is a class in scala which is a super class of all data types and deals with all type of data.
   * Let's see an example.
   */

  def search(a: Any): Any = a match {
    case 1 => println("One")
    case "Two" => println("Two")
    case "Hello" => println("Hello World")
    case _ => println("No")
  }
  
  def main(args : Array[String]){
    /**
     * Pattern matching is a feature of scala.
     * It works same as switch case in other programming languages.
     * It matches best case available in the pattern. 
     * */
    patternMatch(2); //Two
    patternMatch(10); //Undefine.
    
    var res = search("Hello");
    println(res);
    
    var result = search(1);
    println(result);
  }
}