package com.learning.scala.basic

/**
 * Scala Comments:
The scala comments are statements which are not executed by the compiler or interpreter.
The comments can be used to provide information or explanation about the variable, method, class or any statement. 
It can also be used to hide program code details.
In scala, there are three types of comments:
		Single line comment :  //
		Multiline comment   : /**/
		Documentation comment :  /***/
 * */


/**
 * Scala For Loops:
 *  In scala, for loop is known as for-comprehensions. 
 *  It can be used to iterate, filter and return an iterated collection. 
 *  The for-comprehension looks a bit like a for-loop in imperative languages, except that it constructs a list of the results of all iterations.
		Syntax:
		for( i <- range){  
    // statements to be executed  
		}	
		In the above syntax, range is a value which has start and end point. You can pass range by using to or until keyword.  
 * */

/**
 * Difference to vs until
 *   -> to : include start to end.
 *   -> until : include start and exclude end. In simple words start to end-1.
 * 
 * */

object Chapter7 {
  def forLoopUsingTo{
    for(a <- 1 to 10){
      println(a);
    }
  }
  
  def forLoopUsingUntil{
    for(a <- 1 until 10){
        println(a);      
    }
  }
  def main(args: Array[String]) {
    forLoopUsingTo;
    forLoopUsingUntil;
    
  }
}