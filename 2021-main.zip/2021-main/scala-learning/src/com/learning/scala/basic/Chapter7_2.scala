package com.learning.scala.basic
/**
 * For Loop Chapter 7.2
 * */
object Chapter7_2 {
  /**
   * scala by keyword:
   * - The by keyword is used to skip the iteration. When you code like: by 2 it means, this loop will skip all even iterations of loop.
   * */
  
  def forLoopUsingByKeyword{
    for(a <- 1 to 10 by 2){
      println(a);
    }
  }
  
  /**
   * Scala for-each loop:
   * 
   * */
  
  def forEachLoopIteration{
    var list = List(1,2,3,4,5,6,7,8,9,10);
    
    //Method 1:
    list.foreach(println);
    println("*******************************************");
    //Method 2
    list.foreach(print);
    println();
    println("*******************************************");
    //Method 3
    list.foreach((ele : Int) => print(ele + " "));
    println();
    println("*******************************************");
    
  }
  
  
  def main(args : Array[String]){
        forLoopUsingByKeyword;
        forEachLoopIteration;
  }
}