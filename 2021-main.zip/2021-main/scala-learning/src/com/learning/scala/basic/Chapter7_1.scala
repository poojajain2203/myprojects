package com.learning.scala.basic
/**
 * For Loop Chapter 7.1
 * */
object Chapter7_1 {
  //For loop Filtering Exaple:
  
  def filterOnlyEven{
    for(a <- 1 to 10 if (a&1)==0){
      println(a);
    }
  }
  
  
  /**
   * Scala for-loop Example by using yield keyword
		In the above example, we have used yield keyword which returns a result after completing of loop iterations.
		The for use buffer internally to store iterated result and after finishing all iterations it yields the final result from that buffer. 
		 It does not work like imperative loop.
   * */
  
  def forusingYield{
      var res = for(a <- 1 to 10) yield a
      println(res);  
      for(i<- res) println(i);
  }
  
  //Scala for- loop Example for Iterating Collection:
  
  def iterateCollectionUsingForLoop{
    var list = List(1,2,3,4,5,6);
    
    for(i <- list) println(i);
    
  }
  
  def main(args : Array[String]){
    //filterOnlyEven;
    // forusingYield
    iterateCollectionUsingForLoop
  }
}