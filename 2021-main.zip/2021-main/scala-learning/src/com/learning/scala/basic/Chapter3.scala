package com.learning.scala.basic
/**
 * Variable and Data Type.
 */

/**
 * In scala Variable is Two Type:
 *   1) Mutable
 *   		It allows you to change value after declaration of variable.
 *   2)Immutable
 * 				It not allows you to change value after declaration of variable.
 *
 */

/**
 * Tip:
 * if we want to change content then it is advisable to use var instead of val.
 * */

object Chapter3 {
  def main(args: Array[String]) {
    //mutable variable:

    /**
     * In the above code, var is a keyword and data is a variable name. 
     * It contains an integer value 100. Scala is a type infers language so you don't need to specify data type explicitly. 
     * */
    
    var data = 100; 
    println("data  :: "+data); //100
    
    data = 120;
    println("data :: "+data); //120
    
    /**
     * we can also mention data type of variable explicitly as we have used in below.
     * */
    var data2:Int = 100;
    println("data2 :: "+data2);
    
    
    //Immutable variable.
    
    val data3:Int = 100;
    println("data3 :: "+data3);
    
    //it gives us error because immutable variable we cannot change values.
  //  data3 = 120; 
  }
}


/**
 * Data Type In Scala:
 * Data types in scala are much similar to java in terms of their storage, length, 
 * except that in scala there is no concept of primitive data types 
 * every type is an object and starts with capital letter. 
 * A table of data types is given below. You will see their uses further.
 * 
 *   DataType 			Default Value     Size
 *   --------------------------------------
 *   Boolean 					False						 True/False
 * 	 Byte 						0 							 8 bit signed value (-2^7 to 2^7-1)	  
 *   Short            0                16 bit signed value (-2^15 to 2^15-1)
 *   Char             '\u0000'				 16 bit unsigned Unicode character(0 to 2^16-1)
 *   Int 							0								 32 bit signed value(-2^31 to 2^31-1)
 *   Long							0L							 64 bit signed value(-2^63 to 2^63-1)
 *   Float						0.0F						 32 bit IEEE 754 single-precision float
 *	 Double						0.0D						 64 bit IEEE 754 double-precision float
 *	 String	          Null						 A sequence of characters		 	 
 * */

