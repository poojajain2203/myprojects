package com.learning.scala.functions

/**
 * Scala Higher Order Functions:
 * ----------------------------
 * - Higher order function is a function that either takes a function as argument or returns a function.
 * - In other words we can say a function which works with function is called higher order function.
 * - Higher order function allows you to create function composition, lambda function or anonymous function etc.
 */

object Chapter2_HigherOrderFunction {

  //Scala Example: Passing a Function as Parameter in a Function
  def functionExample(a: Int, f: Int => AnyVal): Unit = {
    println(f(a));
  }

  def multiplyWith2(a: Int): Int = {
    return a * 2;
  }

  //Scala Example: Function Composition

  def addBy2(a: Int): Int = {
    return a + 2;
  }

  def functionExample2(a: Int): Int = {
    return a * 2;
  }

  def main(args: Array[String]) {

    functionExample(25, multiplyWith2); //50

    val res = functionExample2(addBy2(10));
    println(res); //24
    
    
  }
}