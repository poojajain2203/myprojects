package com.learning.scala.functions

/**
 *Scala Function Currying 
 * 
 * */

object Chapter5_HigherOrderFunctions {
  
  def main(args : Array[String]) : Unit = {
      
  }
}