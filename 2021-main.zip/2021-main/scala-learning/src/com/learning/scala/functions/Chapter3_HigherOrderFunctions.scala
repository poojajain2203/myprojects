package com.learning.scala.functions

/**
 * Scala Anonymous (lambda) Function:
 * 	- Anonymous function is a function that has no name but works as a function. 
 * 	- It is good to create an anonymous function when you don't want to reuse it latter.
 * 	- You can create anonymous function either by using => (rocket) or _ (underscore) wild card in scala.
 * 
 * 
 * */

object Chapter3_HigherOrderFunctions {
  
  //anonymous function by using => (rocket) 
  var result1 = (a:Int,b:Int)=>a+b;
  
  //anonymous function by using _ (underscore) wild card
  var result2 = (_:Int)+(_:Int);
  def main(args : Array[String]): Unit = {
    println(result1(2,2)); //4
    println(result2(13,1)); //14
  }
}