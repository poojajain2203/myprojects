package com.learning.scala.functions
/**
 * Scala Functions:
   Scala supports functional programming approach. It provides rich set of built-in functions and allows you to create user defined functions also.
		In scala, functions are first class values. You can store function value, pass function as an argument and return function as a value from other function. 
		You can create function by using def keyword. You must mention return type of parameters while defining function and return type of a function is optional.
		 If you don't specify return type of a function, default return type is Unit.
		 
		 Syntax:
		 def functionName(parameters : typeofparameters) : returntypeoffunction = {  
							// statements to be executed  
			}
			
			In the above syntax, = (equal) operator is looking strange but don't worry scala has defined it as:
				You can create function with or without = (equal) operator. If you use it, function will return value. 
				If you don't use it, your function will not return anything and will work like subroutine.  
				
				Scala functions don't use return statement. Return type infers by compiler from the last expression or statement present in the function.
			 Syntax:
		 		def functionName(parameters : typeofparameters)  = {  
							// statements to be executed  
					}
			
				
				
 * 
 * */
object Chapter1_ScalaFunction {
  //Scala Function Example without using = Operator

  def functionExampleWithOutEqualOperator() {
    println("This is Example");
  }

  //Scala Function Example with = Operator
  def functionExampleWithEqualOperator() = {
    var a = 10;
    a;
  }
  
  //or
  
   def functionExampleWithEqualOperatorWithReturnType() : Int = {
    var a = 10;
    return a;
  }
  
  //Scala Parameterized Function Example
   def functionParameterExample(a:Int,b:Int){
     var c = a+b;
     println(c);
   }
   
   //scala Recursive Function
   def functionRecursive(n : Int) : Int = {
     if(n==0)
       return 0;
     return n+functionRecursive(n-1);     
   }
   
   //Function Parameter with Default Value
   def functionDefaultParameter(a:Int=0, b:Int = 0) = {
     a+b;
   }
   
   
   //Scala Function Named Parameter Example
   /**
    * In scala function, you can specify the names of parameters during calling the function. 
    * In the given example, you can notice that parameter names are passing during calling. You can pass named parameters in any order and can also pass values only.
    * */

   def functionNamedParameter(a:Int, b:Int) = {
     a+b;
   }
   
  def main(args: Array[String]) {
    functionExampleWithOutEqualOperator();
    var res = functionExampleWithEqualOperator();
    println(res);
    functionParameterExample(2,3);
    var j = functionExampleWithEqualOperatorWithReturnType();
    println(j);
    
    println("Recursive Function Result :: "+functionRecursive(5));
    
    println("functionDefaultParameter(2,3) :: "+functionDefaultParameter(2,3)); //5
    println("functionDefaultParameter() :: "+functionDefaultParameter()); //0
    println("functionDefaultParameter(2) :: "+functionDefaultParameter(2)); //2
    
    
    //Named Parameter:
     
    println(functionNamedParameter(a=2,b=3));
    println(functionNamedParameter(b=2,a=3));
    
  }
  
}