package com.learning.scala.functions

/**
 * Scala Multiline Expression
 * 
 * */

object Chapter4_HigherOrderFunctions {
  
  /**
   * The function does not evaluate complete expression and just return b here. So, be careful while using multiline expressions.
   * /
   */
  def add1(a : Int , b : Int) : Int = {
    // -- here 1 gives warning msg and only return value of b.
     a
     +b
  }
  
  def add2(a : Int, b:Int) : Int = {
    a+
    b
  }
  
  def add3(a : Int, b:Int) : Int = {
    (a
    +b)
  }
  
  //scala nested functions:
  def add4(a: Int, b:Int, c:Int) : Int ={
      def add5(x : Int , y : Int) = {
        x+y;
      }
      add2(a,add5(b,c));
  }
  
  //Scala Function with Variable Length Parameters:
  def addVar(a : Int *) : Int = {
      var sum = 0;
      for(i <- a ){ 
        sum +=i;
      }
      return sum;
  }
  
  
  def main(args : Array[String]) : Unit = {
    /**
     * Expressions those are written in multiple lines are called multiline expression. In scala, be carefull while using multiline expressions.
			 The following program explains about if we break an expression into multiline, the scala compiler throw a warning message.
			 
			 Result : 
			 warning: a pure expression does nothing in statement  position; you may be omitting necessary parentheses
        a
        ^
				one warning found

     * */
     val first = add1(10,3); //3 
     println(first);
     
     val second = add2(10,3); //13 
     println(second);
     
     val third = add3(10,3); // 13
     println(third);
     
     
     //Scala Nested Functions
     val res = add4(2,3,4); // 9
     println(res);
     
     //Scala Function with Variable Length Parameters:
     val i = addVar(1,2,3,45);
     val j = addVar(1,2,3,4,5,6,7,8,9,9,56);
     
     println(i+" :: "+j);
     
  }
}