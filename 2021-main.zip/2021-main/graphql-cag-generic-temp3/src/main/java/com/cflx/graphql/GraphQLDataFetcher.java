package com.cflx.graphql;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.tuple.ImmutablePair;

import com.cflx.dao.Repo;

import graphql.language.Argument;
import graphql.language.ArrayValue;
import graphql.language.BooleanValue;
import graphql.language.EnumValue;
import graphql.language.Field;
import graphql.language.FloatValue;
import graphql.language.InlineFragment;
import graphql.language.IntValue;
import graphql.language.Node;
import graphql.language.NullValue;
import graphql.language.SelectionSet;
import graphql.language.StringValue;
import graphql.language.Value;
import graphql.language.VariableReference;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.DataFetchingFieldSelectionSet;
import graphql.schema.SelectedField;

public class GraphQLDataFetcher {
	public GraphQLDataFetcher() {

	}

	@SuppressWarnings("rawtypes")
	DataFetcher lookupE = env -> {
		System.out.println("============:DF Event:===========");
		/*
		 * List<String> requestedAttributes = getRequestedAttributes(env.getFields());
		 * System.out.println("res===>"+requestedAttributes);
		 */
	//	getInlineFieldInAQuery(env.getField());
	//	DataFetchingFieldSelectionSet selectionSet = env.getSelectionSet();
	//	ss(selectionSet);
		return Repo.lookupEvents();
	};
	@SuppressWarnings("rawtypes")
	DataFetcher lookupT = env -> {
		System.out.println("============:DF Task:===========");
		return Repo.lookupTasks();
	};

	@SuppressWarnings("rawtypes")
	DataFetcher lookupA = env -> {
		System.out.println("============:DF Action:===========");
		return Repo.lookupActions();
	};

	@SuppressWarnings("rawtypes")
	public DataFetcher getLookupT() {
		return lookupT;
	}

	private void ss(DataFetchingFieldSelectionSet selectionSet) {
		System.out.println(selectionSet.getArguments());
		
	List<SelectedField> sf	= selectionSet.getFields();
	
	for(SelectedField s : sf) {
		System.out.println(s.getName());
	}
		
	}

	@SuppressWarnings("rawtypes")
	public DataFetcher getLookupA() {
		return lookupA;
	}

	@SuppressWarnings("rawtypes")
	public DataFetcher getLookupE() {
		return lookupE;
	}

	// Self Impl.

	public static Object getInlineFieldInAQuery(Field selectedFields) {
		List<Field> selectionSet = selectedFields.getSelectionSet().getSelectionsOfType(Field.class);
		System.out.println(selectionSet.size());
		for (Field f : selectionSet) {
			List<Field> f2 = f.getSelectionSet().getSelectionsOfType(Field.class);
			System.out.println(f2.size());
				
		}

		return null;
	}

	// IAP
	public static ImmutablePair<Map<String, Map<String, Object>>, Map<String, Map<String, Object>>> getInlineFieldMap(
			Field selectedFields) {
		List<InlineFragment> ifs = selectedFields.getSelectionSet().getSelectionsOfType(InlineFragment.class);
		Map<String, Map<String, Object>> inlineFieldMap = Collections.emptyMap();
		Map<String, Map<String, Object>> argumentMap = new HashMap<>();
		if (ifs != null && !ifs.isEmpty()) {
			InlineFragment inlineFragment = ifs.get(0);
			SelectionSet iss = inlineFragment.getSelectionSet();
			inlineFieldMap = collectFields(iss, argumentMap);
		}
		return new ImmutablePair<>(inlineFieldMap, argumentMap);
	}

	@SuppressWarnings("unchecked")
	private static Map<String, Map<String, Object>> collectFields(SelectionSet selections,
			Map<String, Map<String, Object>> argumentMap) {
		Map<String, Map<String, Object>> fieldMap = new HashMap<>();
		List<Field> fields = selections.getSelectionsOfType(Field.class);
		for (Field field : fields) {
			String name = field.getName();
			// parse arguments
			List<Argument> args = field.getArguments();
			if (!args.isEmpty()) {
				Map<String, Object> argMap = new HashMap<>();
				for (Argument arg : args) {
					Object value = mapGraphQlValueObject(arg.getValue());
					if (value != null) {
						argMap.put(arg.getName(), value);
					}
				}
				if (!argMap.isEmpty()) {
					argumentMap.put(name, argMap);
				}
			}
			// parse fields
			SelectionSet ss = field.getSelectionSet();
			Map<String, ?> value = null;
			if (ss != null) {
				value = collectFields(ss, argumentMap);
			}
			fieldMap.put(name, (Map<String, Object>) value);
		}
		return fieldMap;
	}

	public static Object mapGraphQlValueObject(Value<?> valueObj) {
		Object value;
		if (valueObj instanceof StringValue) {
			StringValue obj = (StringValue) valueObj;
			value = obj.getValue();
		} else if (valueObj instanceof NullValue) {
			value = null;
		} else if (valueObj instanceof IntValue) {
			IntValue obj = (IntValue) valueObj;
			value = obj.getValue();
		} else if (valueObj instanceof FloatValue) {
			FloatValue obj = (FloatValue) valueObj;
			value = obj.getValue();
		} else if (valueObj instanceof BooleanValue) {
			BooleanValue obj = (BooleanValue) valueObj;
			value = obj.isValue();
		} else if (valueObj instanceof ArrayValue) {
			ArrayValue obj = (ArrayValue) valueObj;
			value = obj.getValues();
		} else if (valueObj instanceof EnumValue) {
			EnumValue obj = (EnumValue) valueObj;
			value = obj.getName();
		} else if (valueObj instanceof VariableReference) {
			VariableReference obj = (VariableReference) valueObj;
			value = obj.getName();
		} else {
			throw new IllegalArgumentException("GraphQL filter value of type: '" + valueObj.getClass()
					+ "' is not supported currently. valueObj: " + valueObj);
		}
		return value;
	}

	// CAG
	private List<String> getRequestedAttributes(List<Field> fields) {
		List<String> argumentsToFetch = new ArrayList<>();
		// Fetch selection fields
		for (Field field : fields) {
			List<Node> selectionField = field.getSelectionSet().getChildren();
			for (Node selection : selectionField) {
				if (selection instanceof Field) {
					Field requestField = (Field) selection;
					argumentsToFetch.add(requestField.getName());
				}
			}
		}
		return argumentsToFetch;
	}

}
