package com.cflx.test.graphql;

import static org.testng.Assert.assertNotNull;

import java.util.Collections;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cflx.graphql.GraphQLManager;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import graphql.ExecutionResult;

public class TestG {
	
	private GraphQLManager graphQLManager;
	private ObjectMapper objectMapper;
	
	@BeforeTest
	public void init() {
		graphQLManager = new GraphQLManager();
		objectMapper = new ObjectMapper();
	}
	
	
  @Test
  public void f() {
	
	  String query = "query lookupE_{ lookupE_{events{id name children{ ... on Task{id name children{ ... on Action{id name}}}}} pageInfo{hasNextPage endCursor}}}";
	  ExecutionResult res = graphQLManager.getData(query, Collections.emptyMap());
	  JsonNode json = objectMapper.convertValue(res, JsonNode.class);
	//  assertNotNull(json);
	  System.out.println(json);
  }
}
