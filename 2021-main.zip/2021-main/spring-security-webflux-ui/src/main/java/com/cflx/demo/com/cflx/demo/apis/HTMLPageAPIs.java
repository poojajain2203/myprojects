package com.cflx.demo.com.cflx.demo.apis;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import reactor.core.publisher.Mono;

@Controller
public class HTMLPageAPIs {

    @GetMapping("/page")
    public Mono<String> getPage(){
        return Mono.just("index");
    }
}
