package com.cflx.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityWebfluxUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityWebfluxUiApplication.class, args);
	}

}
