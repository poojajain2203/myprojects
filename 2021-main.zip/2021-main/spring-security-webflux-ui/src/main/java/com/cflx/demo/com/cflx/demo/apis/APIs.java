package com.cflx.demo.com.cflx.demo.apis;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/rs")
public class APIs {

    @GetMapping
    public Mono<String> getMessage(){
        return  Mono.just("Service Up.");
    }

}
