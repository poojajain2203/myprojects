package com.cflx.demo.com.cflx.demo.apis;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
public class PortAPI {

    @GetMapping
    public Mono<String> getPortMsg(){
        return Mono.just("Port 8081.");
    }


}
