import java.util.List;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.ListPosition;

public class RedisListExample {

	public static void main(String[] args) {

		Jedis jedis = new Jedis("localhost");

		System.out.println("Connecion is successfully estd." + jedis.ping()); //Pong

		jedis.flushAll(); // delete the all keys.

		// Add values in the list.
		String key = "num";

		jedis.rpush(key, "12");

		System.out.println("Values insertion started.");
		for (int i = 0; i < 10; i++) {
			jedis.lpush(key, String.valueOf(i));
		}

		System.out.println("Length Of List::" + jedis.llen(key));// 10

		jedis.lpushx(key, "50");
		jedis.rpushx(key, "512");

		jedis.lset(key, 5, "456"); // set value at index 5.

		List<String> values = jedis.lrange(key, 0, -1); // start to end.
		for (int i = 0; i < values.size(); i++) {
			System.out.print(values.get(i) + " ");
		}
		System.out.println();

		jedis.lpop(key); // pop from top.
		jedis.rpop(key); // pop from bottom.

		List<String> values1 = jedis.lrange(key, 0, -1); // start to end.
		for (int i = 0; i < values1.size(); i++) {
			System.out.print(values1.get(i) + " "); // 9 8 7 6 456 4 3 2 1 0 12
		}
		System.out.println();

		jedis.linsert(key, ListPosition.AFTER, "2", "50"); // 9 8 7 6 456 4 3 2 50 1 0 12
		jedis.linsert(key, ListPosition.BEFORE, "4", "256"); // 9 8 7 6 456 256 4 3 2 50 1 0 12

		List<String> values2 = jedis.lrange(key, 0, -1); // start to end.
		for (int i = 0; i < values2.size(); i++) {
			System.out.print(values2.get(i) + " ");
		}
		System.out.println();

		if (jedis != null) {
			jedis.close();
			System.out.println("Connection is close.");
		}

	}

}
