import java.util.Set;

import redis.clients.jedis.Jedis;

public class RedisStringExample {

	public static void main(String[] args) {

		/**
		 * set(key,value),get(key), keys(pattern), strlen(key), append(key,value),
		 * flushAll(),del(key)
		 */

		Jedis jedis = new Jedis("localhost");
		System.out.println("Connection to server to successfully");
		System.out.println("PING:" + jedis.ping());

		jedis.flushAll();
		// Redis String.
		
		jedis.set("name", "Ravi Ranjan");
		jedis.set("age", "10");
		jedis.set("address", "c-36 Industrial Area");

		System.out.println("Name:" + jedis.get("name") + "::" + "age:" + jedis.get("age"));

		Set<String> keys = jedis.keys("*");
		for (String key : keys) {
			System.out.println("Key::" + key + "Value:" + jedis.get(key));

		}

		System.out.println("Delete The Key: Address::" + jedis.del("address")); // 1
		System.out.println("Delete The Key if not exist: ram::" + jedis.del("ram")); // 0

		System.out.println("Lenght of the Key Name:" + jedis.strlen("name"));
		jedis.append("name", " Singh");
		System.out.println("Append The::" + jedis.get("name"));

		jedis.flushAll();
		Set<String> keysAfterFlushAll = jedis.keys("*");
		System.out.println("flushAll::" + keysAfterFlushAll);

		if (jedis != null) {
			jedis.close();
			System.out.println("Connection is close");
		}
	}

}
