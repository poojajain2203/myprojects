import java.util.Set;

import redis.clients.jedis.Jedis;

public class RedisSetExample {

	public static void main(String[] args) {

		Jedis jedis = new Jedis("localhost");
		System.out.println("Connection is estd." + jedis.ping() + ":" + jedis.ping("Hii"));
		jedis.flushAll();
		String[] mem1 = { "10", "20", "30", "40", "50", "60", "70", "80" };
		String[] mem2 = { "20", "30", "60", "100", "512" };
		jedis.sadd("num1", mem1);
		jedis.sadd("num2", mem2);
		System.out.println(jedis.scard("num1"));//8
		System.out.println(jedis.scard("num2"));//5
		
		Set<String> val_num1 = jedis.smembers("num1");
		System.out.println("Set1::"+val_num1);
		Set<String> val_num2 =  jedis.smembers("num2");
		System.out.println("Set2::"+val_num2);
		
		
		Set<String>diff = jedis.sdiff("num1","num2");
		System.out.println("difference::"+diff);
		
		Set<String> union  = jedis.sunion("num1","num2");
		System.out.println("union::"+union);
		
		Set<String> intersection = jedis.sinter("num1","num2");
		System.out.println("intersection::"+intersection);
		
		
		
		Set<String> keys =jedis.keys("*");
		System.out.println("Keys Are::"+keys);
		if (jedis != null) {
			jedis.close();
			System.out.println("Connection is closed.");
		}

	}

}
