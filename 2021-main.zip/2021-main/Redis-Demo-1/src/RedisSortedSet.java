import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import redis.clients.jedis.Jedis;

public class RedisSortedSet {

	public static void main(String[] args) {

		Jedis jedis = new Jedis("localhost");
		System.out.println("connection estd." + jedis.ping("Hello"));
		jedis.flushAll();

		String key = "myset1";
		/*Map<Member,Score>*/
		Map<String, Double> scoreMembers = new HashMap<String, Double>();
		scoreMembers.put("a", 10.0);
		scoreMembers.put("bgg", 20.0);
		scoreMembers.put("aa", 20.0);
		scoreMembers.put("aaa", 266.0);
		scoreMembers.put("br", 678.0);
		scoreMembers.put("er", 78.0);
		scoreMembers.put("bar", 66.0);
		scoreMembers.put("ar", 120.0);
		
		jedis.zadd(key, scoreMembers);

		 Set<String> str = jedis.zrange(key, 0, -1);
		 System.out.println("Members"+str);
		 
		 System.out.println("size is:"+jedis.zcard(key));
		 
		 Set<String> str1 = jedis.zrangeByScore(key, "0", "100");
		 System.out.println(str1);
		 
		 System.out.println(jedis.zscore(key, "aa"));
		
		if (jedis != null) {
			jedis.close();
			System.out.println("Connection is closed.");
		}

	}

}
