import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import redis.clients.jedis.Jedis;

public class RedisHashesExample {

	public static void main(String[] args) {

		Jedis jedis = new Jedis("localhost");
		System.out.println("Connection is estd:" + jedis.ping()); // pong

		jedis.flushAll();

		// hash Example:

		/**
		 * Map<String,String> => Map<Field, Value>
		 */

		Map<String, String> hash = new HashMap<String, String>();
		hash.put("Name", "Parkash");
		hash.put("Age", "10");
		hash.put("Address", "c-36 Industrial Area");
		hash.put("contact No", "(+91) 607 567 8990");

		jedis.hmset("example-1", hash); // set values in map.
		System.out.println("<===============================>");
		System.out.println(jedis.hgetAll("example-1")); // get the all values from hash.

		System.out.println("<===============================>");
		System.out.println(jedis.hget("example-1", "Name")); // getting the field value.

		System.out.println("<===============================>");
		System.out.println(jedis.hlen("example-1"));// 4

		System.out.println("<===============================>");
		System.out.println(jedis.hstrlen("example-1", "Address")); // 20

		jedis.hincrBy("example-1", "Age", 2);

		System.out.println("<===============================>");
		System.out.println(jedis.hget("example-1", "Age"));// 12

		System.out.println("<===============================>");
		System.out.println(jedis.hgetAll("example-1"));

		System.out.println("<===============================>");
		List<String> str = jedis.hmget("example-1", "Name", "Age", "contact No");
		System.out.println(str);

		System.out.println("<===============================>");
		List<String> vals = jedis.hvals("example-1");
		System.out.println(vals);

		System.out.println("<===============================>");
		Set<String> keys = jedis.hkeys("example-1");
		System.out.println(keys);

		if (jedis != null) {
			jedis.close();
			System.out.println("Connection is close");
		}

	}

}
