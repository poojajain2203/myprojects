package com.confluxsys.graphql.practice;

import java.util.ArrayList;
import java.util.List;

public class ProductRepo {

	List<Product> products = new ArrayList<Product>();

	public ProductRepo() {

		Product p1 = new Product("101", "Product1", 20.35f);
		Product p2 = new Product("102", "Product2", 20.35f);
		Product p3 = new Product("103", "Product3", 20.35f);
		Product p4 = new Product("104", "Product4", 20.35f);
		Product p5 = new Product("105", "Product5", 20.35f);
		Product p6 = new Product("106", "Product6", 20.35f);
		Product p7 = new Product("107", "Product7", 20.35f);
		Product p8 = new Product("108", "Product8", 20.35f);

		products.add(p1);
		products.add(p2);
		products.add(p3);
		products.add(p4);
		products.add(p5);
		products.add(p6);
		products.add(p7);
		products.add(p8);
	}

	public Product getProductById(String id) {

		for (int i = 0; i < products.size(); i++) {

			if (products.get(i).getId().equals(id)) {
				return products.get(i);
			}
		}
		return null;
	}

	public List<Product> getAllProduct() {

		return products;

	}

}
