package com.confluxsys.graphql.fieldselection;

public class User {

	String id;
	String name;
	int age;
	int weight;
	Friends friedns;

	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(String id, String name, int age, int weight, Friends friends) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.weight = weight;
		this.friedns = friends;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public int getWeight() {
		return weight;
	}
	
	public Friends getFriends() {
		return friedns;
	}

}
