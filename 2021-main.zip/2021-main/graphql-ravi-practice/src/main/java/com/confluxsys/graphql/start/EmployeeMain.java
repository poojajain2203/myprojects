package com.confluxsys.graphql.start;

import java.io.File;
import java.util.Map;

import graphql.GraphQL;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;

public class EmployeeMain {

	public static void main(String[] args) {

		SchemaParser schemaParser = new SchemaParser();
		SchemaGenerator schemaGenerator = new SchemaGenerator();

		// load the schema file:

		File schemaFile = new File(
				"C:\\Users\\Ravi Ranjan\\eclipse-workspace\\graphql-ravi-practice\\src\\main\\resources\\schema.graphqls");

		TypeDefinitionRegistry typeDefinitionRegistry = schemaParser.parse(schemaFile);
		RuntimeWiring runtimeWiring = buildRuntimeWiring();

		GraphQLSchema graphQLSchema = schemaGenerator.makeExecutableSchema(typeDefinitionRegistry, runtimeWiring);

		// GraphQL build = GraphQL.newGraphQL(graphQLSchema).build();

		// ExecutionResult res = build.execute("{id name}");

		// System.out.println(res.getData().toString());	
		
		
		Map<String, String> data = GraphQL.newGraphQL(graphQLSchema).build().execute("{id name}").getData();
		System.out.println(data);
		
		
		Map<String,String> data1= (Map<String, String>)new GraphQL(graphQLSchema).execute("{id name}").getData();
		System.out.println(data1);

	}

	static RuntimeWiring buildRuntimeWiring() {
		return RuntimeWiring.newRuntimeWiring()
				.type("Employee", builder -> builder.dataFetcher("id", EmployeeStaticDataFetcher.getEmployeeId())
						.dataFetcher("name", EmployeeStaticDataFetcher.getEmployeeName()))
				.build();
	}

}
