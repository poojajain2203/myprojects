package com.confluxsys.graphql.async.df;

import java.io.File;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;

//Knowing the field selection set can help make DataFetchers more efficient.

// https://stackoverflow.com/questions/18722471/when-to-use-double-star-in-glob-syntax-within-java

public class Main {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub

		SchemaParser schemaParser = new SchemaParser();
		SchemaGenerator schemaGenerator = new SchemaGenerator();

		File file = loadSchema(
				"C:\\Users\\Ravi Ranjan\\eclipse-workspace\\graphql-ravi-practice\\src\\main\\resources\\employee_address_async.graphqls");

		TypeDefinitionRegistry typeDefinitionRegistry = schemaParser.parse(file);
		GraphQLSchema graphQLSchema = schemaGenerator.makeExecutableSchema(typeDefinitionRegistry, buidRuntimeWiring());

		GraphQL graphQL = GraphQL.newGraphQL(graphQLSchema).build();

		ExecutionInput executionInput = ExecutionInput.newExecutionInput()
				.query("query{getAllEmployee{emp_name emp_address emp_email}}").build();

		/*
		 * ExecutionResult promise1 = graphQL.execute(executionInput);
		 * System.out.println(promise1.getData().toString());
		 */
		CompletableFuture<ExecutionResult> promise = graphQL.executeAsync(executionInput);

		System.out.println("inSide Main:=>" + promise.isDone());

		promise.thenAccept(executionResult -> {
			try {
				System.out.println("Employee Details:=>");
				System.out.println("Data=>" + promise.get().getData().toString());
			} catch (InterruptedException | ExecutionException e) { // TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		// System.out.println("Data=>" + promise.get().getData().toString());

		System.out.println("Before Join=>" + promise.isDone());
		// promise.join();

		System.out.println("After Join=>" + promise.isDone());

		System.out.println(promise);
	}

	private static RuntimeWiring buidRuntimeWiring() {

		return RuntimeWiring.newRuntimeWiring()
				.type("QueryType", builder -> builder.dataFetcher("getAllEmployee", employeeDataFetcher1())).build();
	}

	private static DataFetcher<CompletableFuture<List<Employee>>> employeeDataFetcher1() {

		return new DataFetcher<CompletableFuture<List<Employee>>>() {

			@Override
			public CompletableFuture<List<Employee>> get(DataFetchingEnvironment environment) throws Exception {
				EmployeeRepo employeeRepo = new EmployeeRepo();

				CompletableFuture<List<Employee>> listEmp = CompletableFuture.supplyAsync(() -> {
					return employeeRepo.getAllEmployee();
				});

				// System.out.println("listEmp:=>"+listEmp.get().size());

				System.out.println("insideDatafetcher:=>" + listEmp.isDone());
				return listEmp;
			}

		};
	}

	private static DataFetcher<Object> employeeDataFetcher() {

		return new DataFetcher<Object>() {

			@Override
			public Object get(DataFetchingEnvironment environment) throws Exception {
				EmployeeRepo employeeRepo = new EmployeeRepo();

				return employeeRepo.getAllEmployee();

			}

		};
	}

	private static File loadSchema(String string) {

		return new File(string);
	}

}
