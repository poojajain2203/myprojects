package com.confluxsys.graphql.fieldselection;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.DataFetchingFieldSelectionSet;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLSchema;
import graphql.schema.SelectedField;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;

//Knowing the field selection set can help make DataFetchers more efficient.

// https://stackoverflow.com/questions/18722471/when-to-use-double-star-in-glob-syntax-within-java

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SchemaParser schemaParser = new SchemaParser();
		SchemaGenerator schemaGenerator = new SchemaGenerator();

		File file = loadSchema(
				"C:\\Users\\Ravi Ranjan\\eclipse-workspace\\graphql-ravi-practice\\src\\main\\resources\\userfriend.graphqls");

		TypeDefinitionRegistry typeDefinitionRegistry = schemaParser.parse(file);
		GraphQLSchema graphQLSchema = schemaGenerator.makeExecutableSchema(typeDefinitionRegistry, buidRuntimeWiring());

		GraphQL graphQL = GraphQL.newGraphQL(graphQLSchema).build();

		ExecutionInput executionInput = ExecutionInput.newExecutionInput()
				.query("query{user(id:\"115\"){id name age friends{name age}}}").build();

		ExecutionResult executionResult = graphQL.execute(executionInput);

		Object object = executionResult.getData();
		System.out.println("Object:=>" + object);

		Map<String, Object> serializingResultToJson = executionResult.toSpecification();
		
		//jackson-core dependency
		try {
			String res = new ObjectMapper().writeValueAsString(serializingResultToJson);
			System.out.println(res);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

	private static RuntimeWiring buidRuntimeWiring() {

		return RuntimeWiring.newRuntimeWiring()
				.type("QueryType", builder -> builder.dataFetcher("user", userDataFetcher())).build();
	}

	private static DataFetcher<User> userDataFetcher() {

		return new DataFetcher<User>() {

			@Override
			public User get(DataFetchingEnvironment environment) throws Exception {
				String id = environment.getArgument("id");
				System.out.println("id:=>" + id);

				DataFetchingFieldSelectionSet dataFetchingFieldSelectionSet = environment.getSelectionSet();

				Map<String, GraphQLFieldDefinition> res = dataFetchingFieldSelectionSet.getDefinitions();
				System.out.println("DataFetchingFieldSelectionSet Result:=>");
				for (Map.Entry<String, GraphQLFieldDefinition> map : res.entrySet()) {
					System.out.println("Key:=>" + map.getKey());
					System.out.println("Value:=>" + map.getValue());
				}

				List<SelectedField> field = dataFetchingFieldSelectionSet.getFields("fri*end*"); // * , friends/* , for
																									// inner field use=>
																									// friends, friend?,
																									// fri*end*
				field.forEach(selectedField -> {
					System.out.println("FieldName:=>" + selectedField.getName());
					// System.out.println(selectedField.getFieldDefinition().getType());

					// innerField

					System.out.println("=====Inner Field===");
					DataFetchingFieldSelectionSet innerField = selectedField.getSelectionSet();

					Map<String, GraphQLFieldDefinition> inf = innerField.getDefinitions();

					for (Map.Entry<String, GraphQLFieldDefinition> res1 : inf.entrySet()) {
						System.out.println("key:=>" + res1.getKey());

					}

				});

				System.out.println("===SelectedField===");
				SelectedField sf = dataFetchingFieldSelectionSet.getField("name");
				System.out.println(
						"selectedField:=>Name:" + sf.getName() + " Type:=>" + sf.getFieldDefinition().getType());

				if (dataFetchingFieldSelectionSet.contains("friends/name")) {
					UserRepo userRepo = new UserRepo();
					return userRepo.getUser(id);
				} else {
					System.out.println("NULL");
					return null;
				}
			}
		};
	}

	private static File loadSchema(String string) {

		return new File(string);
	}

}
