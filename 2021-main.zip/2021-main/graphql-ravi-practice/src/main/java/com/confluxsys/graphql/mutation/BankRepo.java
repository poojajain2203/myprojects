package com.confluxsys.graphql.mutation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BankRepo {

	List<Bank> accouts = new ArrayList<Bank>();

	public BankRepo() {

		Bank b1 = new Bank("101", "ABCD345", "Test", 56.3f);
		Bank b2 = new Bank("102", "ABCD3566", "Unique", 569.377f);
		accouts.add(b1);
		accouts.add(b2);
	}

	public List<Bank> getAllAccounts() {
		return accouts;
	}

	public Bank addAccount(Map<String, Object> arg) {

		System.out.println("====inside Repo addAccount Method:===");
		System.out.println("MapItem=>" + arg);
		String id = null;
		String acc_no = null;
		String acc_holder_name = null;
		float bal = 0.0f;
		for (Map.Entry<String, Object> map : arg.entrySet()) {
			if (map.getKey().equals("id")) {
				id = (String) map.getValue();
			} else if (map.getKey().equals("acc_no")) {
				acc_no = (String) map.getValue();
			} else if (map.getKey().equals("acc_holder_name")) {
				acc_holder_name = (String) map.getValue();
			} else if (map.getKey().equals("bal")) {
				// Object obj = map.getValue();

				// bal = Float.parseFloat((String)obj);
			}

		}

		System.out.println(id + " " + acc_holder_name + " " + acc_no + " " + bal);

		Bank bank = new Bank(id, acc_no, acc_holder_name, bal);
		accouts.add(bank);

		return bank;
	}

}
