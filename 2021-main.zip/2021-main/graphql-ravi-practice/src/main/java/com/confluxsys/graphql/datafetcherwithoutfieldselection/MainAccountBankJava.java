package com.confluxsys.graphql.datafetcherwithoutfieldselection;

import java.util.List;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.GraphQLError;

public class MainAccountBankJava {

	public static void main(String[] args) {
		
		GraphQL graphQL = AccountBankSchema.getGraphQL();
		
		ExecutionInput executionInput = ExecutionInput.newExecutionInput().query("query{accountHolderDetails{id account_holder_name account_no} bankMetaData{ifsc bank_name} }").build();
		
		ExecutionResult executionResult  = graphQL.execute(executionInput);
		
		Object result = executionResult.getData();
		System.out.println("Data=>"+result);
		
		List<GraphQLError> errors = executionResult.getErrors();
		System.out.println("errors=>"+errors);
		
		

	}

}
