package com.confluxsys.graphql.mutation;

public class Bank {

	String id;
	String acc_no;
	String acc_holder_name;
	float bal;

	public Bank() {
		// TODO Auto-generated constructor stub
	}

	public Bank(String id, String acc_no, String acc_holder_name, float bal) {
		super();
		this.id = id;
		this.acc_no = acc_no;
		this.acc_holder_name = acc_holder_name;
		this.bal = bal;
	}

	public String getId() {
		return id;
	}

	public String getAcc_no() {
		return acc_no;
	}

	public String getAcc_holder_name() {
		return acc_holder_name;
	}

	public float getBal() {
		return bal;
	}

}
