package com.confluxsys.graphql.fieldselection;

public class Friends {

	String name;
	int age;

	public Friends() {
		// TODO Auto-generated constructor stub
	}

	public Friends(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

}
