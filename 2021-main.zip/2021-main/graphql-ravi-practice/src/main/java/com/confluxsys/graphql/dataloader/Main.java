package com.confluxsys.graphql.dataloader;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import org.dataloader.BatchLoader;
import org.dataloader.DataLoader;
import org.dataloader.DataLoaderRegistry;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.execution.instrumentation.dataloader.DataLoaderDispatcherInstrumentation;
import graphql.execution.instrumentation.dataloader.DataLoaderDispatcherInstrumentationOptions;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		SchemaParser schemaParser = new SchemaParser();
		SchemaGenerator schemaGenerator = new SchemaGenerator();
		File schema = loadSchema(
				"C:\\Users\\Ravi Ranjan\\eclipse-workspace\\graphql-ravi-practice\\src\\main\\resources\\author_book_dataloader.graphqls");

		if (schema.exists()) {

			TypeDefinitionRegistry typeDefinitionRegistry = schemaParser.parse(schema);

			GraphQLSchema graphQLSchema = schemaGenerator.makeExecutableSchema(typeDefinitionRegistry,
					buildRunTimeWiring());

			BatchLoader<String, Book> bookBatchLoader = new BatchLoader<String, Book>() {

				@Override
				public CompletionStage<List<Book>> load(List<String> keys) {

					AuthorRepo authorRepo = new AuthorRepo();
					System.out.println("keys:" + keys);
					return CompletableFuture.supplyAsync(() -> authorRepo.getDataBooks(keys));
				}

			};

			DataLoader<String, Book> authorDataLoader = DataLoader.newDataLoader(bookBatchLoader);

			// DataFetcher authorDataFetcher = authorDataFetcher();

			// DataFetcher bookDataFetcher = bookDataFethcher();

			DataLoaderDispatcherInstrumentationOptions options = DataLoaderDispatcherInstrumentationOptions.newOptions()
					.includeStatistics(true);

			DataLoaderDispatcherInstrumentation dispatcherInstrumentation = new DataLoaderDispatcherInstrumentation(
					options);

			GraphQL graphQL = GraphQL.newGraphQL(graphQLSchema).instrumentation(dispatcherInstrumentation).build();

			DataLoaderRegistry registry = new DataLoaderRegistry();
			registry.register("author", authorDataLoader);

			String query = "query{getAllAuthorsAndBook(id:\"1\") {book{btitle}}}";
			ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).dataLoaderRegistry(registry)
					.build();

			ExecutionResult result = graphQL.execute(executionInput);
			System.out.println("Result::=>" + result.getData().toString());
		} else {
			throw new FileNotFoundException("invalid Path");

		}

	}

	private static RuntimeWiring buildRunTimeWiring() {
		// TODO Auto-generated method stub
		return RuntimeWiring.newRuntimeWiring()
				.type("QueryType", builder -> builder.dataFetcher("getAllAuthorsAndBook", authorDataFetcher()))
				.type("QueryType", builder -> builder.dataFetcher("getAllAuthorsAndBook", bookDataFethcher())).build();
	}

	private static DataFetcher bookDataFethcher() {
		// TODO Auto-generated method stub
		return new DataFetcher() {
			@Override
			public Object get(DataFetchingEnvironment environment) throws Exception {
				Book book = environment.getSource();
				AuthorRepo authorRepo = new AuthorRepo();
				String id = environment.getArgument("id");
				List<String> booksids = authorRepo.getBooksId(id);

				System.out.println("Books IDs are::" + booksids);

				DataLoader<String, Object> dataLoader = environment.getDataLoader("author");
				// System.out.println("DataLoder inside bookDataFetcher::"+dataLoader);
				return dataLoader.loadMany(booksids);
			}
		};
	}

	private static DataFetcher authorDataFetcher() {
		// TODO Auto-generated method stub
		return new DataFetcher() {
			@Override
			public Object get(DataFetchingEnvironment environment) throws Exception {
				// TODO Auto-generated method stub
				DataLoader<String, Object> dataLoader = environment.getDataLoader("author");
				System.out.println("DataLoader inside authorDataFetcher::" + dataLoader);
				String id = environment.getArgument("id");
				return dataLoader.load(id); // 1
			}
		};
	}

	private static File loadSchema(String path) {
		// TODO Auto-generated method stub
		return new File(path);
	}

}
