package com.confluxsys.graphql.practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.GraphQLError;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {

		SchemaParser schemaParser = new SchemaParser();
		SchemaGenerator schemaGenerator = new SchemaGenerator();

		File schemaFile = loadSchema(
				"C:\\Users\\Ravi Ranjan\\eclipse-workspace\\graphql-ravi-practice\\src\\main\\resources\\product.graphqls");

		if (schemaFile.exists()) {

			TypeDefinitionRegistry typeDefinitionRegistry = schemaParser.parse(schemaFile);

			GraphQLSchema graphQLSchema = schemaGenerator.makeExecutableSchema(typeDefinitionRegistry,
					buildRunTimeWiring());

			GraphQL graphQL = GraphQL.newGraphQL(graphQLSchema).build();

			ExecutionInput executionInput = ExecutionInput.newExecutionInput()
					.query("query{getProductById(id :\"105\"){id pName pCost}}").build();
			ExecutionResult executionResult = graphQL.execute(executionInput);

			Object result = executionResult.getData();

			System.out.println("Result:=>" + result);
			List<GraphQLError> graphQLError = executionResult.getErrors();
			System.out.println("Error:=>" + graphQLError);

			ExecutionInput executionInput2 = ExecutionInput.newExecutionInput()
					.query("query{getProduct{id pName pCost}}").build();

			ExecutionResult executionResult2 = graphQL.execute(executionInput2);

			Map<String, Product> productMap = executionResult2.getData();
			System.out.println("products=>" + productMap);

		} else {
			throw new FileNotFoundException();
		}

	}

	private static File loadSchema(String string) {
		// TODO Auto-generated method stub
		return new File(string);
	}

	private static RuntimeWiring buildRunTimeWiring() {

		return RuntimeWiring.newRuntimeWiring().type("QueryType", wiring -> wiring
				.dataFetcher("getProductById", getProductByID()).dataFetcher("getProduct", getAllProducts())).build();

	}

	private static DataFetcher<List<Product>> getAllProducts() {
		// TODO Auto-generated method stub
		return new DataFetcher<List<Product>>() {

			@Override
			public List<Product> get(DataFetchingEnvironment environment) throws Exception {
				// TODO Auto-generated method stub

				ProductRepo productRepo = new ProductRepo();

				return productRepo.getAllProduct();
			}
		};
	}

	private static DataFetcher<Product> getProductByID() {
		// TODO Auto-generated method stub
		return new DataFetcher<Product>() {

			@Override
			public Product get(DataFetchingEnvironment environment) throws Exception {

				String id = environment.getArgument("id");
				System.out.println(id);
				
				
				
				/*
				 * Map<String, Object> getArguments() - this represents the arguments that have
				 * been provided on a field and the values of those arguments that have been
				 * resolved from passed in variables, AST literals and default argument values.
				 * You use the arguments of a field to control what values it returns.
				 */

				//Map<String , Object> arg =environment.getArguments();
				 //System.out.println("arguments:=>"+arg);
				if (id != null) {
					ProductRepo productRepo = new ProductRepo();
					return productRepo.getProductById(id);

				} else {
					System.out.println("Invalid Id");
					return null;
				}

			}
		};
	}

}
