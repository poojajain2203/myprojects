package com.confluxsys.graphql.fieldselection;

import java.util.ArrayList;
import java.util.List;

public class UserRepo {

	List<User> list = new ArrayList<User>();

	public UserRepo() {
		User u1 = new User("110", "Ravi", 21, 73, new Friends("Test1", 22));
		User u2 = new User("111", "Ravi", 21, 73, new Friends("Test2", 22));
		User u3 = new User("112", "Ravi", 21, 73, new Friends("Test3", 22));
		User u4 = new User("113", "Ravi", 21, 73, new Friends("Test4", 22));
		User u5 = new User("114", "Ravi", 21, 73, new Friends("Test5", 22));
		User u6 = new User("115", "Ravi", 21, 73, new Friends("Test6", 22));
		User u7 = new User("116", "Ravi", 21, 73, new Friends("Test7", 22));
		User u8 = new User("117", "Ravi", 21, 73, new Friends("Test8", 22));

		list.add(u1);
		list.add(u2);
		list.add(u3);
		list.add(u4);
		list.add(u5);
		list.add(u6);
		list.add(u7);
		list.add(u8);
	}

	public User getUser(String id) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getId().equalsIgnoreCase(id)) {
				return list.get(i);
			}
		}
		return null;
	}

}
