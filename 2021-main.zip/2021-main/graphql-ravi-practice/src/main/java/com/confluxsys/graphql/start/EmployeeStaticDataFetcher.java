package com.confluxsys.graphql.start;

import graphql.schema.DataFetcher;
import graphql.schema.StaticDataFetcher;

public class EmployeeStaticDataFetcher extends StaticDataFetcher {

	public EmployeeStaticDataFetcher(Object value) {
		super(value);
		// TODO Auto-generated constructor stub
	}

	static DataFetcher<String> employeeId = data -> {

		String id = "101";
		return id;
	};

	static DataFetcher<String> employeeName = data -> {

		String name = "Ravi";
		return name;
	};

	public static DataFetcher<String> getEmployeeId() {
		return employeeId;
	}

	public static DataFetcher<String> getEmployeeName() {
		return employeeName;
	}

}
