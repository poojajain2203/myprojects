package com.confluxsys.graphql.mutation.newjavaimpl;

import java.util.ArrayList;
import java.util.List;

public class BankRepo {

	List<Bank> accouts = new ArrayList<Bank>();

	public BankRepo() {

		Bank b1 = new Bank("101", "ABCD345", "Test", 56.3f);
		Bank b2 = new Bank("102", "ABCD3566", "Unique", 569.377f);
		accouts.add(b1);
		accouts.add(b2);
	}

	public List<Bank> getAllAccounts() {
		return accouts;
	}
	
	public Bank addAccount(String id, String acc_no , String acc_holder_name ,float bal) {
		Bank bank = new Bank(id, acc_no, acc_holder_name, bal);
		accouts.add(bank);
		return bank;
	}

}
