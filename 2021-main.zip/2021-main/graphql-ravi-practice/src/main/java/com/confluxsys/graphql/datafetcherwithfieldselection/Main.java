package com.confluxsys.graphql.datafetcherwithfieldselection;

import java.io.File;
import java.util.Scanner;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;

public class Main {

	public static void main(String[] args) {

		SchemaParser schemaParser = new SchemaParser();
		SchemaGenerator schemaGenerator = new SchemaGenerator();

		File schemaFile = loadSchema(
				"C:\\Users\\Ravi Ranjan\\eclipse-workspace\\graphql-ravi-practice\\src\\main\\resources\\employeeds.graphqls");
		TypeDefinitionRegistry typeDefinitionRegistry = schemaParser.parse(schemaFile);

		GraphQLSchema graphQLSchema = schemaGenerator.makeExecutableSchema(typeDefinitionRegistry,
				buildRuntimeWiring());

		GraphQL graphQL = GraphQL.newGraphQL(graphQLSchema).build();

		ExecutionInput executionInput = ExecutionInput.newExecutionInput()
				.query("query{employeeDetails{id name address{state city}}}").build();

		/*
		 * Scanner sc = new Scanner(System.in); System.out.println("Enter Query:");
		 * String query = sc.nextLine();
		 * 
		 * ExecutionInput executionInput =
		 * ExecutionInput.newExecutionInput(query).build();
		 */

		ExecutionResult executionResult = graphQL.execute(executionInput);

		System.out.println(executionResult.getData().toString());

	}

	private static DataFetcher<Employee> getEmployee() {

		return new DataFetcher<Employee>() {

			@Override
			public Employee get(DataFetchingEnvironment environment) throws Exception {

				Employee employee = new Employee("101", "Ravi Ranjan", new Address("HMH", "Rajasthan"));

				return employee;
			}
		};

	}

	private static File loadSchema(String string) {
		return new File(string);
	}

	private static RuntimeWiring buildRuntimeWiring() {

		return RuntimeWiring.newRuntimeWiring()
				.type("QueryType", typeWiring -> typeWiring.dataFetcher("employeeDetails", getEmployee())).build();

	}

}
