package com.confluxsys.graphql.dataloader;

public class Book {

	String bid;
	String btitle;
	String bdec;
	String byear;

	public Book() {
		// TODO Auto-generated constructor stub
	}

	public Book(String bid, String btitle, String bdec, String byear) {
		super();
		this.bid = bid;
		this.btitle = btitle;
		this.bdec = bdec;
		this.byear = byear;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getBtitle() {
		return btitle;
	}

	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}

	public String getBdec() {
		return bdec;
	}

	public void setBdec(String bdec) {
		this.bdec = bdec;
	}

	public String getByear() {
		return byear;
	}

	public void setByear(String byear) {
		this.byear = byear;
	}

}
