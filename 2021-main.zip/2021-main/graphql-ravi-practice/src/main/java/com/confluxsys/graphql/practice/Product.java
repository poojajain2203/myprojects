package com.confluxsys.graphql.practice;

public class Product {

	String id;
	String pName;
	float pCost;

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(String id, String pName, float pCost) {
		super();
		this.id = id;
		this.pName = pName;
		this.pCost = pCost;
	}

	public String getId() {
		return id;
	}

	public String getpName() {
		return pName;
	}

	public float getpCost() {
		return pCost;
	}
}
