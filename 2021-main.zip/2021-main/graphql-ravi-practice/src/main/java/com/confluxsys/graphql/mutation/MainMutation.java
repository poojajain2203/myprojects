package com.confluxsys.graphql.mutation;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.FieldCoordinates;
import graphql.schema.GraphQLCodeRegistry;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;
import jdk.nashorn.internal.ir.CallNode.EvalArgs;

public class MainMutation {

	public static void main(String[] args) throws FileNotFoundException {
		SchemaParser schemaParser = new SchemaParser();
		SchemaGenerator schemaGenerator = new SchemaGenerator();

		File schema = new File(
				"C:\\Users\\Ravi Ranjan\\eclipse-workspace\\graphql-ravi-practice\\src\\main\\resources\\bank_mutation.graphqls");

		if (schema.exists()) {

			TypeDefinitionRegistry typeRuntimeWiring = schemaParser.parse(schema);

			GraphQLSchema graphQLSchema = schemaGenerator.makeExecutableSchema(typeRuntimeWiring, buildRunTimeWiring());

			GraphQL graphQL = GraphQL.newGraphQL(graphQLSchema).build();

			/*
			 * ExecutionInput executionInput = ExecutionInput.newExecutionInput()
			 * .query("query{getAllAccount{acc_no acc_holder_name bal}}").build();
			 * 
			 * ExecutionResult executionResult = graphQL.execute(executionInput);
			 * 
			 * System.out.println(executionResult.getData().toString());
			 */
			
			String query = "mutation {createAccount(id:\"103\",acc_no:\"2345\",acc_holder_name:\"GraphLQL\",bal:20.5) {acc_no,id,acc_holder_name}}";

			ExecutionInput executionInput2 = ExecutionInput.newExecutionInput().query(query).build();
			ExecutionResult executionResult2 = graphQL.execute(executionInput2);
			System.out.println(executionResult2.isDataPresent());
			System.out.println(executionResult2.getData().toString());

		} else {
			throw new FileNotFoundException("File Path is wrong or File is missing");
		}
	}

	private static RuntimeWiring buildRunTimeWiring() {
		// TODO Auto-generated method stub
		return RuntimeWiring.newRuntimeWiring()
				.type("QueryType", builder -> builder.dataFetcher("getAllAccount", getAllAccounts()))

				.type("Mutation", builder -> builder.dataFetcher("createAccount", addBankAccount())).build();
	}

	private static DataFetcher<Bank> addBankAccount() { // TODO Auto-generated method stub
		return new DataFetcher<Bank>() {

			@Override
			public Bank get(DataFetchingEnvironment environment) throws Exception {

				System.out.println("===inside addBankAccount()=====");
				  Map<String, Object> arg = environment.getArguments();
				  System.out.println("MapItem:=>=>" + arg);
				 
				
//				String id = environment.getArgument("id");
//				String acc_no = environment.getArgument("acc_no");
//				String acc_holder_name = environment.getArgument("acc_holder_name");
			
				//float bal = environment.getArgumentOrDefault("bal", 0.0f);//float is not working.
				
				
				BankRepo bank = new BankRepo();
				return bank.addAccount(arg);
			}
		};
	}

	private static DataFetcher<List<Bank>> getAllAccounts() {

		return new DataFetcher<List<Bank>>() {

			@Override
			public List<Bank> get(DataFetchingEnvironment environment) throws Exception {
				BankRepo bankRepo = new BankRepo();
				return bankRepo.getAllAccounts();
			}
		};
	}

}