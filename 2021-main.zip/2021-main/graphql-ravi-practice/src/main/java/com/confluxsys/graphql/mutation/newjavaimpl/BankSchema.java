
package com.confluxsys.graphql.mutation.newjavaimpl;

import java.util.List;
import java.util.Map;

import graphql.GraphQL;
import graphql.Scalars;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.FieldCoordinates;
import graphql.schema.GraphQLArgument;
import graphql.schema.GraphQLCodeRegistry;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLInputObjectField;
import graphql.schema.GraphQLInputObjectType;
import graphql.schema.GraphQLList;
import graphql.schema.GraphQLNonNull;
import graphql.schema.GraphQLObjectType;
import graphql.schema.GraphQLScalarType;
import graphql.schema.GraphQLSchema;
import jdk.nashorn.internal.ir.CallNode.EvalArgs;

public class BankSchema {

	/*
	 * 
	 * type QueryType{ getAllAccount : [Bank]!
	 * 
	 * }
	 * 
	 * type Mutation{ createAccount( id:String!, acc_no : String!, acc_holder_name:
	 * String!, bal : Float! ) : Bank }
	 * 
	 * type Bank{ id:String! acc_no : String! acc_holder_name: String! bal : Float!
	 * }
	 * 
	 * 
	 */

	// Type Bank.

	private static GraphQLObjectType bankType = GraphQLObjectType.newObject().name("Bank")
			.description("Storing The Bank Account")
			.field(GraphQLFieldDefinition.newFieldDefinition().name("id").description("bank account id")
					.type(Scalars.GraphQLString))
			.field(GraphQLFieldDefinition.newFieldDefinition().name("acc_no").description("bank account no")
					.type(Scalars.GraphQLString))
			.field(GraphQLFieldDefinition.newFieldDefinition().name("acc_holder_name")
					.description("bank account holder name").type(Scalars.GraphQLString))
			.field(GraphQLFieldDefinition.newFieldDefinition().name("bal").description("use account balance")
					.type(Scalars.GraphQLInt))
			.build();

	// Type QueryType
	@SuppressWarnings("deprecation")
	private static GraphQLObjectType queryType = GraphQLObjectType.newObject().name("QueryType")
			.description("lookup the all account details")
			.field(GraphQLFieldDefinition.newFieldDefinition().name("getAllAccount")
					.description("return the all bank accoutns detail list.")
					.type(new GraphQLList(bankType/* new GraphQLNonNull(bankType) */)).dataFetcher(bankDataFetcher()))
			.build();

	//
	
	//

	private static GraphQLObjectType mutationCreateAccount = GraphQLObjectType.newObject().name("addAccount")
			.field(GraphQLFieldDefinition.newFieldDefinition().name("createAccount").type(bankType)
					.argument(GraphQLArgument.newArgument().name("id").type(Scalars.GraphQLString))
					.argument(GraphQLArgument.newArgument().name("acc_no").type(Scalars.GraphQLString))
					.argument(GraphQLArgument.newArgument().name("acc_holder_name").type(Scalars.GraphQLString))
					.argument(GraphQLArgument.newArgument().name("bal").type(Scalars.GraphQLInt)))
			.build();

	//
	private static GraphQLCodeRegistry graphQLCodeRegistry = GraphQLCodeRegistry.newCodeRegistry()
			.dataFetcher(FieldCoordinates.coordinates("addAccount", "createAccount"), createAccountDataFetcher())
			.build();

	//
	private static GraphQLSchema graphQLSchema = GraphQLSchema.newSchema().query(queryType)
			.mutation(mutationCreateAccount).codeRegistry(graphQLCodeRegistry).build();

	private static GraphQL graphQL = GraphQL.newGraphQL(graphQLSchema).build();

	public static GraphQL getGraphQL() {
		return graphQL;
	}

	private static DataFetcher<Bank> createAccountDataFetcher() {
		// TODO Auto-generated method stub
		return new DataFetcher<Bank>() {

			@Override
			public Bank get(DataFetchingEnvironment environment) throws Exception {

				 String id =environment.getArgument("id");
				 String acc_no = environment.getArgument("acc_no");
				 String acc_holder_name = environment.getArgument("acc_holder_name");
				 int bal = environment.getArgument("bal");
				 
				 
				 System.out.println(id+" "+acc_no+" "+acc_holder_name+" "+bal);
				return new Bank(id,acc_no,acc_holder_name,bal);
				// return null;
			}
		};
	}

	private static DataFetcher<List<Bank>> bankDataFetcher() {

		return new DataFetcher<List<Bank>>() {

			@Override
			public List<Bank> get(DataFetchingEnvironment environment) throws Exception {
				BankRepo bankrepo = new BankRepo();
				List<Bank> b = bankrepo.getAllAccounts();
				System.out.println("list size:=>" + b.size());
				// Bank b = new Bank("1","rr","tt",78.08f);
				return b;

			}
		};
	}

}
