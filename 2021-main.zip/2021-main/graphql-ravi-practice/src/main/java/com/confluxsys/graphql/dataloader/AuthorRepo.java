package com.confluxsys.graphql.dataloader;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AuthorRepo {

	String url = "jdbc:postgresql://localhost:5432/test";
	String un = "postgres";
	String pw = "14july";
	Connection con = null;
	Statement stmt = null;
	ResultSet res = null;

	public AuthorRepo() {

		System.out.println("----inside AuthoreRepo Constructor------");
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try {
			con = DriverManager.getConnection(url, un, pw);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<Book> getDataBooks(List<String> keys) {

		System.out.println("----inside getDataBooks AuthoreRepo-------");
		List<Book> books = new ArrayList<Book>();
		try {

			for (int i = 0; i < keys.size(); i++) {
				String queySubject = "SELECT * FROM BOOK WHERE AUTHOR_ID IN ('" + keys.get(i) + "')";
				stmt = con.createStatement();
				res = stmt.executeQuery(queySubject);

				while (res.next()) {
					String bid = res.getString("book_id");
					String btitle = res.getString("book_title");
					String bdec = res.getString("book_description");
					String byear = res.getString("book_pub_year");
					books.add(new Book(bid, btitle, bdec, byear));
				}
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (con != null || res != null || stmt != null) {
				try {
					con.close();
					stmt.close();
					res.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
		System.out.println("-------outside getDataBooks AuthoreRepo::" + books);
		return books;
	}

	public List<String> getBooksId(String id) {
		System.out.println("----inside getBookId AuthoreRepo-------");
		List<String> booksids = new ArrayList<String>();
		try {
			String queySubject = "SELECT book_id FROM BOOK WHERE AUTHOR_ID IN ('" + id + "')";
			stmt = con.createStatement();
			res = stmt.executeQuery(queySubject);

			while (res.next()) {
				String book_id = res.getString("book_id");
				booksids.add(book_id);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (con != null || res != null || stmt != null) {
				try {
					con.close();
					stmt.close();
					res.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
		System.out.println("-------outside getBookId AuthoreRepo::" + booksids);
		return booksids;
	}

}
