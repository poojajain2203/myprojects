package com.confluxsys.graphql.datafetcherwithoutfieldselection;

public class AccountHolder {
	
	String id;
	String account_no;
	String account_holder_name;
	
	public AccountHolder() {
		// TODO Auto-generated constructor stub
	}
	
	public AccountHolder(String id, String account_no, String account_holder_name) {
		super();
		this.id = id;
		this.account_no = account_no;
		this.account_holder_name = account_holder_name;
	}
	public String getId() {
		return id;
	}
	public String getAccount_no() {
		return account_no;
	}
	public String getAccount_holder_name() {
		return account_holder_name;
	}
	
	

}
