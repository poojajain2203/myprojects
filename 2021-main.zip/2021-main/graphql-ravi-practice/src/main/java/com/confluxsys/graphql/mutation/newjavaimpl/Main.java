package com.confluxsys.graphql.mutation.newjavaimpl;



import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;

public class Main {

	public static void main(String[] args) {
		
		
		GraphQL graphQL  = BankSchema.getGraphQL();
		
		//ExecutionInput executionInput = ExecutionInput.newExecutionInput().query("query{getAllAccount{id acc_no}}").build();
		String query = "mutation{createAccount(id:\"103\", acc_no:\"gg\",acc_holder_name:\"ravi\",bal:20) {acc_no id bal acc_holder_name}}";

		ExecutionInput executionInput = ExecutionInput.newExecutionInput().query(query).build();
		
		ExecutionResult executionResult = graphQL.execute(executionInput);
		System.out.println("isDataPresent:=>"+executionResult.isDataPresent());
		System.out.println(executionResult.getData().toString());

	}

}
