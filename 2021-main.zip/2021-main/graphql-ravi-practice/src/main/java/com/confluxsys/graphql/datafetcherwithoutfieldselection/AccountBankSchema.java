package com.confluxsys.graphql.datafetcherwithoutfieldselection;

import com.confluxsys.graphql.datafetcherwithoutfieldselection.AccountHolder;
import com.confluxsys.graphql.datafetcherwithoutfieldselection.BankMetaData;

import graphql.GraphQL;
import graphql.Scalars;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLObjectType;
import graphql.schema.GraphQLSchema;

public class AccountBankSchema {

	/*
	 * type AccountHolder { id : String! account_no : String! account_holder_name
	 * :String! }
	 */

	private static GraphQLObjectType accountHolder = GraphQLObjectType.newObject().name("AccountHolder")
			.description("bank  account holder details")
			.field(GraphQLFieldDefinition.newFieldDefinition().name("id").description("account holder id")
					.type(Scalars.GraphQLString))
			.field(GraphQLFieldDefinition.newFieldDefinition().name("account_no")
					.description("bank account holder account number").type(Scalars.GraphQLString))
			.field(GraphQLFieldDefinition.newFieldDefinition().name("account_holder_name")
					.description("bank account holder name").type(Scalars.GraphQLString))
			.build();

	/*
	 * type BankMetaData { ifsc: String! bank_name : String! }
	 */

	private static GraphQLObjectType bankMetaData = GraphQLObjectType.newObject().name("BankMetaData")
			.description("bank meta data")
			.field(GraphQLFieldDefinition.newFieldDefinition().name("ifsc").description("bank ifsc code")
					.type(Scalars.GraphQLString))
			.field(GraphQLFieldDefinition.newFieldDefinition().name("bank_name").description("bank name")
					.type(Scalars.GraphQLString))
			.build();

	/*
	 * type QueryType { accountHolderDetails : AccountHolder bankMetaData :
	 * BankMetaData }
	 */

	@SuppressWarnings("deprecation")
	private static GraphQLObjectType queryType = GraphQLObjectType.newObject().name("QueryType")
			.description("lookup details")
			.field(GraphQLFieldDefinition.newFieldDefinition().name("accountHolderDetails")
					.description("lookup account holder details").type(accountHolder).dataFetcher(accountDataFetcher()))
			.field(GraphQLFieldDefinition.newFieldDefinition().name("bankMetaData")
					.description("lookup bankmeta data details").type(bankMetaData).dataFetcher(metaDataFetcher()))
			.build();

	private static GraphQLSchema graphQLSchema = GraphQLSchema.newSchema().query(queryType).build();

	private static GraphQL graphQL = GraphQL.newGraphQL(graphQLSchema).build();

	private static DataFetcher<AccountHolder> accountDataFetcher() {
		// TODO Auto-generated method stub
		return new DataFetcher<AccountHolder>() {

			@Override
			public AccountHolder get(DataFetchingEnvironment environment) throws Exception {
				AccountHolder accountHolder = new AccountHolder("12345", "4566788890", "Ravi Ranjan");
				return accountHolder;
			}
		};
	}

	private static DataFetcher<BankMetaData> metaDataFetcher() {
		// TODO Auto-generated method stub
		return new DataFetcher<BankMetaData>() {

			@Override
			public BankMetaData get(DataFetchingEnvironment environment) throws Exception {
				// TODO Auto-generated method stub
				BankMetaData bankMetaData = new BankMetaData("1234", "BOB");
				return bankMetaData;
			}
		};
	}

	public static GraphQL getGraphQL() {
		return graphQL;
	}

}
