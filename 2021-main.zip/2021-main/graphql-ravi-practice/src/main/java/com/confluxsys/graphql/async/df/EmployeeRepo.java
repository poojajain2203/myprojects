package com.confluxsys.graphql.async.df;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmployeeRepo {

	private final String URL = "jdbc:postgresql://localhost:5432/test";
	private final String USER_NAME = "postgres";
	private final String PASSWORD = "14july";
	Connection connection = null;

	public EmployeeRepo() {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try {
			connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public List<Employee> getAllEmployee() {
		Statement statement = null;
		ResultSet resultSet = null;
		List<Employee> employees = new ArrayList<Employee>();
		try {
			final String getAllEmployee = "SELECT * FROM EMPLOYEE";
			statement = connection.createStatement();
			resultSet = statement.executeQuery(getAllEmployee);
			while (resultSet.next()) {
				Employee employee = new Employee();
				employee.setEmp_id(resultSet.getString("EMP_ID"));
				employee.setEmp_name(resultSet.getString("EMP_NAME"));
				employee.setEmp_email(resultSet.getString("EMP_EMAIL"));
				employee.setEmp_address(resultSet.getString("EMP_ADDRESS"));
				employees.add(employee);
			}
			return employees;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (connection != null || statement != null || resultSet != null) {
				try {
					connection.close();
					statement.close();
					resultSet.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return null;

	}

}
