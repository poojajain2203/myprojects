package com.confluxsys.graphql.datafetcherwithoutfieldselection;

public class BankMetaData {

	String ifsc;
	String bank_name;

	public BankMetaData() {
		// TODO Auto-generated constructor stub
	}

	public BankMetaData(String ifsc, String bank_name) {
		super();
		this.ifsc = ifsc;
		this.bank_name = bank_name;
	}

	public String getIfsc() {
		return ifsc;
	}

	public String getBank_name() {
		return bank_name;
	}

}
