package com.confluxsys.graphql.datafetcherwithoutfieldselection;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.GraphQLError;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;import jdk.nashorn.internal.ir.CallNode.EvalArgs;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {

		SchemaParser schemaParser = new SchemaParser();
		SchemaGenerator schemaGenerator = new SchemaGenerator();

		File schemaFile = loadSchema(
				"C:\\Users\\Ravi Ranjan\\eclipse-workspace\\graphql-ravi-practice\\src\\main\\resources\\bank.graphqls");

		if (schemaFile.exists()) {

			TypeDefinitionRegistry typeDefinitionRegistry = schemaParser.parse(schemaFile);

			GraphQLSchema graphQLSchema = schemaGenerator.makeExecutableSchema(typeDefinitionRegistry,
					buildRunTimeWiring());

			GraphQL graphQL = GraphQL.newGraphQL(graphQLSchema).build();

			ExecutionInput executionInput = ExecutionInput.newExecutionInput()
					.query("query{accountHolderDetails{id account_holder_name account_no} bankMetaData{ifsc bank_name} }").build();
			ExecutionResult executionResult = graphQL.execute(executionInput);

			Object result = executionResult.getData();

			System.out.println("Result:=>" + result);
			List<GraphQLError> graphQLError = executionResult.getErrors();
			System.out.println("Error:=>" + graphQLError);

		} else {
			throw new FileNotFoundException();
		}
	}

	private static File loadSchema(String string) {
		// TODO Auto-generated method stub
		return new File(string);
	}

	private static RuntimeWiring buildRunTimeWiring() {

		return RuntimeWiring.newRuntimeWiring()
				.type("QueryType", builder -> builder.dataFetcher("accountHolderDetails", accountDataFetcher())
						.dataFetcher("bankMetaData", bankMetaDataFetcher()))
				.build();

	}

	private static DataFetcher<BankMetaData> bankMetaDataFetcher() {
		// TODO Auto-generated method stub
		return new DataFetcher<BankMetaData>() {

			@Override
			public BankMetaData get(DataFetchingEnvironment environment) throws Exception {
				BankMetaData bankMetaData = new BankMetaData("1234", "HDFC");
				return bankMetaData;
			}
		};
	}

	static DataFetcher<AccountHolder> accountDataFetcher() {
		return new DataFetcher<AccountHolder>() {

			@Override
			public AccountHolder get(DataFetchingEnvironment environment) throws Exception {
				//System.out.println(environment.toString());
				AccountHolder accountHolder = new AccountHolder("123rtyj", "45678092345", "Test");

				return accountHolder;
			}
		};
	}

}
