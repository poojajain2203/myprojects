package io.vertx.first;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;

public class MyFirstVerticle extends AbstractVerticle {

	@Override
	public void start(Future<Void> startFuture) {

		vertx.createHttpServer().requestHandler(r -> {
			r.response().end("<h1>Hello First Application</h1>");
		}).listen(8081, result -> {
			if (result.succeeded()) {
				startFuture.complete();
			} else {
				startFuture.fail(result.cause());
			}
		});
	}

}
