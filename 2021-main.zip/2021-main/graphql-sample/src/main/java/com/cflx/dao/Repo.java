package com.cflx.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import graphql.language.Field;
import graphql.language.InlineFragment;
import graphql.language.Node;
import graphql.language.Selection;
import graphql.language.SelectionSet;
import graphql.relay.Relay;
import graphql.relay.Relay.ResolvedGlobalId;
import graphql.schema.DataFetchingFieldSelectionSet;
import graphql.schema.SelectedField;

/**
 * @author Ravi Ranjan
 */

public class Repo {

	/**
	 * <id, employeeMap>
	 */
	static Map<String, Object> employeeMap = null;

	static {
		employeeMap = new HashMap<String, Object>();
		Map<String, Object> emp1 = new HashMap<String, Object>();
		emp1.put("id", 10);
		emp1.put("name", "Ravi");
		emp1.put("mobileNumber", "123-XXX-34");
		Map<String, Object> addressEmp1 = new HashMap<String, Object>();
		addressEmp1.put("city", "HMH");
		addressEmp1.put("state", "Raj");
		addressEmp1.put("pincode", "335512");
		emp1.put("address", addressEmp1);
		employeeMap.put("10", emp1);

	}

	public Map<String, Object> getEmployeeDetails(Map<String, Object> parameters,
			DataFetchingFieldSelectionSet selectionSet, List<Field> field, Field f) {

		System.out.println("==========selection set==================");

		Map<String, Map<String, Object>> obj = selectionSet.getArguments();

		System.out.println(obj);

		List<SelectedField> sf = selectionSet.getFields();
		for (SelectedField s : sf) {
			System.out.println("====== :: " + s.getName());
		}

		for (Field fe : field) {
			System.out.println("######## :: " + fe.getName()); // Name OF The Quey
			System.out.println("^^^^^^^^^^^ ::" + fe.getAlias()); // alias name
			List<Node> n = fe.getSelectionSet().getChildren();
			for (Node n1 : n) {
				if (n1 instanceof Field) {
					Field g = (Field) n1;
					System.out.println("%%%%%%%%%% :: " + g.getName());

					SelectionSet s = g.getSelectionSet();
					if (s != null) {
						List<Node> ni = s.getChildren();
						for (Node nii : ni) {
							if (nii instanceof Field) {
								Field h = (Field) nii;
								System.out.println("???????? ::" + h.getName());
							}
						}

					}

				}
			}
		}

		System.out.println("===================using field============");

		System.out.println("######## :: " + f.getName()); // Name OF The Quey
		System.out.println("^^^^^^^^^^^ ::" + f.getAlias()); // alias name
		List<Node> n = f.getSelectionSet().getChildren();
		for (Node n1 : n) {
			if (n1 instanceof Field) {
				Field g = (Field) n1;
				System.out.println("%%%%%%%%%% :: " + g.getName());

				SelectionSet s = g.getSelectionSet();
				if (s != null) {
					List<Node> ni = s.getChildren();
					for (Node nii : ni) {
						if (nii instanceof Field) {
							Field h = (Field) nii;
							System.out.println("???????? ::" + h.getName());
						}
					}

				}

			}
		}

		return (Map<String, Object>) employeeMap.get(parameters.get("id").toString());
	}

	public Object getHomeDetails(Map<String, Object> parameters,
			DataFetchingFieldSelectionSet dataFetchingFieldSelectionSet, List<Field> filed, Field f) {
		// TODO Auto-generated method stub

		System.out.println("==========selection set==================");

		Map<String, Map<String, Object>> obj = dataFetchingFieldSelectionSet.getArguments();
		System.out.println(obj);

		System.out.println("==========Using Field============");

	//	SelectionSet s = f.getSelectionSet();
	//	List<Selection> selections = s.getSelections();
		List<Selection> selections = f.getSelectionSet().getSelections();
		for (Selection se : selections) {
			if (se instanceof Field) {
				Field fi = (Field) se;
				System.out.println(fi.getName());
				SelectionSet selectionSet = fi.getSelectionSet();
				if (selectionSet != null) {
					List<Field> fet = selectionSet.getSelectionsOfType(Field.class);
					List<InlineFragment> inline = selectionSet.getSelectionsOfType(InlineFragment.class);
					if (inline != null && (fet == null || fet.isEmpty())) {
						for (InlineFragment in : inline) {
							SelectionSet selset = in.getSelectionSet();
							List<Selection> sel = selset.getSelections();
							for (Selection se1 : sel) {
								if (se instanceof Field) {
									String name = in.getTypeCondition().getName();
									System.out.println(name);
									Field ft = (Field) se1;
									System.out.println(ft.getName());
									SelectionSet fd = ft.getSelectionSet();
									if (fd != null) {
										List<InlineFragment> inline2 = fd.getSelectionsOfType(InlineFragment.class);
										for (InlineFragment i : inline2) {
											String name2 = i.getTypeCondition().getName();
											System.out.println(name2);
											SelectionSet selset2 = i.getSelectionSet();
											List<Selection> se2 = selset2.getSelections();
											for (Selection h : se2) {
												if (h instanceof Field) {
													Field g = (Field) h;
													System.out.println(g.getName());
												}
											}
										}

									}
								}
							}
						}
					} else if ((inline == null || inline.isEmpty()) && fet != null) {
						for (Field g : fet) {
							System.out.println(g.getName());
						}
					} else {
						System.out.println("Invalid");
					}
				}
			}

		}
		
		
		recursiveMethod(f.getSelectionSet().getSelections());
		System.out.println(generalMap);
		System.out.println(mapNormalField);
		System.out.println(mapInlineField);
		return null;
	}
	List<String> normalField = new ArrayList<String>();
	List<Object> generalMap = new ArrayList<Object>();
	
	public void recursiveMethod(List<Selection> selection) {
		if (selection == null || selection.size() == 0) {
			return;
		}
		
		Selection firstSelection = selection.get(0);
		if(firstSelection instanceof Field) {
			Field f = (Field) firstSelection;
			if(f.getSelectionSet()==null) {
				//add normal field
				generalMap.add(f.getName());
			}else {
				SelectionSet selectionSet = f.getSelectionSet();
				String nameOfParent = f.getName();
				if(selectionSet!=null) {
					List<Field> fet = selectionSet.getSelectionsOfType(Field.class);
					List<InlineFragment> inline = selectionSet.getSelectionsOfType(InlineFragment.class);
					if ((inline != null || !inline.isEmpty()) && (fet == null || fet.isEmpty())) {
						//inline nesting field fetching.
						setInlineFieldInMap(inline,nameOfParent);
						//Mapping:
						Map<String, Object> finalInline = new HashMap<String, Object>();
						for(Map.Entry<String, Object> inlineMap : mapInlineField.entrySet()) {
							List<Object> obj = (List<Object>) inlineMap.getValue();
							if(finalInline.isEmpty()) {
								finalInline.put("child", obj);
							}else {
								List<Object> temp= (List<Object>) finalInline.get("child");
								Map<String, Object> dummyMap = new HashMap<String, Object>();
								dummyMap.put("child",  (List<Object>) inlineMap.getValue());
								temp.add(dummyMap);
							}
						}
						generalMap.add(finalInline);
						mapInlineField.clear();
						
					}else {
						setFieldInMap(fet,nameOfParent);
						if(!mapNormalField.isEmpty()) {
							Map<String, Object> nestedMapping = new HashMap<String, Object>();
							for(Map.Entry<String, Object> m : mapNormalField.entrySet()) {
								if(nestedMapping.isEmpty()) {
									nestedMapping.put(m.getKey(), m.getValue());
								}else if(nestedMapping.get(m.getKey())!=null) {
									List<Object> obj = (List<Object>) m.getValue();
									Map<String, Object> temp = new HashMap<String, Object>();
									temp.put(m.getKey(), m.getValue());
									obj.add(temp);
								}else {
									//error throw.
								}
								
							}
							generalMap.add(nestedMapping);
							mapNormalField.clear();
						}
					}
				}
			}
			selection.remove(0);
			recursiveMethod(selection);
		}
		
		
		
	}
	private void setInlineFieldInMap(List<InlineFragment> inline, String nameOfParent) {
		// TODO Auto-generated method stub
		if(inline == null ||(inline.isEmpty() && inline.size()==0)) {
			return ;
		}
		
		
		//Only First Element:
		InlineFragment in = inline.get(0);
		List<Selection> selection = in.getSelectionSet().getSelections();
		mapToInlineChild(selection,nameOfParent);
	}
	int counter = 0;
	private void mapToInlineChild(List<Selection> selection, String nameOfParent) {
		// TODO Auto-generated method stub
		if(selection==null || selection.isEmpty() || selection.size()==0) {
			return ;
		}
		Selection tempSelection = selection.get(0);
		if(tempSelection instanceof Field) {
			List<Object> obj = new ArrayList<Object>();
			Field f = (Field) tempSelection;
			SelectionSet ss = f.getSelectionSet();
			if(ss==null) {
				obj.add(f.getName());
				if(mapInlineField.isEmpty()) {
					mapInlineField.put(nameOfParent+counter, obj);
				}else if(mapInlineField.get(nameOfParent+counter)!=null){
					List<Object> objtemp = (List<Object>) mapInlineField.get(nameOfParent+counter);
					objtemp.add(f.getName());
					mapInlineField.put(nameOfParent+counter, objtemp);
				}else {
					mapInlineField.put(nameOfParent+counter, obj);
					
				}
			}else {
				counter++;
				if (ss.getSelectionsOfType(InlineFragment.class) != null
						&& !ss.getSelectionsOfType(InlineFragment.class).isEmpty()) {
					setInlineFieldInMap(ss.getSelectionsOfType(InlineFragment.class), f.getName() + counter);
				}else {
					// --add impl for inline fragment normal type 
					
					/**
					 * usecase{id name}
					 * 
					 * */
					
					/*
					 * setFieldInMap(ss.getSelectionsOfType(Field.class),f.getName());
					 */
				}
			}
			selection.remove(0);
			mapToInlineChild(selection,nameOfParent);
			
		}
	}

	Map<String, Object> mapNormalField = new LinkedHashMap<String, Object>();
	Map<String, Object> mapInlineField = new LinkedHashMap<String, Object>();
	private void setFieldInMap(List<Field> fet, String nameOfParent) {
		if(fet == null || (fet.size()==0 && fet.isEmpty())) {
			return ;
		}
		Field f = fet.get(0);
		SelectionSet selectionSet = f.getSelectionSet();
		if(selectionSet==null) {
			if(mapNormalField.isEmpty()) {
				List<String> attr = new ArrayList<String>();
				attr.add(f.getName());
				mapNormalField.put(nameOfParent, attr);
			}else if(mapNormalField.get(nameOfParent)!=null) {
				List<String> obj = (List<String>) mapNormalField.get(nameOfParent);
				obj.add(f.getName());
				mapNormalField.put(nameOfParent, obj);
			}else {
				List<String> attr = new ArrayList<String>();
				attr.add(f.getName());
				mapNormalField.put(nameOfParent, attr);
			}
		}else {
			List<InlineFragment> inline = selectionSet.getSelectionsOfType(InlineFragment.class);
			List<Field> field = selectionSet.getSelectionsOfType(Field.class);
			if((inline==null || inline.isEmpty() || inline.size()==0) && (field!=null && !field.isEmpty() && field.size()>0)) {
				setFieldInMap(field,f.getName());
			}else {
				//call inline mapping function.
				//setInlineFieldInMap(inline,f.getName());
			}
		}
		fet.remove(0);
		setFieldInMap(fet, nameOfParent);
	}

	public void relay() {
		Relay relay = new Relay();
		long d = new Date().getTime();
		System.out.println(d);
		// encrypt
		String endCursor = relay.toGlobalId("Timestamp", String.valueOf(d));
		System.out.println(endCursor);
		// for decrypt
		ResolvedGlobalId decryptCursor = relay.fromGlobalId(endCursor);
		Long res = Long.parseLong(decryptCursor.getId());
		System.out.println(res);

	}

}