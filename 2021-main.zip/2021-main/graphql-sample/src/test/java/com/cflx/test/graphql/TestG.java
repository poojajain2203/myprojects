package com.cflx.test.graphql;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cflx.dao.Repo;
import com.cflx.graphql.GraphQLManager;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import graphql.ExecutionResult;

public class TestG {
	
	private GraphQLManager graphQLManager;
	private ObjectMapper objectMapper;
	
	@BeforeTest
	public void init() {
		graphQLManager = new GraphQLManager();
		objectMapper = new ObjectMapper();
	}
	
	
  @Test
  public void f() {
	  Map<String, Object> parms = new HashMap<String, Object>();
	  parms.put("id", "10");
	  
	  
	  
	  String query = "query lookupEmployee($id:String){emp :lookupEmployee(id:$id){id name mobileNumber address{pincode state city}}}";
	   ExecutionResult res = graphQLManager.getData(query,parms);
	  JsonNode json = objectMapper.convertValue(res, JsonNode.class);
	  System.out.println(json);
  }
  
  
  @Test
  public void testInline() {
	  String query = "query lookupDesign{ home : lookupDesign{id designType address{city state pincode} child{ ... on Kitchen{id type feel isDemoAvailable cost interior isRegularWashable child{ ... on Bathroom{id cost interior soap tapQuailty type  size usecase{id name} child{... on G{id cost type g}}} }} } }}";
	  ExecutionResult res = graphQLManager.getData(query,Collections.emptyMap());
	  JsonNode json = objectMapper.convertValue(res, JsonNode.class);
	  System.out.println(json);
  
  }
  
  @Test
  public void testRely() {
	  Repo r = new Repo();
	  r.relay();
	  
  }
}
