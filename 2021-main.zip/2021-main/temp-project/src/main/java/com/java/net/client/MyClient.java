package com.java.net.client;

import java.io.IOException;

public class MyClient {

	
	public static void main(String[] args) throws IOException {
			
		
	}

}
