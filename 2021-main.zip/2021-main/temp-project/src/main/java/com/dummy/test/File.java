package com.dummy.test;

public class File implements IAM {

	private static final String name = "Hello";

	public String getName() {
		return name;
	}

}
