package com.dummy.test;

public class Session implements IAM {

	private static final String session = "Session";

	public String getSession() {
		return session;
	}
}
