package com.dummy.test;

public class Main {

	public static void main(String[] args) {
		
	IAM i = new File();
	
	System.out.println(((File)i).getName());
	
	i = new Session();
	System.out.println(((Session)i).getSession());
	
	
	

	}
	

}
