package com.dummy.test;

public interface IAM {

}
