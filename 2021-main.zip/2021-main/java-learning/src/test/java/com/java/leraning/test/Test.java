package com.java.leraning.test;

import com.java.learning.T1;
import com.java.learning.lambda.Book;

import java.util.List;

public class Test {

   @org.testng.annotations.Test
    public  void testMethod(){
        T1.getField();
    }

    @org.testng.annotations.Test
    public void testField1(){
       T1.checkWhichClass(Book.class);
    }

    @org.testng.annotations.Test
    public  void testField2(){
       T1.checkWhichClass(List.class);
    }


    @org.testng.annotations.Test
    public  void testField3(){
        T1.checkWhichClassByClassMethod(Book.class);
    }

    @org.testng.annotations.Test
    public void testField4(){
       T1.checkWhichClassByClassMethod(List.class);
    }

}
