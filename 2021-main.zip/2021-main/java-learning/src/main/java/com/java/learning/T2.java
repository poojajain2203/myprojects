package com.java.learning;

import java.util.ArrayList;
import java.util.List;

public class T2 {
    public static void main(String[] args) {
        List<Integer> integers = new ArrayList<>();
        integers.add(12);
        integers.add(14);
        integers.add(67);

        int[] i = integers.stream().mapToInt(Integer::intValue).toArray();
        for (Integer i1 : i){
            System.out.println(i1);
        }

    }
}

