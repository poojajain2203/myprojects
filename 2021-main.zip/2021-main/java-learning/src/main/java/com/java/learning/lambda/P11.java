package com.java.learning.lambda;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Why Optional?
 *   class Customer{
 *       int id;
 *       String name;
 *       //setter & getter
 *   }
 *
 *   class Test{
 *      public static void main(String[] args) {
 *             Customer c1 = new Customer(10,"Ravi");
 *             c1.getFields(); // will give data.
 *             Customer c2 = new Customer(10,null);
 *             String name = c2.getName(); //will give null.
 *             //make uppercase
 *
 *             name.toUpperCase(); // null pointer exception.
 *     }
 *
 *   }
 *
 * */





public class P11 {

    public static  Customer getCustomerUsingEmail(String email){ List<Customer> allCustomer = DataBaseCustomer.getAll();
     return allCustomer.stream().filter(customer -> customer.getEmail().equals(email)).findAny().orElseThrow(()->new IllegalArgumentException("Email is not valid."));
    }

    public static void main(String[] args) {
            Customer c1  = new Customer(10,"Ravi","test@gmail.com", Arrays.asList("123","456"));
        Customer c2  = new Customer(11,"Rahul kumar",null, Arrays.asList("123","456"));
            /**
             * Way of Creating Optional Object.
             *  1. empty() : create empty Optional object
             *  2. of()  : create optional object with check value is not null, if value is null then throw exception.
             *  3. ofNullable() : empty()+of() => create optional object if value is null then return empty Optional else return optional with value.
             * */
            //Using empty method.
        Optional emptyOptional = Optional.empty();
        System.out.println(emptyOptional);//Optional.empty
        //Using of method
/*
        Optional<String> emailOptional = Optional.of(c2.getEmail());
        System.out.println(emailOptional); //should be not null. */

        Optional<String> emailOptional1 = Optional.of(c1.getEmail());
        System.out.println(emailOptional1);//Optional[test@gmail.com]

        //using ofNullable method.
        Optional<String> emailOptional2 = Optional.ofNullable(c1.getEmail());
        System.out.println(emailOptional2); //Optional[test@gmail.com]

        Optional<String> emailOptional3 = Optional.ofNullable(c2.getEmail());
        System.out.println(emailOptional3); //Optional.empty

        //methods:
        System.out.println(emailOptional2.get()); // test@gmail.com
        System.out.println(emailOptional3.isPresent());//false


        System.out.println(emailOptional3.orElse("Default Value"));

        //throw exception when email is null.
      // System.out.println(emailOptional3.orElseThrow(()->new IllegalArgumentException("Email is not null")));
        System.out.println(emailOptional3.orElseGet(()->"Default Email."));

        Customer c = getCustomerUsingEmail("peter@gmail.com");
        System.out.println(c.toString());

    }
}
