package com.java.learning.lambda;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class P4 {
    public static void main(String[] args) {
        //Predicate
        //Even Odd:
        Predicate<Integer> result = (t) -> t%2==0;
        System.out.println(result.test(2));
        System.out.println(result.test(5));
        //Java 8 filter method used Predicate.
        List<Integer> list = Arrays.asList(1,2,3,4,5);
        //Print Only Even Data.
        list.stream().filter(result).forEach(t-> System.out.println(t));
    }
}
