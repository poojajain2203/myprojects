package com.java.learning.lambda;

import java.util.*;

//Java 8 Stream - How to Sort a Map using lambda
public class P9 {

    public static void main(String[] args) {

        //Primitive Type Sorting
        Map<String, Integer> map = new LinkedHashMap<>();
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Ten", 10);
        map.put("Nine", 9);
        map.put("Minus One", -1);
        map.put("Zero", 0);

        //Sort A Map Traditional Way
        List<Map.Entry<String, Integer>> list = new ArrayList<>(map.entrySet());
        System.out.println("Before Sorting \n" + list);
        Collections.sort(list, (i, j) -> (i.getValue() - j.getValue()));
        System.out.println("After Sorting \n" + list);


        //Using Lambda.
        System.out.println("=========== Using Lambda Sorting By Value ============");
        map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
        System.out.println("============ Using Lambda Sorting By Key ==========");
        map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);


        //Custom Data Type Sorting In Map:
        //Sorting Using Employee Salary:
        Map<Employee, Integer> empMap = new TreeMap<>((i, j) -> (int) (i.getSalary() - j.getSalary()));
        empMap.put(new Employee(100, "Ravi", 50), 70);
        empMap.put(new Employee(98, "Utkarsh", 30), 80);
        empMap.put(new Employee(105, "Abhishek", 80), 90);
        empMap.put(new Employee(65, "Amit", 890), 60);
        System.out.println(empMap);


        //Using Lambda:
        empMap.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getName).reversed())).forEach(System.out::println);

    }
}




