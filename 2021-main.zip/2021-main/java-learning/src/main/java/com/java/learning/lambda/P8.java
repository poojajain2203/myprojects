package com.java.learning.lambda;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

/**
 * @author Ravi Ranjan
 * */

//Java 8 Stream - How to Sort a List using lambda
public class P8 {

    public static void main(String[] args) {
        List<Integer> list  = Arrays.asList(1,6,7,8,2,0,-9);
        System.out.println(list);
        Collections.sort(list); //ASSENDING
        System.out.println(list);
        Collections.reverse(list); //DESCENDING
        System.out.println(list);

        //Using Lambda
        List<Integer> l  = Arrays.asList(1,6,7,8,2,0,-9);
        System.out.println("====== ASC ORDER ============");
        l.stream().sorted().forEach(t-> System.out.println(t));//ASSENDING ORDER
        System.out.println("======= DESC ORDER ==========");
        l.stream().sorted(Comparator.reverseOrder()).forEach(t-> System.out.println(t)); //DESCENDING ORDER


        //Sorted Custome Data Type.

        List<Employee> emp = EmployeeDao.getAllEmployee();
        System.out.println("=======Before Sorting======\n"+emp);
        Collections.sort(emp,(i,j)->(int)(i.getSalary()-j.getSalary()));
        System.out.println("=======After Soring=======\n"+emp);


        List<Employee> emp2 = EmployeeDao.getAllEmployee();
        System.out.println("=========  Before Sorting ==========");
        System.out.println(emp2);
        System.out.println("======== After Sorting ============");
        emp2.stream().sorted((i,j)->(i.getName().compareTo(j.getName()))).forEach(System.out::println);
        System.out.println("=========  Before Sorting ==========");
        System.out.println(emp2);
        System.out.println("========== After Sorting ===========");
        emp2.stream().sorted(Comparator.comparing(Employee::getName)).forEach(System.out::println);
    }
}