package com.java.learning.lambda;

import java.util.ArrayList;
import java.util.List;

public class BookDao {

    public List<Book> getBooks() {
        List<Book> book = new ArrayList<>();
        book.add(new Book(1, "C", 200));
        book.add(new Book(2, "Java", 500));
        book.add(new Book(10, "Networking", 700));
        book.add(new Book(5, "DBMS", 699));
        return book;

    }
}
