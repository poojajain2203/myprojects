package com.java.learning;

import java.lang.reflect.Field;

class  Book{
    public static final String GRAPHQL_ACTION_ID = "id";
    public static final String GRAPHQL_ACTION_NAME = "name";
    public static final String GRAPHQL_ACTION_STATUS = "status";
    public static final String GRAPHQL_ACTION_DESCRIPTION = "description";
    public static final String GRAPHQL_ACTION_ACTION_OUTCOME = "actionOutcome";
    public static final String GRAPHQL_ACTION_ACTION_OUTCOME_SUMMARY = "actionOutcomeSummary";
    public static final String GRAPHQL_ACTION_SP_ACTION_ID = "spActionId";
    public static final String GRAPHQL_ACTION_SP_ACTION_STATUS = "spActionStatus";
    public static final String GRAPHQL_ACTION_DATA = "data";
    public static final String GRAPHQL_ACTION_ACTION_TYPE = "actionType";
    public static final String GRAPHQL_ACTION_ACTION_TIME = "actionTime";
    public static final String GRAPHQL_ACTION_CREATE_TIME = "createTime";
    public static final String GRAPHQL_ACTION_USECASE_INSTANCE = "usecaseInstance";

}

class Human{

}



public class T1 {
    public static  boolean checkWhichClass(Class c){
        if(Book.class.getName().equals(c.getName())){
            return true;
        }

        return  false; //for Human class
    }

    public static boolean checkWhichClassByClassMethod(Class c){
        if(c.isAssignableFrom(Book.class)) {
            return true;
        }
        return false; //Human Class
    }

    public static void getField(){
        Field[] f = Book.class.getFields();
        System.out.println(f.length);
        for (Field field : f){
            if(field.isSynthetic()){
                System.out.println("Synthetic Field Found.");
                continue;
            }

            System.out.println(field.getName());
        }
    }

    public static void main(String[] args) {
        boolean res1 = checkWhichClass(Book.class);
        System.out.println("Book CLass :: "+res1);
        boolean res2 = checkWhichClass(Human.class);
        System.out.println("Book Class ::"+res2);

        boolean res3 = checkWhichClassByClassMethod(Book.class);
        System.out.println("Book Class :: "+res3);

        boolean res4  = checkWhichClassByClassMethod(Human.class);
        System.out.println("Book Class :: "+res4);
    }
}
