package com.java.learning.lambda;

import java.util.List;
import java.util.stream.Collectors;

public class P7 {

    public static List<Employee> getEmployeeUsingTaxBases(boolean isTaxPayable) {
        if (isTaxPayable) {
            return EmployeeDao.getAllEmployee().stream().filter(emp -> emp.getSalary() > 500000L).collect(Collectors.toList());
        } else {
            return EmployeeDao.getAllEmployee().stream().filter(employee -> employee.getSalary() <= 500000L).collect(Collectors.toList());
        }

    }


    public static void main(String[] args) {
        System.out.println(P7.getEmployeeUsingTaxBases(true));
        System.out.println(P7.getEmployeeUsingTaxBases(false));
    }
}
