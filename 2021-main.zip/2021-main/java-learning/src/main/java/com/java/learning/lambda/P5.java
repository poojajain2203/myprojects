package com.java.learning.lambda;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class P5 {

    public static void main(String[] args) {
        //Supplier
        Supplier<String> result = ()-> "I am String";
        System.out.println(result.get());

        //Print Even if no is even.
        List<String> list = Arrays.asList();

        System.out.println(list.stream().findAny().orElseGet(result));



    }
}
