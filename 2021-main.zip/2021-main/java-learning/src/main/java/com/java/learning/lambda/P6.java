package com.java.learning.lambda;

import java.util.*;

/**
 * Stream In Java:
 * --------------
 * forEach
 * filter
 *
 * */


public class P6 {
    public static void main(String[] args) {
        //forEach:
        //Print List
        List<Integer> listOfInteger = Arrays.asList(1,2,3,4,5,6);
        System.out.println("=================Iterate List ================");
        listOfInteger.stream().forEach(t-> System.out.println(t));
        //Print map
        Map<Integer,String> map = new HashMap<>();
        map.put(1,"Ravi Ranjan");
        map.put(2,"Rahul Kumar");

        System.out.println("=============Without Using Stream===============");
        map.forEach((key,value)-> System.out.println(key + " : "+value));
        System.out.println("===========Using Stream =====================");
        map.entrySet().stream().forEach((obj)-> System.out.println(obj.getKey() + " : "+obj.getValue()));


        //Filter
        List<String> nameList = new ArrayList<>();
        nameList.add("Ravi Ranjan");
        nameList.add("Rahul kumar");
        nameList.add("Amit");
        nameList.add("Parag");
        nameList.add("raj");


        //Print which Name which is start with 'R'
        System.out.println("============Print element which is start with 'R' ==================");
        nameList.stream().filter((t)->t.startsWith("R")).forEach(t-> System.out.println(t));


        //Print Only Even Id & Name:
        System.out.println("============Print Map Key & Value which key is even.================");
        map.entrySet().stream().filter(obj->obj.getKey()%2==0).forEach(obj-> System.out.println(obj.getKey()+" : "+obj.getValue()));















    }
}
