package com.java.learning.lambda;

/**
 * What is Lambda Expression?:
 * - The Expression through which we can represent an Anonymous function.
 * <p>
 * - Anonymous : Nameless/Unknown
 * - Anonoymous function: A method who don't have any name or modifier.
 * <p>
 * Syntax : Parameter   Expression  Body
 * ()           ->        System.out.println("I am Lambda.")
 */

interface Calculator {
    int subtract(int n1, int n2);
}


public class P1 {
    public static void main(String[] args) {
        Calculator c = (n1, n2) ->n1 - n2;
        System.out.println(c.subtract(3,2));

    }
}

/**
 * What is Functional Interface?:
 * The Interface who contains only one abstract method but can have
 * multiple default and static method is called functional Interface.
 * <p>
 * Ex:
 * Runnable  => run()
 * Callable  => call()
 * Comparable  => compareTo()
 * Comparator => compare()
 */
