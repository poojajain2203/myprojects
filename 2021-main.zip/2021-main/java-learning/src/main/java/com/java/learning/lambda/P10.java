package com.java.learning.lambda;

import java.util.List;
import java.util.stream.Collectors;

//Java 8 Streams | map () & flatMap() Example
public class P10 {
    /**
     * Differences between Java 8 Map() Vs flatMap() :
     * map():
     * - It processes stream of values.
     * - It does only mapping.
     * - It’s mapper function produces single value for each input value.
     * - It is a One-To-One mapping.
     * - Data Transformation : From Stream to Stream
     * - Use this method when the mapper function is producing a single value for each input value.
     *
     * flatMap():
     * - It processes stream of stream of values.
     * - It performs mapping as well as flattening.
     * - It’s mapper function produces multiple values for each input value.
     * - It is a One-To-Many mapping.
     * - Data Transformation : From Stream<Stream> to Stream
     * - Use this method when the mapper function is producing multiple values for each input value.
     */

    public static void main(String[] args) {
        List<Customer> list = DataBaseCustomer.getAll();

        //one to one mapping: <All Email>
        List<String> emails = list.stream().map(customer -> customer.getEmail()).collect(Collectors.toList());
        System.out.println(emails);

        //
        //one to many mapping using map we can't  collect it into one stream.
        List<List<String>> collectNumbers = list.stream().map(customer -> customer.getPhoneNumbers()).collect(Collectors.toList());
        System.out.println(collectNumbers);

        //Collect All PhoneNumbers In One Stream.
        List<String> allPhoneNumbers = list.stream().flatMap(customer -> customer.getPhoneNumbers().stream()).collect(Collectors.toList());
        System.out.println(allPhoneNumbers);
    }

}
