package com.java.learning.lambda;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class P2 {

    public static void main(String[] args) {
        BookService bs = new BookService();
        //SortedByName.
        System.out.println(bs.getSortedBook());
        //2nd Method
        System.out.println(bs.getSortedBookDesc());

         //Using Lambda.
        System.out.println(bs.getSortedBookDesc2());

    }

}
