package com.java.learning.lambda;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class BookService {


    public List<Book> getSortedBook() {
        List<Book> b = new BookDao().getBooks();
        Collections.sort(b, new MySorting());
        return b;
    }

    public List<Book> getSortedBookDesc() {
        List<Book> b = new BookDao().getBooks();
        Collections.sort(b, new Comparator<Book>() {
            @Override
            public int compare(Book o1, Book o2) {
                //descending order.
                return o2.getName().compareTo(o1.getName());
            }
        });
        return b;
    }

    //using Lambda.
    public List<Book> getSortedBookDesc2() {
        List<Book> b = new BookDao().getBooks();
        Collections.sort(b, (o1, o2) -> o2.getName().compareTo(o1.getName()));
        return b;
    }
}


class MySorting implements Comparator<Book> {

    @Override
    public int compare(Book o1, Book o2) {
        //assending order.
        return o1.getName().compareTo(o2.getName());
    }
}
