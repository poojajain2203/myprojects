package com.java.learning.lambda;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class EmployeeDatabase {
    public static List<Emp> getEmployees(){
        List<Emp> emps = new ArrayList<>();
        for (int i=1;i<=1000000;i++){

            emps.add(new Emp(i,"A","emp"+i,Integer.valueOf(new Random().nextInt(1000*100))));
        }
        return emps;


    }

}
