package com.java.learning.lambda;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * What is Map-Reduce?
 *   - Map-Reduce is a functional Programming model it serves our 2 purpose.
 *       - Map ==> Transforming Data.
 *       - Reduce ==> Aggregating Data
 *        (combines elements of a Stream and produces a single value)
 *
 * Ex: Stream: [2,4,6,9,1,3,7] Sum of Numbers present in stream?
 *
 * Map() -> Transform Stream<Object> to Stream of int.
 * Reduce() -> combine stream of int and produce the sum result.
 *
 *  Reduce Method:
 *   T reduce(T identity, BinaryOperator<T> accumulator);
 *         - identity is initial value of type T.
 *         - accumulator is a function for combining two values.
 *
 *  Integer sumResult = Stream.of(2,4,6,9,1,3,7).reduce(0,(a,b)->a+b);
 *          - identity: 0 which is nothing initial value.
 *          - Accumulator: (a,b)->a+b function.
 *
 * */

class Emp{
    private int id;
    private String grade;
    private String name;
    private int sal;

    public int getSal() {
        return sal;
    }

    public void setSal(int sal) {
        this.sal = sal;
    }

    public Emp() {

    }
    public Emp(int id, String grade, String name,int sal) {
        this.id = id;
        this.grade = grade;
        this.name = name;
        this.sal = sal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

public class P12 {

    public static List<Emp>  getAll(){
        return  Stream.of(new Emp(1,"A","Ravi",2400),new Emp(2,"A","Rahul",2400),new Emp(3,"B","Tarun",450)).collect(Collectors.toList());
    }


    public static void main(String[] args) {

        List<Integer> numbers = Arrays.asList(2,4,6,8);
        int sum1 = numbers.stream().mapToInt(Integer::intValue).sum();
        int sum2 = numbers.stream().mapToInt(i->i).sum();
        Optional<Integer> sum3 = numbers.stream().reduce(Integer::sum);
        System.out.println(sum1 + " "+sum2+" "+sum3.get());


        Integer maxValue = numbers.stream().reduce(0,(a,b)->a>b?a:b);
        System.out.println(maxValue);





        Integer sumOfResult = Stream.of(2,4,6,8,10).reduce(0,(a,b)->a+b);
        System.out.println(sumOfResult);


        //Evaluate average salary of grade A employee.
        List<Emp> emp = P12.getAll();

        double avgSal = emp.stream().filter(e -> e.getGrade().equals("A")).map(e -> e.getSal()).mapToDouble(i -> i).average().getAsDouble();
        System.out.println(avgSal);
        double totalSal = emp.stream().filter(e -> e.getGrade().equals("A")).map(e -> e.getSal()).mapToDouble(i -> i).sum();
        System.out.println(totalSal);
    }
}
