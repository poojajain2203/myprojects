package com.java.learning.lambda;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/**
 * Consumer,Predicate, Supplier:
 * -----------------------------
 * Consumer:
 * --------
 * - Consumer<T> is an built functional Interface introduced in java 8
 * Consumer can be used in all contexts where an object needs to be consumed
 * i.e taken as input,and some operation is to be performed on the object
 * without returning any result.
 * ----- void accept(T t);
 *
 * Predicate:
 * ---------
 * This Functional Interface used for conditional check.
 * where you think, we can use these true/false returning functions in day to
 * day programming we should choose Predicate.
 *
 * -------  boolean test(T t);
 *
 * Supplier:
 * --------
 * This functional Interface, Supplier can be used in all context where
 * there is no input but an output is expected.
 *
 * -------  T get();
 */


public class P3  {
    public static void main(String[] args) {
        //Consumer
        Consumer<Integer> consumer = (t)-> System.out.println(t);
        consumer.accept(10);

        List<Integer> list = Arrays.asList(1,2,3,4,5,6,7);
        //foreach method accept the Consumer interface.
        list.stream().forEach(consumer);
        list.stream().forEach(t-> System.out.println(t));
    }


}
