package com.ravi.grahqlend;

import javax.servlet.annotation.WebServlet;

import com.coxautodev.graphql.tools.SchemaParser;

import graphql.schema.GraphQLSchema;
import graphql.servlet.SimpleGraphQLServlet;


@WebServlet(urlPatterns = "/graphql")
public class GraphQLEndPoints  extends SimpleGraphQLServlet{



	//URL  Request GET : http://localhost:8081/graphql-demo/graphql?query={allLinks{url}}
	
	/*
	 
	 Request : POST
	 mutation{
    createLink(url : "www.google.com" description:"web"){
        url 
        description
    }
   
    Request : GET
    
    query{
    allLinks{
        url
        description
        
    }
}
}
	 
	  
	  
	  */

	public GraphQLEndPoints() {
		super(buildSchema());
	}
	
	private static GraphQLSchema buildSchema() {
		
		LinkRepository linkRepository = new LinkRepository();
		//	System.out.println("Hello");
		return SchemaParser.newParser().file("schema.graphqls").resolvers(new Query(linkRepository),new Mutation(linkRepository)).build().makeExecutableSchema();
	}

}
			