package com.cflx.test.graphql;

import static org.testng.Assert.assertNotNull;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cflx.graphql.GraphQLManager;

import graphql.ExecutionResult;

public class TestG {
	
	private GraphQLManager graphQLManager;
	
	@BeforeTest
	public void init() {
		graphQLManager = new GraphQLManager();
	}
	
	
  @Test
  public void f() {
	  
	  String query = "query lookupQuark{ lookupQuark{... on Event{name id type child{edges{node{ ... on Task{id name type}}}}}}}";
	//  String query = "query lookupQuark{ lookupQuark{... on Task{name id type child{edges{node{ ... on Action{id name type}}}}}}}";
	  ExecutionResult res = graphQLManager.getData(query, null);
	  
	  assertNotNull(res);
  }
}
