package com.cflx.graphql;

import static graphql.schema.idl.TypeRuntimeWiring.newTypeWiring;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.cflx.model.Event;
import com.cflx.model.Task;
import com.cflx.model.Action;

import graphql.schema.GraphQLSchema;
import graphql.schema.TypeResolver;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;

public class SchemaLoader {

	private static final String GRAPHQL_FILE_NAME = "graphql-schema.graphql";
	private static SchemaLoader schemaProvider;
	private GraphQLSchema graphQLSchema;

	public static SchemaLoader getInstance() {
		if (schemaProvider == null) {
			schemaProvider = new SchemaLoader();
		}
		return schemaProvider;
	}

	public graphql.GraphQL getGraphqlProvider() {
		return graphql.GraphQL.newGraphQL(graphQLSchema).build();
	}

	public void buildSchema() {
		InputStream stream = null;
		Reader reader = null;
		try {
			ClassLoader classLoader = SchemaLoader.class.getClassLoader();
			stream = classLoader.getResourceAsStream(GRAPHQL_FILE_NAME);

			if (stream == null) {
				throw new RuntimeException("Cannot read Graphl schema!. File: " + GRAPHQL_FILE_NAME);
			}

			reader = new InputStreamReader(stream);
			SchemaGenerator schemaGenerator = new SchemaGenerator();
			SchemaParser schemaParser = new SchemaParser();
			TypeDefinitionRegistry registry = schemaParser.parse(reader);
			RuntimeWiring wiring = buildRuntimeWiring();
			graphQLSchema = schemaGenerator.makeExecutableSchema(registry, wiring);

		} catch (Exception e) {
			throw new RuntimeException("Cannot build Graphql schema. Error: ", e);

		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
				if (stream != null) {
					stream.close();
				}
			} catch (IOException e) {
			}
		}
	}

	private RuntimeWiring buildRuntimeWiring() {
		GraphQLDataFetcher dataFetcher = new GraphQLDataFetcher();
		System.out.println("Wiring");
		return RuntimeWiring.newRuntimeWiring().type(newTypeWiring("Query").dataFetcher("lookupQuark", dataFetcher.lookupQuark))
				.type(newTypeWiring("Event").dataFetcher("child", dataFetcher.eventChildDF))
				.type(newTypeWiring("Task").dataFetcher("child", dataFetcher.taskChildDF))
				.type(newTypeWiring("Action").dataFetcher("child", dataFetcher.actionChildDF))
				.type(newTypeWiring("AbstractEntity").typeResolver(entityResolver)).build();
	}
	//need pojo
	private static final TypeResolver entityResolver = env -> {
		if (env.getObject() != null) {
			Object obj = env.getObject();
			System.out.println(obj);
			if (obj instanceof Task) {
				System.out.println("Task TR");
				return env.getSchema().getObjectType("Task");
			} else if (obj instanceof Event) {
				System.out.println("Event TR");
				return env.getSchema().getObjectType("Event");
			} else if (obj instanceof Action) {
				System.out.println("Action TR");
				return env.getSchema().getObjectType("Action");
			} else {
				System.out.println("Invalid Type Resolver");
				return null;
			}

		}
		System.out.println("(: === Cannot Resolve Type ====:)");
		return null;
	};
}
