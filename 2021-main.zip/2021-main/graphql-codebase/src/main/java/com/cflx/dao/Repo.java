
package com.cflx.dao;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.cflx.model.Action;
import com.cflx.model.Event;
import com.cflx.model.Task;

public class Repo {

	static Event e1;
	static Task t1;
	static Map<Integer, Task> map;
	static Map<Integer, Action> mapAction;
	static {
		Action a1 = new Action(200, "Action_A", "A", null);
		Action a2 = new Action(201, "Action_B", "B", null);
		Action a3 = new Action(202, "Action_C", "C", null);
		Action a4 = new Action(203, "Action_D", "D", null);
		mapAction = new HashMap<Integer, Action>();
		mapAction.put(200, a1);
		mapAction.put(201, a2);
		mapAction.put(202, a3);
		mapAction.put(203, a4);

		t1 = new Task(1, "Task_A", "A", Arrays.asList(a1, a2));
		Task t2 = new Task(2, "Task_B", "B", Arrays.asList(a3, a4));
		Task t3 = new Task(3, "Task_C", "C", null);
		Task t4 = new Task(4, "Task_D", "D", null);
		map = new HashMap<Integer, Task>();
		map.put(1, t1);
		map.put(2, t2);
		map.put(3, t3);
		map.put(4, t4);
		e1 = new Event(100, "Event_A", "A", Arrays.asList(t1, t2, t3, t4));

	}

	public Object search() {

		return Arrays.asList(e1);
		// return Arrays.asList(t1);

	}

	public static Task getTasks(int id) {
		System.out.println("Dao Task Id : " + id);
		return map.get(id);
	}

	public static Event getEvents(int id) {
		return null;
	}

	public static Action getActions(int id) {
		System.out.println("Dao Action Id : " + id);
		return mapAction.get(id);
	}

}
