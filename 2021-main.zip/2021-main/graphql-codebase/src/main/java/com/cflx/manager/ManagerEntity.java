package com.cflx.manager;

import java.util.List;

import com.cflx.dao.Repo;
import com.cflx.model.Action;
import com.cflx.model.Event;
import com.cflx.model.Task;

public class ManagerEntity {

	private Repo repo;

	public ManagerEntity() {
		repo = new Repo();
	}

	public Object serach() {
		// which will be call E/T/A
		return repo.search();
	}

	public static Task getTasks(int id) {
		return Repo.getTasks(id);
	}
	
	public static Event getEvents(int id) {
		return Repo.getEvents(id);
	}
	
	public static Action getActions(int id) {
		return Repo.getActions(id);
	}
}
