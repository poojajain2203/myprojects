package com.cflx.graphql;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;

import org.dataloader.BatchLoader;
import org.dataloader.DataLoader;
import org.dataloader.DataLoaderRegistry;

import com.cflx.manager.ManagerEntity;
import com.cflx.model.Action;
import com.cflx.model.Event;
import com.cflx.model.Task;

import graphql.schema.DataFetcher;

public class GraphQLDataFetcher {

	private ManagerEntity managerEntity;
	public static DataLoaderRegistry dataLoaderRegistry;

	public GraphQLDataFetcher() {
		managerEntity = new ManagerEntity();
		DataLoader<Integer, Task> taskDataLoader = DataLoader.newDataLoader(taskBatchLoader);
		DataLoader<Integer, Event> eventDataLoader = DataLoader.newDataLoader(eventBatchLoader);
		DataLoader<Integer, Action> actionDataLoader = DataLoader.newDataLoader(actionBatchLoader);
		dataLoaderRegistry = new DataLoaderRegistry();
		dataLoaderRegistry.register("task", taskDataLoader);
		dataLoaderRegistry.register("event", eventDataLoader);
		dataLoaderRegistry.register("action", actionDataLoader);

	}

	DataFetcher lookupQuark = env -> {
		return managerEntity.serach();
	};

	public DataFetcher getLookupQuark() {
		return lookupQuark;
	}

	public DataFetcher taskChildDF = env -> {
		System.out.println("Task Child DF");
		Task task = env.getSource();
		System.out.println("Task :: {} " + task);
		List<Action> action = task.getChild();
		List<Integer> idAction = new ArrayList<>();
		for (Action t : action) {
			idAction.add(t.getId());
		}
		System.out.println("Tasks Id :{} " + idAction);
		DataLoader<Integer, Task> dataLoader = env.getDataLoader("event");

		return dataLoader.loadMany(idAction);
	};

	public DataFetcher eventChildDF = env -> {
		System.out.println("Event Child DF");
		Event event = env.getSource();
		System.out.println("Event :: {} " + event);
		List<Task> task = event.getChild();
		List<Integer> idTask = new ArrayList<>();
		for (Task t : task) {
			idTask.add(t.getId());
		}
		System.out.println("Tasks Id :{} " + idTask);
		DataLoader<Integer, Task> dataLoader = env.getDataLoader("task");
		return dataLoader.loadMany(idTask);
	};

	public DataFetcher actionChildDF = env -> {
		System.out.println("Action Child DF");
		Action action = env.getSource();
		System.out.println("action :: {} " + action);
		List<Event> event = action.getChild();
		List<Integer> idevent = new ArrayList<>();
		for (Event t : event) {
			idevent.add(t.getId());
		}
		System.out.println("actions Id :{} " + idevent);
		DataLoader<Integer, Task> dataLoader = env.getDataLoader("event");
		return dataLoader.loadMany(idevent);
	};

	BatchLoader<Integer, Task> taskBatchLoader = new BatchLoader<Integer, Task>() {

		@Override
		public CompletionStage<List<Task>> load(List<Integer> keys) {
			// TODO Auto-generated method stub
			System.out.println("keys::" + keys);
			return CompletableFuture.supplyAsync(() -> getTasks(keys));
		}

		private List<Task> getTasks(List<Integer> keys) {
			return keys.stream().map(ManagerEntity::getTasks).collect(Collectors.toList());
		}
	};

	BatchLoader<Integer, Event> eventBatchLoader = new BatchLoader<Integer, Event>() {

		@Override
		public CompletionStage<List<Event>> load(List<Integer> keys) {
			// TODO Auto-generated method stub
			System.out.println("keys::" + keys);
			return CompletableFuture.supplyAsync(() -> getEvents(keys));
		}

		private List<Event> getEvents(List<Integer> keys) {
			return keys.stream().map(ManagerEntity::getEvents).collect(Collectors.toList());
		}
	};

	BatchLoader<Integer, Action> actionBatchLoader = new BatchLoader<Integer, Action>() {

		@Override
		public CompletionStage<List<Action>> load(List<Integer> keys) {
			// TODO Auto-generated method stub
			System.out.println("keys::" + keys);
			return CompletableFuture.supplyAsync(() -> getActions(keys));
		}

		private List<Action> getActions(List<Integer> keys) {
			return keys.stream().map(ManagerEntity::getActions).collect(Collectors.toList());
		}
	};

}
